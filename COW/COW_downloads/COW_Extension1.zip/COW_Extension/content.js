(() => {
  const existing = document.getElementById("cow-floating-root");
  if (existing) {
    existing.style.display = existing.style.display === "none" ? "block" : "none";
    return;
  }

  const PLATFORM_ORDER = [
    "XY","OL","LS","XH",
    "TD","RF","HS","YD",
    "ND","YS","SH","JY",
    "JD","MT","FB"
  ];

  const PLATFORM_URLS = {
    "XY": "https://be.ms1666888.com/ManualDeposit",
    "OL": "https://be.ms1666888.com/ManualDeposit",
    "LS": "https://be.ms1666888.com/ManualDeposit",
    "XH": "https://be.ms1666888.com/ManualDeposit",
    "TD": "https://gz76qha4.tdyule222.com",
    "RF": "https://ktphr2j6.rfyule555.com/",
    "HS": "https://txwhsiqk.hsly04.com/",
    "YD": "https://ymsvcncb.ydyule666.com",
    "ND": "https://xgjemo.hdmx57.com/",
    "YS": "https://bu69t1grl1.ysyla16888.com/",
    "SH": "https://m6hcy34zd9.sh0031.com/",
    "JY": "https://dfdkgv.jyna67.com/",
    "JD": "https://b22465e41r.jdvip1688.com/",
    "MT": "https://kka0pl5f2t.mtyl1388.com/",
    "FB": "http://fbyl369.com/"
  };

  const MS_URL = "https://ms.rcppay.com/management/payment/third-party";
  const SFP_URL = "https://sfp.csussr.com/management/transaction-record/withdrawal-slips";

  const root = document.createElement("div");
  root.id = "cow-floating-root";
  root.innerHTML = `
    <div id="cow-dragbar">
      <div>
        <div id="cow-title">COW_Extension</div>
        <div id="cow-sub">控制中心</div>
      </div>
      <div id="cow-head-actions">
        <button id="cow-min" title="縮小">—</button>
        <button id="cow-close" title="隱藏">×</button>
      </div>
    </div>

    <div id="cow-tabs">
      <button class="cow-tab active" data-tab="login">檢查登入</button>
      <button class="cow-tab" data-tab="repay">出款失敗補回</button>
      <button class="cow-tab" data-tab="short">出款金額有少</button>
      <button class="cow-tab" data-tab="settings">补回记录</button>
    </div>

<div id="cow-body">
      <div class="cow-page active" data-page="login">
        <div class="cow-section-title">平台</div>
        <div id="cow-grid"></div>

        <button id="cow-check-login" class="cow-primary">檢查登入</button>

        <div id="cow-status">尚未操作</div>
        <div id="cow-note">選取平台後 點擊 檢查登入 確認是否都已登入</div>
      </div>

      <div class="cow-page" data-page="repay">
        <div class="cow-section-title">出款失敗補回</div>

        <textarea id="cow-repay-input" class="cow-textarea" rows="4" placeholder="請輸入補回資料格式&#10;RF\tWKRL_77638\tzd16888&#10;补回176"></textarea>

        <div class="cow-progress-wrap">
          <div class="cow-progress-line"></div>
          <div class="cow-progress-step" data-step="query">
            <div class="cow-progress-dot"></div>
            <div class="cow-progress-label">查詢</div>
          </div>
          <div class="cow-progress-step" data-step="ms">
            <div class="cow-progress-dot"></div>
            <div class="cow-progress-label">MS作帳</div>
          </div>
          <div class="cow-progress-step" data-step="operate">
            <div class="cow-progress-dot"></div>
            <div class="cow-progress-label">操作補回頁面</div>
          </div>
          <div class="cow-progress-step" data-step="captcha">
            <div class="cow-progress-dot"></div>
            <div class="cow-progress-label">人工輸入驗證碼</div>
          </div>
        </div>

        <div class="cow-return-grid">
          <div class="cow-return-card">
            <div class="cow-return-title cow-return-title-row"><span>查詢進度</span><button id="cow-query-btn" class="cow-inline-btn">查詢</button></div>
            <div id="cow-query-progress" class="cow-return-box">尚未開始</div>
          </div>
          <div class="cow-return-card">
            <div class="cow-return-title cow-return-title-row"><span>補回進度</span><button id="cow-repay-btn" class="cow-inline-btn">操作+MS作帳</button></div>
            <div id="cow-repay-progress" class="cow-return-box">尚未開始</div>
          </div>
        </div>

      </div>

      <div class="cow-page" data-page="short">
        <div class="cow-placeholder">出款金額有少</div>
      </div>

      <div class="cow-page" data-page="settings">
        <div class="cow-section-title">补回记录</div>
        <div id="cow-repay-records" class="cow-record-list">尚无记录</div>
      </div>
    </div>

    <div id="cow-resize-top-left" class="cow-resize-handle cow-resize-top-left" title="拖曳縮放"></div>
    <div id="cow-resize-top-right" class="cow-resize-handle cow-resize-top-right" title="拖曳縮放"></div>
    <div id="cow-resize-left" class="cow-resize-handle cow-resize-left" title="拖曳縮放"></div>
    <div id="cow-resize-right" class="cow-resize-handle cow-resize-right" title="拖曳縮放"></div>
  `;

  const style = document.createElement("style");
  style.textContent = `
    #cow-floating-root {
      position: fixed !important;
      top: 70px; right: 18px;
      width: 410px !important;
      z-index: 2147483647 !important;
      background: linear-gradient(180deg,#f8fbff 0%,#f3f6fb 100%) !important;
      border: 1px solid #d8e0ec !important;
      border-radius: 16px !important;
      box-shadow: 0 18px 48px rgba(15,23,42,.18), 0 2px 10px rgba(15,23,42,.08) !important;
      font-family: Arial,"Microsoft JhengHei",sans-serif !important;
      color:#1f2937 !important;
      overflow:hidden !important;
      --cow-scale: 1;
      transform:scale(var(--cow-scale)) !important;
      transform-origin:top left !important;
    }
    #cow-floating-root * { box-sizing:border-box !important; }

    #cow-floating-root .cow-resize-handle {
      position:absolute !important;
      width:18px !important;
      height:18px !important;
      z-index:30 !important;
      opacity:.72 !important;
      user-select:none !important;
    }

    #cow-floating-root .cow-resize-top-left {
      top:2px !important;
      left:2px !important;
      cursor:nwse-resize !important;
      border-left:3px solid #7c8795 !important;
      border-top:3px solid #7c8795 !important;
      border-top-left-radius:4px !important;
    }

    #cow-floating-root .cow-resize-top-right {
      top:2px !important;
      right:2px !important;
      cursor:nesw-resize !important;
      border-right:3px solid #7c8795 !important;
      border-top:3px solid #7c8795 !important;
      border-top-right-radius:4px !important;
    }

    #cow-floating-root .cow-resize-left {
      bottom:2px !important;
      left:2px !important;
      cursor:nesw-resize !important;
      border-left:3px solid #7c8795 !important;
      border-bottom:3px solid #7c8795 !important;
      border-bottom-left-radius:4px !important;
    }

    #cow-floating-root .cow-resize-right {
      bottom:2px !important;
      right:2px !important;
      cursor:nwse-resize !important;
      border-right:3px solid #7c8795 !important;
      border-bottom:3px solid #7c8795 !important;
      border-bottom-right-radius:4px !important;
    }

    #cow-floating-root .cow-resize-handle:hover {
      opacity:1 !important;
      border-color:#222 !important;
    }

    #cow-dragbar {
      padding:10px 12px !important;
      background: linear-gradient(135deg,#161c24 0%,#2a3442 100%) !important;
      color:#fff !important;
      display:flex !important;
      justify-content:space-between !important;
      align-items:center !important;
      cursor:move !important;
      user-select:none !important;
      border-bottom:1px solid rgba(255,255,255,.08) !important;
    }

    #cow-title { font-size:16px !important; font-weight:800 !important; letter-spacing:.2px !important; line-height:1.1 !important; }
    #cow-sub { font-size:9px !important; line-height:1.05 !important; opacity:.68 !important; margin-top:1px !important; }

    #cow-head-actions {
      display:flex !important;
      gap:6px !important;
    }

    #cow-head-actions button {
      width:30px !important;
      height:30px !important;
      padding:0 !important;
      border:1px solid rgba(255,255,255,.16) !important;
      border-radius:8px !important;
      background:rgba(255,255,255,.96) !important;
      color:#1f2937 !important;
      cursor:pointer !important;
      font-weight:700 !important;
      transition:transform .15s ease, background .15s ease, box-shadow .15s ease !important;
      box-shadow:0 1px 2px rgba(0,0,0,.06) !important;
    }
    #cow-head-actions button:hover {
      background:#ffffff !important;
      transform:translateY(-1px) !important;
      box-shadow:0 4px 10px rgba(0,0,0,.12) !important;
    }


    #cow-floating-root.cow-mini {
      width:44px !important;
      background:transparent !important;
      border:0 !important;
      box-shadow:none !important;
      overflow:visible !important;
      transform:scale(1) !important;
      transform-origin:top left !important;
    }

    #cow-floating-root.cow-mini #cow-dragbar {
      padding:0 !important;
      background:transparent !important;
      cursor:default !important;
    }

    #cow-floating-root.cow-mini #cow-dragbar > div:first-child,
    #cow-floating-root.cow-mini #cow-close,
    #cow-floating-root.cow-mini #cow-tabs,
    #cow-floating-root.cow-mini #cow-body,
    #cow-floating-root.cow-mini .cow-resize-handle {
      display:none !important;
    }

    #cow-floating-root.cow-mini #cow-head-actions {
      gap:0 !important;
    }

    #cow-floating-root.cow-mini #cow-min {
      width:38px !important;
      height:38px !important;
      border-radius:10px !important;
      border:1px solid #4c5668 !important;
      box-shadow:0 6px 18px rgba(0,0,0,.28) !important;
      font-size:20px !important;
      font-weight:800 !important;
      line-height:1 !important;
      font-family:"Microsoft JhengHei","PingFang TC",Arial,sans-serif !important;
      background:#1f2a38 !important;
      color:#ffd86b !important;
      text-shadow:0 1px 2px rgba(0,0,0,.35) !important;
      cursor:move !important;
      touch-action:none !important;
    }

    #cow-floating-root.cow-mini #cow-min:hover {
      background:#273445 !important;
      color:#ffe28a !important;
      border-color:#667489 !important;
    }

    #cow-tabs {
      display:grid !important;
      grid-template-columns: 0.95fr 1.45fr 1.35fr 0.75fr !important;
      gap:6px !important;
      padding:7px 8px 4px !important;
      background:#eef3f8 !important;
      border-bottom:1px solid #dbe4ef !important;
    }

    #cow-tabs .cow-tab {
      min-height:36px !important;
      padding:5px 8px !important;
      border:1px solid transparent !important;
      border-radius:10px !important;
      background:transparent !important;
      color:#5b677a !important;
      font-size:11px !important;
      line-height:1.25 !important;
      cursor:pointer !important;
      white-space:normal !important;
      word-break:keep-all !important;
      transition:all .15s ease !important;
    }

    #cow-tabs .cow-tab:last-child { border-right:0 !important; }

    #cow-tabs .cow-tab:hover {
      background:#f8fbff !important;
      color:#334155 !important;
      border-color:#d9e3ef !important;
    }

    #cow-tabs .cow-tab.active {
      background:#ffffff !important;
      color:#0f172a !important;
      font-weight:800 !important;
      border-color:#d8e3f0 !important;
      box-shadow:0 4px 12px rgba(37,99,235,.08) !important;
    }

    #cow-body { padding:8px 14px 14px !important; background:linear-gradient(180deg,#f8fbff 0%,#f4f7fb 100%) !important; }
    .cow-page { margin-top:0 !important; }
    .cow-page > :first-child { margin-top:0 !important; }

    .cow-page { display:none !important; }
    .cow-page.active { display:block !important; }

    .cow-section-title {
      font-size:14px !important;
      font-weight:800 !important;
      margin:0 0 8px 0 !important;
      color:#1f2937 !important;
      letter-spacing:.2px !important;
    }

    #cow-grid {
      display:grid !important;
      grid-template-columns:repeat(4,1fr) !important;
      gap:8px !important;
      margin-top:2px !important;
    }

    #cow-grid label {
      display:flex !important;
      align-items:center !important;
      gap:7px !important;
      padding:9px 10px !important;
      border:1px solid #d7e0ec !important;
      border-radius:10px !important;
      background:#ffffff !important;
      font-size:12px !important;
      color:#334155 !important;
      cursor:pointer !important;
      transition:all .15s ease !important;
      box-shadow:0 1px 2px rgba(15,23,42,.03) !important;
    }

    #cow-grid label:hover {
      border-color:#94a3b8 !important;
      box-shadow:0 6px 12px rgba(15,23,42,.06) !important;
      transform:translateY(-1px) !important;
    }

    #cow-grid label:has(input:checked) {
      border-color:#1d4ed8 !important;
      background:linear-gradient(180deg,#eff6ff 0%,#dbeafe 100%) !important;
      color:#0f172a !important;
      box-shadow:0 0 0 1px rgba(29,78,216,.08), 0 6px 16px rgba(29,78,216,.12) !important;
    }

    #cow-grid input {
      margin:0 !important;
      accent-color:#2563eb !important;
    }

    #cow-floating-root .cow-primary {
      width:100% !important;
      margin-top:14px !important;
      padding:11px !important;
      border:1px solid #1d2735 !important;
      border-radius:10px !important;
      background:linear-gradient(135deg,#1f2937 0%,#111827 100%) !important;
      color:#fff !important;
      font-size:13px !important;
      font-weight:700 !important;
      letter-spacing:.2px !important;
      cursor:pointer !important;
      box-shadow:0 8px 18px rgba(17,24,39,.16) !important;
      transition:transform .15s ease, box-shadow .15s ease !important;
    }
    #cow-floating-root .cow-primary:hover {
      transform:translateY(-1px) !important;
      box-shadow:0 12px 20px rgba(17,24,39,.2) !important;
    }

    #cow-status {
      margin-top:10px !important;
      padding:10px 11px !important;
      background:#ffffff !important;
      border:1px solid #d8e1eb !important;
      border-radius:10px !important;
      font-size:12px !important;
      color:#334155 !important;
      box-shadow:inset 0 1px 0 rgba(255,255,255,.85), 0 1px 2px rgba(15,23,42,.03) !important;
    }

    #cow-note {
      margin-top:9px !important;
      color:#64748b !important;
      font-size:11px !important;
      line-height:1.5 !important;
      background:rgba(255,255,255,.6) !important;
      border:1px dashed #d7e0ec !important;
      border-radius:10px !important;
      padding:9px 10px !important;
    }

    .cow-placeholder {
      min-height:140px !important;
      display:flex !important;
      justify-content:center !important;
      align-items:center !important;
      border:1px dashed #ccc !important;
      border-radius:8px !important;
      background:#fff !important;
      color:#888 !important;
      font-size:13px !important;
    }

    .cow-textarea {
      width:100% !important;
      min-height:82px !important;
      resize:vertical !important;
      padding:10px 11px !important;
      border:1px solid #d7e0ec !important;
      border-radius:10px !important;
      background:#fff !important;
      color:#1f2937 !important;
      font-size:12px !important;
      line-height:1.5 !important;
      outline:none !important;
      box-shadow:inset 0 1px 2px rgba(15,23,42,.03) !important;
    }
    .cow-textarea:focus {
      border-color:#93c5fd !important;
      box-shadow:0 0 0 3px rgba(59,130,246,.12) !important;
    }

    .cow-progress-wrap {
      position:relative !important;
      display:grid !important;
      grid-template-columns:repeat(4,1fr) !important;
      margin:12px 2px 14px !important;
      padding:8px 6px 2px !important;
      background:rgba(255,255,255,.7) !important;
      border:1px solid #dde6f1 !important;
      border-radius:12px !important;
    }

    .cow-progress-line {
      position:absolute !important;
      left:12.5% !important;
      right:12.5% !important;
      top:19px !important;
      height:3px !important;
      background:#d5deea !important;
      z-index:0 !important;
      border-radius:999px !important;
    }

    .cow-progress-step {
      position:relative !important;
      z-index:1 !important;
      text-align:center !important;
    }

    .cow-progress-dot {
      width:22px !important;
      height:22px !important;
      margin:0 auto 7px !important;
      border:2px solid #a8b3c2 !important;
      border-radius:50% !important;
      background:#fff !important;
      box-shadow:0 0 0 4px #f4f8fc !important;
    }

    .cow-progress-step.done .cow-progress-dot {
      border-color:#2e7d32 !important;
      background:#43a047 !important;
      box-shadow:0 0 0 3px #e8f5e9 !important;
    }

    .cow-progress-step.active .cow-progress-dot {
      border-color:#d99000 !important;
      background:#ffb300 !important;
      box-shadow:0 0 0 3px #fff3cd !important;
    }

    .cow-progress-label {
      font-size:10px !important;
      line-height:1.2 !important;
      color:#555 !important;
      white-space:normal !important;
    }

    .cow-return-grid {
      display:grid !important;
      grid-template-columns:1fr 1fr !important;
      gap:8px !important;
      margin-top:8px !important;
    }

    .cow-return-card {
      min-width:0 !important;
    }

    .cow-return-title {
      margin-bottom:4px !important;
      font-size:11px !important;
      font-weight:700 !important;
      color:#444 !important;
    }

    #cow-query-btn,
    #cow-repay-btn {
      font-size:11px !important;
    }

    #cow-query-progress,
    #cow-repay-progress {
      font-size:11px !important;
    }

    .cow-return-title-row > span {
      color:#444 !important;
      font-size:11px !important;
      font-weight:700 !important;
    }
.cow-return-box {
      min-height:64px !important;
      max-height:110px !important;
      overflow:auto !important;
      padding:8px !important;
      border:1px solid #dae3ee !important;
      border-radius:10px !important;
      background:#fff !important;
      color:#475569 !important;
      font-size:11px !important;
      line-height:1.45 !important;
      white-space:pre-wrap !important;
      box-shadow:inset 0 1px 1px rgba(15,23,42,.02) !important;
    }

    #cow-query-progress,
    #cow-repay-progress {
      min-height:170px !important;
      max-height:260px !important;
      overflow-y:auto !important;
      font-size:11px !important;
      line-height:1.5 !important;
      padding:9px !important;
      white-space:normal !important;
      border:1px solid #dde5ef !important;
      border-radius:10px !important;
      background:rgba(255,255,255,.88) !important;
    }

    #cow-repay-progress .cow-preview-main-line {
      font-size:11px !important;
      line-height:1.4 !important;
      margin:0 !important;
      transition:color .15s ease !important;
    }

    #cow-repay-progress .cow-preview-sub-line {
      padding-left:0 !important;
      font-size:11px !important;
      line-height:1.4 !important;
      margin:0 0 2px 0 !important;
    }

#cow-repay-progress .cow-preview-main-line.cow-preview-done {
      color:#16803a !important;
      font-weight:800 !important;
    }


    .cow-record-list {
      max-height:430px !important;
      overflow-y:auto !important;
      display:flex !important;
      flex-direction:column !important;
      gap:8px !important;
      color:#555 !important;
      font-size:11px !important;
      line-height:1.5 !important;
    }

    .cow-record-card {
      padding:10px 11px !important;
      border:1px solid #d9e2ec !important;
      border-radius:12px !important;
      background:linear-gradient(180deg,#ffffff 0%,#f8fbff 100%) !important;
      color:#334155 !important;
      white-space:pre-wrap !important;
      word-break:break-all !important;
      box-shadow:0 3px 10px rgba(15,23,42,.05) !important;
    }

    .cow-record-title {
      font-size:12px !important;
      font-weight:800 !important;
      color:#111 !important;
      margin-bottom:3px !important;
    }

    .cow-record-event {
      margin-top:2px !important;
      color:#16803a !important;
      font-weight:700 !important;
    }

.cow-section-gap {
      margin-top:12px !important;
    }

    .cow-captcha-list {
      display:flex !important;
      flex-direction:column !important;
      gap:7px !important;
    }

    .cow-captcha-row {
      display:grid !important;
      grid-template-columns:118px 1fr 96px !important;
      gap:5px !important;
      align-items:center !important;
    }

    .cow-captcha-name {
      font-size:11px !important;
      font-weight:700 !important;
      color:#333 !important;
    }

    .cow-code-input {
      width:100% !important;
      height:30px !important;
      padding:4px 7px !important;
      border:1px solid #ccc !important;
      border-radius:6px !important;
      background:#fff !important;
      color:#222 !important;
      font-size:11px !important;
      outline:none !important;
    }

    #cow-floating-root .cow-small-btn {
      height:30px !important;
      padding:0 6px !important;
      border:1px solid #222 !important;
      border-radius:6px !important;
      background:#222 !important;
      color:#fff !important;
      font-size:10px !important;
      cursor:pointer !important;
      white-space:nowrap !important;
    }

    #cow-floating-root .cow-secondary-btn {
      border-color:#bbb !important;
      background:#fff !important;
      color:#333 !important;
    }


    .cow-return-title-row {
      display:flex !important;
      align-items:center !important;
      justify-content:flex-start !important;
      gap:10px !important;
    }

    #cow-floating-root .cow-inline-btn {
      height:32px !important;
      min-width:72px !important;
      padding:0 16px !important;
      border:1px solid #222 !important;
      border-radius:6px !important;
      background:#222 !important;
      color:#fff !important;
      font-size:12px !important;
      font-weight:700 !important;
      cursor:pointer !important;
      line-height:30px !important;
      white-space:nowrap !important;
    }

  `;

  document.documentElement.appendChild(style);
  document.documentElement.appendChild(root);

  const grid = root.querySelector("#cow-grid");
  const status = root.querySelector("#cow-status");

  let cowPanelScale = 1;

  chrome.storage.local.get(["cowSelectedPlatforms", "cowPanelPosition", "cowPanelScale"], (data) => {
    const selected = Array.isArray(data.cowSelectedPlatforms) ? data.cowSelectedPlatforms : [];
    const savedScale = Number(data.cowPanelScale);
    cowPanelScale = Number.isFinite(savedScale) ? Math.max(0.75, Math.min(2, savedScale)) : 1;
    root.style.setProperty("--cow-scale", String(cowPanelScale));
    PLATFORM_ORDER.forEach(code => {
      const label = document.createElement("label");
      label.innerHTML = `<input type="checkbox" value="${code}" ${selected.includes(code) ? "checked" : ""}> <span>${code}</span>`;
      grid.appendChild(label);
    });

    if (data.cowPanelPosition && typeof data.cowPanelPosition.x === "number" && typeof data.cowPanelPosition.y === "number") {
      root.style.left = `${data.cowPanelPosition.x}px`;
      root.style.top = `${data.cowPanelPosition.y}px`;
      root.style.right = "auto";
    } else {
      const initialWidth = 410 * cowPanelScale;
      root.style.left = `${Math.max(0, window.innerWidth - initialWidth - 18)}px`;
      root.style.top = "70px";
      root.style.right = "auto";
    }
  });

  function saveSelection() {
    const selected = [...grid.querySelectorAll('input[type="checkbox"]:checked')].map(x => x.value);
    chrome.storage.local.set({ cowSelectedPlatforms: selected });
    return selected;
  }

  grid.addEventListener("change", saveSelection);

  root.querySelector("#cow-check-login").addEventListener("click", () => {
    const selected = saveSelection();

    if (!selected.length) {
      status.textContent = "請先選取至少一個平台";
      return;
    }

    const WG_CODES = ["XY", "OL", "LS", "XH"];
    const hasWG = selected.some(code => WG_CODES.includes(code));
    const normalSelected = selected.filter(code => !WG_CODES.includes(code));

    const urls = [
      { name: "MS", url: MS_URL },
      { name: "四方", url: SFP_URL },
      ...(hasWG ? [{ name: "WG", url: PLATFORM_URLS["XY"] }] : []),
      ...normalSelected.map(code => ({ name: code, url: PLATFORM_URLS[code] }))
    ];

    status.textContent = `正在開啟：MS、四方、${selected.join("、")}`;

    chrome.runtime.sendMessage({ type: "open_urls", urls }, (resp) => {
      if (chrome.runtime.lastError) {
        status.textContent = "開啟失敗：" + chrome.runtime.lastError.message;
        return;
      }
      status.textContent = `已開啟：MS、四方、${selected.join("、")}`;
    });
  });


  const COW_REPAY_RECORDS_KEY = "cowRepayRecords";
  const COW_REPAY_RECORDS_MAX = 200;
  let cowDraftStartedAt = null;
  let cowLastRecordedRawText = "";
  let cowCurrentRecordId = "";

  function cowNowMs() {
    return Date.now();
  }

  function cowFormatClock(ms) {
    if (!ms) return "";
    const d = new Date(ms);
    const hh = String(d.getHours()).padStart(2, "0");
    const mm = String(d.getMinutes()).padStart(2, "0");
    return `${hh}：${mm}`;
  }

  function cowGetRepayInputLine(rawText) {
    const lines = String(rawText || "")
      .replace(/\r/g, "\n")
      .split("\n")
      .map(x => x.trim())
      .filter(Boolean);
    return lines.find(line => /[補补]回\s*[0-9]+(?:\.[0-9]+)?/.test(line)) || "";
  }

  function cowStorageGetRecords() {
    return new Promise(resolve => {
      chrome.storage.local.get([COW_REPAY_RECORDS_KEY], data => {
        const list = Array.isArray(data[COW_REPAY_RECORDS_KEY]) ? data[COW_REPAY_RECORDS_KEY] : [];
        resolve(list);
      });
    });
  }

  function cowStorageSetRecords(records) {
    return new Promise(resolve => {
      chrome.storage.local.set({ [COW_REPAY_RECORDS_KEY]: records }, () => resolve());
    });
  }

  async function cowRenderRepayRecords() {
    const box = root.querySelector("#cow-repay-records");
    if (!box) return;
    const records = await cowStorageGetRecords();
    if (!records.length) {
      box.textContent = "尚无记录";
      return;
    }

    // 由上到下：最舊在上、最新在最下面。舊版本留下的記錄也依時間重新排序。
    const orderedRecords = [...records].sort((a, b) => Number(a?.createdAt || 0) - Number(b?.createdAt || 0));

    box.innerHTML = orderedRecords.map(record => {
      const lines = [];
      lines.push(`<div class="cow-record-title">出款失败补回 ${cowEsc(cowFormatClock(record.createdAt))}</div>`);
      if (record.dateText) lines.push(`<div>${cowEsc(record.dateText)}</div>`);
      lines.push(`<div>${cowEsc(record.platform || "")}\t${cowEsc(record.orderNo || "")}</div>`);
      lines.push(`<div>${cowEsc(record.member || "")}</div>`);
      lines.push(`<div>${cowEsc(record.repayLine || "")}</div>`);
      if (record.queryAt) lines.push(`<div class="cow-record-event">${cowEsc(cowFormatClock(record.queryAt))} 查询</div>`);
      if (record.operationAt) lines.push(`<div class="cow-record-event">${cowEsc(cowFormatClock(record.operationAt))} 操作</div>`);
      return `<div class="cow-record-card">${lines.join("")}</div>`;
    }).join("");

    // 補回記錄採「舊在上、新在下」排列；每次開啟或更新後自動停在最下面，
    // 讓最新一筆直接出現在視野內，不需要使用者手動往下拉。
    requestAnimationFrame(() => {
      box.scrollTop = box.scrollHeight;
    });
  }

  async function cowCreateRepayRecord(rawText, queryResponse) {
    if (!queryResponse || !queryResponse.ok) return;
    const parsed = queryResponse.parsed || {};
    const now = cowNowMs();
    const record = {
      id: `repay_${now}_${Math.random().toString(36).slice(2, 8)}`,
      createdAt: cowDraftStartedAt || now,
      dateText: String(parsed.dateText || "").trim(),
      platform: String(parsed.platform || "").trim(),
      orderNo: String(parsed.orderNo || "").trim(),
      member: String(parsed.member || "").trim(),
      repayLine: cowGetRepayInputLine(rawText) || `补回${cowFmt(parsed.repayAmount)}`,
      rawText: String(rawText || ""),
      queryAt: now,
      operationAt: null
    };

    // 先鎖定目前這筆，避免使用者查詢完成後立刻按操作時產生記錄競態。
    cowCurrentRecordId = record.id;
    cowLastRecordedRawText = String(rawText || "");
    cowDraftStartedAt = null;

    const records = await cowStorageGetRecords();
    records.push(record);
    records.sort((a, b) => Number(a?.createdAt || 0) - Number(b?.createdAt || 0));
    if (records.length > COW_REPAY_RECORDS_MAX) {
      records.splice(0, records.length - COW_REPAY_RECORDS_MAX);
    }
    await cowStorageSetRecords(records);
    await cowRenderRepayRecords();
  }

  async function cowMarkCurrentRecordOperated() {
    if (!cowCurrentRecordId) return;
    const records = await cowStorageGetRecords();
    const record = records.find(x => x && x.id === cowCurrentRecordId);
    if (!record) return;
    if (!record.operationAt) record.operationAt = cowNowMs();
    await cowStorageSetRecords(records);
    await cowRenderRepayRecords();
  }

  const cowRepayInputForRecord = root.querySelector("#cow-repay-input");
  if (cowRepayInputForRecord) {
    cowRepayInputForRecord.addEventListener("input", () => {
      const value = cowRepayInputForRecord.value.trim();
      if (!value) {
        cowDraftStartedAt = null;
        cowCurrentRecordId = "";
        cowLastRecordedRawText = "";
        return;
      }
      if (!cowDraftStartedAt && value !== cowLastRecordedRawText.trim()) {
        cowDraftStartedAt = cowNowMs();
        cowCurrentRecordId = "";
      }
    });
  }

  cowRenderRepayRecords();

  function setProgressDot(stepName, state) {
    const step = root.querySelector(`.cow-progress-step[data-step="${stepName}"]`);
    if (!step) return;
    step.classList.remove("done", "active");
    if (state === "done") step.classList.add("done");
    if (state === "active") step.classList.add("active");
  }

  function cowEsc(v) {
    return String(v == null ? "" : v)
      .replace(/&/g, "&amp;")
      .replace(/</g, "&lt;")
      .replace(/>/g, "&gt;")
      .replace(/"/g, "&quot;")
      .replace(/'/g, "&#39;");
  }

  function cowFmt(v) {
    if (v == null || v === "") return "";
    const n = Number(v);
    if (Number.isFinite(n)) {
      if (Math.abs(n - Math.trunc(n)) < 1e-9) return String(Math.trunc(n));
      return n.toFixed(8).replace(/0+$/, "").replace(/\.$/, "");
    }
    return String(v);
  }

  function cowShowQueryError(box, message) {
    if (!box) return;
    box.innerHTML = `<div style="color:red;font-weight:700;">${cowEsc(message || "查詢失敗")}</div>`;
  }

  function formatQueryResult(data) {
    if (!data) return "查詢失敗：沒有返回資料";
    if (!data.ok) return data.error || "查詢失敗";

    const p = data.preview || {};
    const systemFee = Number(p.systemFee) || 0;
    const payoutFeeRepay = Number(p.payoutFeeRepay) || 0;
    const splitText = p.isSplit ? (p.splitText || "") : "無拆帳";
    const warnCloud = systemFee > 0 || payoutFeeRepay > 0;

    const repayLine = p.isSpecial
      ? `<div style="color:red;font-weight:800;">補回：${cowEsc(cowFmt(p.rmbAmount))} (${cowEsc(cowFmt(p.repayAmount))}+${cowEsc(cowFmt(p.systemFee))}手續費)</div>`
      : `<div>補回：${cowEsc(cowFmt(p.repayAmount))}</div>`;

    return {
      html: [
        `<div>人民幣金額：${cowEsc(cowFmt(p.rmbAmount))}</div>`,
        `<div>實際出款：${cowEsc(cowFmt(p.actualPayout))}</div>`,
        `<div>拆帳：${cowEsc(splitText)}</div>`,
        repayLine,
        `<div${systemFee > 0 ? ' style="color:red;font-weight:700;"' : ''}>系統手續費：${cowEsc(cowFmt(p.systemFee))}</div>`,
        `<div${payoutFeeRepay > 0 ? ' style="color:red;font-weight:700;"' : ''}>出款手續費補回：${cowEsc(cowFmt(p.payoutFeeRepay))}</div>`,
        warnCloud ? `<div style="color:red;font-weight:800;font-size:20px;line-height:1.5;margin-top:4px;">請確認是否需要填寫雲端</div>` : ""
      ].join("")
    };
  }

  function formatRepayPreview(data) {
    if (!data || !data.ok) return "請先完成查詢";

    const p = data.preview || {};
    const platform = String(p.platform || (data.parsed && data.parsed.platform) || "").trim() || "平台";
    const platformAmount = Number(p.platformFirstAmount);
    const inputRepay = Number(p.repayAmount);
    const amountDifferent = Number.isFinite(platformAmount) && Number.isFinite(inputRepay)
      ? Math.abs(platformAmount - inputRepay) > 1e-9
      : String(p.platformFirstAmount) !== String(p.repayAmount);

    const platformAmountStyle = amountDifferent
      ? ' style="color:red;font-weight:800;"'
      : "";

    const secondAmount = p.needPlatformSecond ? cowFmt(p.platformSecondAmount) : "不需要";
    const secondRemark = p.needPlatformSecond ? (p.platformSecondRemark || "") : "不需要";

    return {
      html: [
        `<div id="cow-preview-ms" class="cow-preview-main-line"><b>1.MS 金額：${cowEsc(cowFmt(p.msAmount))}</b></div>`,
        `<div class="cow-preview-sub-line">備註：${cowEsc(p.msRemark || "")}</div>`,

                `<div id="cow-preview-sfp" class="cow-preview-main-line"><b>2.四方 金額：${cowEsc(cowFmt(p.sfpOrderAmount))}</b></div>`,
        `<div class="cow-preview-sub-line">備註：${cowEsc(p.effectiveDateText ? `${p.effectiveDateText} 保留原備註` : "保留原備註")}</div>`,

                `<div id="cow-preview-platform1" class="cow-preview-main-line"${platformAmountStyle}><b>3.${cowEsc(platform)}平台 金額：${cowEsc(cowFmt(p.platformFirstAmount))}</b></div>`,
        `<div class="cow-preview-sub-line">第一筆備註：${cowEsc(p.platformFirstRemark || "")}</div>`,

                `<div id="cow-preview-platform2" class="cow-preview-main-line"><b>4.平台手續費 金額：${cowEsc(secondAmount)}</b></div>`,
        `<div class="cow-preview-sub-line">第二筆備註：${cowEsc(secondRemark)}</div>`
      ].join("")
    };
  }

  function cowRenderRepayPreview(data) {
    const box = root.querySelector("#cow-repay-progress");
    if (!box) return;
    try {
      const formatted = formatRepayPreview(data);
      if (formatted && typeof formatted === "object" && formatted.html) {
        box.innerHTML = formatted.html;
      } else {
        box.textContent = formatted;
      }
    } catch (err) {
      box.textContent = "補回預覽顯示錯誤：" + (err && err.message ? err.message : String(err));
    }
  }

  function cowMarkPreviewLineDone(kind) {
    const idMap = {
      ms: "#cow-preview-ms",
      sfp: "#cow-preview-sfp",
      platform1: "#cow-preview-platform1",
      platform2: "#cow-preview-platform2"
    };
    const el = root.querySelector(idMap[kind] || "");
    if (el) el.classList.add("cow-preview-done");
  }

  let cowLastQueryResponse = null;
  let cowMsDoneForQuery = false;
  let cowSfpPreparedForQuery = false;
  let cowSfpDoneForQuery = false;
  let cowPlatformPreparedForQuery = false;

  const queryBtn = root.querySelector("#cow-query-btn");
  if (queryBtn) {
    queryBtn.addEventListener("click", () => {
      const box = root.querySelector("#cow-query-progress");
      const input = root.querySelector("#cow-repay-input");
      const rawText = input ? input.value.trim() : "";

      // 每次按查詢都視為全新一筆：進度條先歸零，舊查詢與操作狀態全部清除。
      ["query", "ms", "operate", "captcha"].forEach(step => setProgressDot(step, ""));
      cowLastQueryResponse = null;
      cowMsDoneForQuery = false;
      cowSfpPreparedForQuery = false;
      cowSfpDoneForQuery = false;
      cowPlatformPreparedForQuery = false;

      const repayBox = root.querySelector("#cow-repay-progress");
      if (repayBox) repayBox.textContent = "尚未開始";

      if (!rawText) {
        cowShowQueryError(box, "請先輸入補回資料");
        return;
      }

      queryBtn.disabled = true;
      queryBtn.textContent = "查詢中";
      if (box) box.textContent = "正在查詢四方...";
      setProgressDot("query", "active");

      chrome.runtime.sendMessage(
        { type: "cow_repay_query", text: rawText },
        (resp) => {
          queryBtn.disabled = false;
          queryBtn.textContent = "查詢";

          if (chrome.runtime.lastError) {
            cowShowQueryError(box, "查詢失敗：" + chrome.runtime.lastError.message);
            setProgressDot("query", "");
            return;
          }

          if (resp && resp.ok) {
            cowLastQueryResponse = resp;
            cowRenderRepayPreview(resp);
            cowCreateRepayRecord(rawText, resp).catch(() => {});
          } else {
            cowLastQueryResponse = null;
            const repayBox = root.querySelector("#cow-repay-progress");
            if (repayBox) repayBox.textContent = "尚未開始";
          }

          if (box) {
            try {
              const formatted = formatQueryResult(resp);
              if (formatted && typeof formatted === "object" && formatted.html) {
                box.innerHTML = formatted.html;
              } else if (resp && !resp.ok) {
                cowShowQueryError(box, formatted);
              } else {
                box.textContent = formatted;
              }
            } catch (err) {
              cowShowQueryError(box, "查詢結果顯示錯誤：" + (err && err.message ? err.message : String(err)));
            }
          }

          if (resp && resp.ok) {
            setProgressDot("query", "done");
          } else {
            setProgressDot("query", "");
          }
        }
      );
    });
  }

  const repayBtn = root.querySelector("#cow-repay-btn");
  if (repayBtn) {
    repayBtn.addEventListener("click", async () => {
      const repayBox = root.querySelector("#cow-repay-progress");

      if (!cowLastQueryResponse || !cowLastQueryResponse.ok) {
        if (repayBox) {
          repayBox.insertAdjacentHTML("beforeend",
            '<div style="color:red;font-weight:700;margin-top:4px;">請先完成查詢，再進行作帳</div>');
        }
        return;
      }

      cowRenderRepayPreview(cowLastQueryResponse);
      if (cowMsDoneForQuery) cowMarkPreviewLineDone("ms");
      if (cowSfpPreparedForQuery || cowSfpDoneForQuery) cowMarkPreviewLineDone("sfp");
      if (cowPlatformPreparedForQuery) {
        cowMarkPreviewLineDone("platform1");
        if (cowLastQueryResponse?.preview?.needPlatformSecond) cowMarkPreviewLineDone("platform2");
      }

      repayBtn.disabled = true;
      repayBtn.textContent = "操作中";
      setProgressDot("ms", cowMsDoneForQuery ? "done" : "active");
      setProgressDot("operate", "");
      setProgressDot("captcha", "");

      const send = payload => new Promise(resolve => {
        chrome.runtime.sendMessage(payload, resp => {
          if (chrome.runtime.lastError) {
            resolve({ok:false,error:chrome.runtime.lastError.message});
          } else {
            resolve(resp || {ok:false,error:"沒有回傳結果"});
          }
        });
      });

      // 使用統計：每次有效的「操作+MS作帳」點擊都算 1 次，並記錄平台。
      // 統計失敗不影響原本補回流程。
      void send({
        type:"cow_track_repay_click",
        platform:String(cowLastQueryResponse?.parsed?.platform || "").toUpperCase()
      });

      // Step 1: MS. If already successful for this query, never submit it again.
      if (!cowMsDoneForQuery) {
        const msResp = await send({ type:"cow_ms_repay_execute", lastQuery:cowLastQueryResponse });
        if (!msResp.ok) {
          if (repayBox) repayBox.insertAdjacentHTML("beforeend",
            `<div style="color:red;font-weight:700;margin-top:4px;">${cowEsc(msResp.error || "6.操作MS錯誤")}</div>`);
          repayBtn.disabled = false;
          repayBtn.textContent = "操作+MS作帳";
          return;
        }
        cowMsDoneForQuery = true;
        cowMarkPreviewLineDone("ms");
        setProgressDot("ms", "done");
      } else {
        setProgressDot("ms", "done");
      }

      // Step 2: 四方 + 平台操作到驗證碼頁面，驗證碼由使用者直接在各頁面人工輸入。
      setProgressDot("operate", "active");
      if (!cowSfpPreparedForQuery && !cowSfpDoneForQuery) {
        const sfpResp = await send({ type:"cow_sfp_repay_prepare", lastQuery:cowLastQueryResponse });
        if (!sfpResp.ok) {
          if (repayBox) repayBox.insertAdjacentHTML("beforeend",
            `<div style="color:red;font-weight:700;margin-top:4px;">${cowEsc(sfpResp.error || "7.操作四方錯誤")}</div>`);
          repayBtn.disabled = false;
          repayBtn.textContent = "操作+MS作帳";
          return;
        }
        cowSfpPreparedForQuery = true;
        cowMarkPreviewLineDone("sfp");
      }

      if (repayBox && cowSfpPreparedForQuery && !cowSfpDoneForQuery) {
        repayBox.insertAdjacentHTML("beforeend",
          '<div style="margin-top:4px;">四方補回頁面已操作完成，請至四方頁面人工輸入驗證碼</div>');
      }

      // 接著操作平台；平台同樣只操作到驗證碼畫面。
      // DY：XY/OL/LS/XH 共用 ManualDeposit；KR/TD 走標準平台流程。
      const platformCode = String(cowLastQueryResponse?.parsed?.platform || "").toUpperCase();
      const isWG = ["XY","OL","LS","XH"].includes(platformCode);

      if (!cowPlatformPreparedForQuery) {
        const platformResp = isWG
          ? await send({
              type:"cow_prepare_manual_deposit",
              lastQuery:cowLastQueryResponse
            })
          : await send({
              type:"cow_prepare_standard_platform",
              lastQuery:cowLastQueryResponse
            });

        if (!platformResp.ok) {
          if (repayBox) repayBox.insertAdjacentHTML("beforeend",
            `<div style="color:red;font-weight:700;margin-top:4px;">${cowEsc(platformResp.error || "8.操作平台錯誤")}</div>`);
          repayBtn.disabled = false;
          repayBtn.textContent = "操作+MS作帳";
          return;
        }

        cowPlatformPreparedForQuery = true;
        cowMarkPreviewLineDone("platform1");
        if (platformResp.needSecond) cowMarkPreviewLineDone("platform2");

        if (repayBox) {
          if (isWG) {
            if (platformResp.needSecond) {
              repayBox.insertAdjacentHTML("beforeend",
                `<div style="margin-top:4px;">${cowEsc(platformCode)} DY 已填好並送出兩筆：充值-USDT + 红利，請至平台頁面人工輸入兩組驗證碼</div>`);
            } else {
              repayBox.insertAdjacentHTML("beforeend",
                `<div style="margin-top:4px;">${cowEsc(platformCode)} DY 已填好並送出第一筆：充值-USDT，請至平台頁面人工輸入驗證碼</div>`);
            }
          } else if (platformResp.needSecond) {
            repayBox.insertAdjacentHTML("beforeend",
              `<div style="margin-top:4px;">${cowEsc(platformCode)} 已清除舊資料並填好兩筆，請至平台頁面人工輸入兩組驗證碼</div>`);
          } else {
            repayBox.insertAdjacentHTML("beforeend",
              `<div style="margin-top:4px;">${cowEsc(platformCode)} 已清除舊資料並填好第一筆，請至平台頁面人工輸入驗證碼</div>`);
          }
        }
      }

      // 四方與平台都已操作到驗證碼頁面。
      setProgressDot("operate", "done");
      setProgressDot("captcha", "active");
      await cowMarkCurrentRecordOperated();

      repayBtn.disabled = false;
      repayBtn.textContent = "操作+MS作帳";
    });
  }

  root.querySelectorAll(".cow-tab").forEach(tab => {
    tab.addEventListener("click", () => {
      root.querySelectorAll(".cow-tab").forEach(x => x.classList.remove("active"));
      root.querySelectorAll(".cow-page").forEach(x => x.classList.remove("active"));
      tab.classList.add("active");
      root.querySelector(`.cow-page[data-page="${tab.dataset.tab}"]`).classList.add("active");
      if (tab.dataset.tab === "settings") cowRenderRepayRecords().catch(() => {});
    });
  });

  root.querySelector("#cow-close").addEventListener("click", () => {
    root.style.display = "none";
  });

  const minBtn = root.querySelector("#cow-min");
  let minimized = false;
  let suppressMinClick = false;

  function cowSavePanelPosition() {
    const rect = root.getBoundingClientRect();
    chrome.storage.local.set({
      cowPanelPosition: { x: Math.round(rect.left), y: Math.round(rect.top) },
      cowPanelScale
    });
  }

  function cowKeepInsideViewport() {
    const rect = root.getBoundingClientRect();
    let x = rect.left;
    let y = rect.top;
    if (rect.right > window.innerWidth) x -= (rect.right - window.innerWidth);
    if (rect.bottom > window.innerHeight && rect.height < window.innerHeight) y -= (rect.bottom - window.innerHeight);
    x = Math.max(0, x);
    y = Math.max(0, y);
    root.style.left = `${x}px`;
    root.style.top = `${y}px`;
    root.style.right = "auto";
  }

  function cowApplyMinimizedState() {
    const beforeRect = root.getBoundingClientRect();

    if (minimized) {
      // 缩小时直接对准原本「缩小」按钮的位置，让用户马上找到。
      const minRect = minBtn.getBoundingClientRect();
      const miniSize = 38;
      const miniX = Math.max(0, Math.min(window.innerWidth - miniSize, minRect.left + (minRect.width - miniSize) / 2));
      const miniY = Math.max(0, Math.min(window.innerHeight - miniSize, minRect.top + (minRect.height - miniSize) / 2));

      root.classList.add("cow-mini");
      root.style.left = `${miniX}px`;
      root.style.top = `${miniY}px`;
      root.style.right = "auto";

      minBtn.textContent = "補";
      minBtn.title = "拖曳移動｜點擊展開 COW";
      minBtn.setAttribute("aria-label", "拖曳移動，點擊展開 COW");
    } else {
      // 展开时仍以「補」图示的右边为基准，往左展开，避免超出右侧画面。
      const miniRect = beforeRect;
      root.classList.remove("cow-mini");
      root.style.setProperty("--cow-scale", String(cowPanelScale));

      const targetWidth = 410 * cowPanelScale;
      let targetLeft = miniRect.right - targetWidth;
      let targetTop = miniRect.top;

      targetLeft = Math.max(0, Math.min(Math.max(0, window.innerWidth - targetWidth), targetLeft));
      targetTop = Math.max(0, targetTop);

      root.style.left = `${targetLeft}px`;
      root.style.top = `${targetTop}px`;
      root.style.right = "auto";

      minBtn.textContent = "—";
      minBtn.title = "縮小";
      minBtn.setAttribute("aria-label", "縮小");
    }

    requestAnimationFrame(() => {
      cowKeepInsideViewport();
      cowSavePanelPosition();
    });
  }

  minBtn.addEventListener("click", (e) => {
    if (suppressMinClick) {
      suppressMinClick = false;
      e.preventDefault();
      e.stopPropagation();
      return;
    }
    minimized = !minimized;
    cowApplyMinimizedState();
  });

  cowApplyMinimizedState();

  const dragbar = root.querySelector("#cow-dragbar");
  let dragging = false, dx = 0, dy = 0;

  dragbar.addEventListener("mousedown", (e) => {
    if (e.target.closest("button")) return;
    dragging = true;
    const rect = root.getBoundingClientRect();
    dx = e.clientX - rect.left;
    dy = e.clientY - rect.top;
    root.style.right = "auto";
    e.preventDefault();
  });

  // 縮小後的「補」圖示可以直接拖曳移動。
  let miniDrag = null;
  minBtn.addEventListener("mousedown", (e) => {
    if (!minimized || e.button !== 0) return;
    const rect = root.getBoundingClientRect();
    miniDrag = {
      startX:e.clientX,
      startY:e.clientY,
      dx:e.clientX - rect.left,
      dy:e.clientY - rect.top,
      moved:false
    };
    root.style.right = "auto";
    e.preventDefault();
  });

  // 左上 / 右上 / 左下 / 右下都可拖曳缩放；字体与内容一起等比例变化。
  const resizeTopLeft = root.querySelector("#cow-resize-top-left");
  const resizeTopRight = root.querySelector("#cow-resize-top-right");
  const resizeLeft = root.querySelector("#cow-resize-left");
  const resizeRight = root.querySelector("#cow-resize-right");
  let resizeState = null;

  function cowBeginResize(corner, e) {
    if (minimized || e.button !== 0) return;
    const rect = root.getBoundingClientRect();
    root.style.left = `${rect.left}px`;
    root.style.top = `${rect.top}px`;
    root.style.right = "auto";

    resizeState = {
      corner,
      startX:e.clientX,
      startY:e.clientY,
      startScale:cowPanelScale,
      startWidth:rect.width,
      startHeight:rect.height,
      baseHeight:rect.height / Math.max(0.01, cowPanelScale),
      startLeft:rect.left,
      startTop:rect.top,
      rightEdge:rect.right,
      bottomEdge:rect.bottom
    };

    e.preventDefault();
    e.stopPropagation();
  }

  resizeTopLeft.addEventListener("mousedown", e => cowBeginResize("tl", e));
  resizeTopRight.addEventListener("mousedown", e => cowBeginResize("tr", e));
  resizeLeft.addEventListener("mousedown", e => cowBeginResize("bl", e));
  resizeRight.addEventListener("mousedown", e => cowBeginResize("br", e));

  document.addEventListener("mousemove", (e) => {
    if (resizeState) {
      const isLeft = resizeState.corner === "tl" || resizeState.corner === "bl";
      const isTop = resizeState.corner === "tl" || resizeState.corner === "tr";

      const rawHorizontal = isLeft
        ? (resizeState.startX - e.clientX)
        : (e.clientX - resizeState.startX);

      const rawVertical = isTop
        ? (resizeState.startY - e.clientY)
        : (e.clientY - resizeState.startY);

      const horizontalScale = (resizeState.startWidth + rawHorizontal) / 410;
      const verticalScale = (resizeState.startHeight + rawVertical) / resizeState.baseHeight;
      let nextScale = (horizontalScale + verticalScale) / 2;

      const maxScaleX = isLeft
        ? (resizeState.rightEdge - 4) / 410
        : (window.innerWidth - resizeState.startLeft - 4) / 410;

      const maxScaleY = isTop
        ? (resizeState.bottomEdge - 4) / resizeState.baseHeight
        : (window.innerHeight - resizeState.startTop - 4) / resizeState.baseHeight;

      nextScale = Math.max(0.75, Math.min(2, maxScaleX, maxScaleY, nextScale));
      cowPanelScale = nextScale;
      root.style.setProperty("--cow-scale", String(cowPanelScale));

      const newWidth = 410 * cowPanelScale;
      const newHeight = resizeState.baseHeight * cowPanelScale;

      if (isLeft) {
        root.style.left = `${Math.max(0, resizeState.rightEdge - newWidth)}px`;
      } else {
        root.style.left = `${resizeState.startLeft}px`;
      }

      if (isTop) {
        root.style.top = `${Math.max(0, resizeState.bottomEdge - newHeight)}px`;
      } else {
        root.style.top = `${resizeState.startTop}px`;
      }
      return;
    }

    if (miniDrag) {
      if (Math.hypot(e.clientX - miniDrag.startX, e.clientY - miniDrag.startY) > 4) {
        miniDrag.moved = true;
        suppressMinClick = true;
      }
      if (miniDrag.moved) {
        const rect = root.getBoundingClientRect();
        const x = Math.max(0, Math.min(window.innerWidth - rect.width, e.clientX - miniDrag.dx));
        const y = Math.max(0, Math.min(window.innerHeight - rect.height, e.clientY - miniDrag.dy));
        root.style.left = `${x}px`;
        root.style.top = `${y}px`;
      }
      return;
    }

    if (!dragging) return;
    const rect = root.getBoundingClientRect();
    const x = Math.max(0, Math.min(window.innerWidth - rect.width, e.clientX - dx));
    const y = Math.max(0, Math.min(window.innerHeight - Math.min(40, rect.height), e.clientY - dy));
    root.style.left = `${x}px`;
    root.style.top = `${y}px`;
  });

  document.addEventListener("mouseup", () => {
    if (resizeState) {
      resizeState = null;
      cowKeepInsideViewport();
      cowSavePanelPosition();
    }

    if (miniDrag) {
      if (miniDrag.moved) cowSavePanelPosition();
      miniDrag = null;
    }

    if (dragging) {
      dragging = false;
      cowSavePanelPosition();
    }
  });

  window.addEventListener("resize", () => {
    cowKeepInsideViewport();
  });
})();
