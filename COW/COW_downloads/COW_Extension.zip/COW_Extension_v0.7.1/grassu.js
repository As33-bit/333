(() => {
  'use strict';

  const root = document.getElementById('cow-floating-root');
  if (!root) return;
  if (root.querySelector('.cow-tab[data-tab="grassu"]')) return;

  const tabs = root.querySelector('#cow-tabs');
  const body = root.querySelector('#cow-body');
  if (!tabs || !body) return;

  const tab = document.createElement('button');
  tab.className = 'cow-tab';
  tab.dataset.tab = 'grassu';
  tab.textContent = '草换U作帐';
  tabs.appendChild(tab);

  const page = document.createElement('div');
  page.className = 'cow-page cow-grassu-page';
  page.dataset.page = 'grassu';
  page.innerHTML = `
    <div class="gu-title-row">
      <div class="gu-title-stack">
        <div class="cow-section-title gu-section-title">草换U作帐</div>
        <label class="gu-label gu-title-label" for="gu-input">输入资料</label>
      </div>
      <div class="gu-rate-wrap">
        <span>汇率</span>
        <input id="gu-rate" class="gu-input gu-rate-input" type="text" value="6.9" inputmode="decimal" />
      </div>
    </div>

    <textarea id="gu-input" class="gu-textarea" rows="4" placeholder="贴上草换U / U换草资料"></textarea>

    <div class="gu-actions">
      <button id="gu-parse" class="gu-primary" type="button">解析</button>
      <button id="gu-clear" class="gu-secondary" type="button">清空</button>
    </div>

    <button id="gu-start" class="gu-start" type="button" disabled>开始作帐</button>

    <button id="gu-cloud-copy" class="gu-cloud-copy" type="button" disabled>点我复制以下容 即可 贴上云端</button>
    <div id="gu-cloud-box" class="gu-cloud-box" tabindex="0"><pre id="gu-cloud-text">解析成功后自动生成云端内容</pre></div>

    <div class="gu-divider"></div>

    <div class="gu-result-head">
      <div class="cow-section-title gu-result-title">解析结果</div>
      <span id="gu-demo-tag">等待解析</span>
    </div>

    <div id="gu-results" class="gu-results">
      <div class="gu-empty">输入资料后点击「解析」</div>
    </div>

    <div class="gu-status"><span class="gu-dot"></span> MS工作页：尚未建立</div>
  `;
  body.appendChild(page);

  const style = document.createElement('style');
  style.id = 'cow-grassu-style';
  style.textContent = `
    #cow-tabs { grid-template-columns: .9fr 1.34fr 1.28fr .78fr 1fr !important; }
    #cow-tabs .cow-tab { padding-left:4px !important; padding-right:4px !important; font-size:10px !important; }
    #cow-floating-root .cow-grassu-page { padding-top:1px !important; }
    #cow-floating-root .gu-title-row { display:flex !important; align-items:flex-start !important; justify-content:space-between !important; gap:10px !important; margin-bottom:5px !important; }
    #cow-floating-root .gu-title-row .gu-section-title { margin-bottom:0 !important; }
    #cow-floating-root .gu-title-stack { display:flex !important; flex-direction:column !important; align-items:flex-start !important; min-width:0 !important; }
    #cow-floating-root .gu-title-label { margin:4px 0 0 !important; }
    #cow-floating-root .gu-rate-wrap { display:flex !important; align-items:center !important; gap:6px !important; color:#475569 !important; font-size:10px !important; font-weight:800 !important; white-space:nowrap !important; }
    #cow-floating-root .gu-rate-input { width:78px !important; height:30px !important; padding:4px 8px !important; text-align:center !important; font-weight:800 !important; }
    #cow-floating-root .gu-label { display:block !important; font-size:11px !important; font-weight:700 !important; color:#475569 !important; margin:8px 0 5px !important; }
    #cow-floating-root .gu-input, #cow-floating-root .gu-textarea {
      width:100% !important; border:1px solid #cfd8e5 !important; border-radius:9px !important;
      background:#fff !important; color:#111827 !important; outline:none !important;
      font:12px/1.5 Arial,"Microsoft JhengHei",sans-serif !important;
      box-shadow: inset 0 1px 2px rgba(15,23,42,.03) !important;
    }
    #cow-floating-root .gu-input { height:36px !important; padding:7px 10px !important; }
    #cow-floating-root .gu-textarea { min-height:78px !important; padding:9px 10px !important; resize:vertical !important; }
    #cow-floating-root .gu-input:focus, #cow-floating-root .gu-textarea:focus { border-color:#64748b !important; box-shadow:0 0 0 3px rgba(100,116,139,.10) !important; }
    #cow-floating-root .gu-actions { display:grid !important; grid-template-columns:1fr .72fr !important; gap:8px !important; margin-top:9px !important; }
    #cow-floating-root .gu-actions button, #cow-floating-root .gu-start { height:36px !important; border-radius:9px !important; font-size:12px !important; font-weight:800 !important; cursor:pointer !important; }
    #cow-floating-root .gu-primary { border:1px solid #1f2937 !important; background:#1f2937 !important; color:#fff !important; }
    #cow-floating-root .gu-secondary { border:1px solid #d4dce7 !important; background:#fff !important; color:#475569 !important; }
    #cow-floating-root .gu-primary:hover { background:#111827 !important; }
    #cow-floating-root .gu-secondary:hover { background:#f8fafc !important; }
    #cow-floating-root .gu-start { width:100% !important; margin-top:8px !important; border:1px solid #cbd5e1 !important; background:#e7ecf2 !important; color:#94a3b8 !important; cursor:not-allowed !important; }
    #cow-floating-root .gu-start:not(:disabled) { border-color:#1f2937 !important; background:#1f2937 !important; color:#fff !important; cursor:pointer !important; }
    #cow-floating-root .gu-start:not(:disabled):hover { background:#111827 !important; }
    #cow-floating-root .gu-cloud-copy { width:100% !important; height:34px !important; margin-top:8px !important; border:1px solid #2563eb !important; border-radius:9px !important; background:#eff6ff !important; color:#1d4ed8 !important; font-size:11px !important; font-weight:900 !important; cursor:pointer !important; }
    #cow-floating-root .gu-cloud-copy:disabled { border-color:#d7dee8 !important; background:#f3f5f8 !important; color:#9aa6b6 !important; cursor:not-allowed !important; }
    #cow-floating-root .gu-cloud-copy:not(:disabled):hover { background:#dbeafe !important; }
    #cow-floating-root .gu-cloud-box { width:100% !important; min-height:62px !important; max-height:150px !important; margin-top:7px !important; border:1px solid #cfd8e5 !important; border-radius:9px !important; background:#fff !important; overflow-x:auto !important; overflow-y:auto !important; cursor:default !important; box-shadow: inset 0 1px 2px rgba(15,23,42,.03) !important; }
    #cow-floating-root #gu-cloud-text { margin:0 !important; padding:9px 10px !important; min-width:max-content !important; white-space:pre !important; word-break:normal !important; overflow-wrap:normal !important; font:11px/1.55 Consolas,Monaco,"Microsoft JhengHei",monospace !important; color:#334155 !important; user-select:text !important; }
    #cow-floating-root .gu-divider { height:1px !important; background:#dfe6ef !important; margin:13px 0 11px !important; }
    #cow-floating-root .gu-result-head { display:flex !important; align-items:center !important; justify-content:space-between !important; gap:8px !important; }
    #cow-floating-root .gu-result-title { margin:0 !important; }
    #cow-floating-root #gu-demo-tag { font-size:9px !important; font-weight:800 !important; color:#64748b !important; background:#e8eef5 !important; border-radius:999px !important; padding:3px 7px !important; }
    #cow-floating-root #gu-demo-tag.ok { color:#166534 !important; background:#dcfce7 !important; }
    #cow-floating-root #gu-demo-tag.bad { color:#991b1b !important; background:#fee2e2 !important; }
    #cow-floating-root .gu-results { margin-top:9px !important; }
    #cow-floating-root .gu-empty { padding:16px 10px !important; text-align:center !important; color:#94a3b8 !important; font-size:11px !important; border:1px dashed #cbd5e1 !important; border-radius:9px !important; background:#fff !important; }
    #cow-floating-root .gu-item { padding:10px 1px 11px !important; border-bottom:1px solid #e0e6ee !important; }
    #cow-floating-root .gu-item:last-child { border-bottom:0 !important; }
    #cow-floating-root .gu-item-title { font-size:12px !important; font-weight:900 !important; color:#111827 !important; margin-bottom:4px !important; }
    #cow-floating-root .gu-warning { font-size:11px !important; font-weight:800 !important; color:#b45309 !important; margin:2px 0 5px !important; }
    #cow-floating-root .gu-error { font-size:11px !important; font-weight:800 !important; color:#b91c1c !important; margin:2px 0 5px !important; }
    #cow-floating-root .gu-route { font-size:12px !important; font-weight:800 !important; color:#334155 !important; margin-bottom:5px !important; word-break:break-word !important; }
    #cow-floating-root .gu-row { font-size:11px !important; color:#475569 !important; line-height:1.58 !important; }
    #cow-floating-root .gu-row strong { display:inline-block !important; min-width:48px !important; color:#334155 !important; }
    #cow-floating-root .gu-status { text-align:center !important; margin-top:8px !important; color:#64748b !important; font-size:9px !important; }
    #cow-floating-root .gu-dot { display:inline-block !important; width:7px !important; height:7px !important; border-radius:50% !important; background:#94a3b8 !important; margin-right:4px !important; }
    #cow-floating-root .gu-dot.gu-dot-ok { background:#16a34a !important; }
    #cow-floating-root .gu-dot.gu-dot-bad { background:#dc2626 !important; }
  `;
  document.documentElement.appendChild(style);

  tab.addEventListener('click', () => {
    root.querySelectorAll('.cow-tab').forEach(x => x.classList.remove('active'));
    root.querySelectorAll('.cow-page').forEach(x => x.classList.remove('active'));
    tab.classList.add('active');
    page.classList.add('active');
  });

  const $ = (s) => page.querySelector(s);
  const rate = $('#gu-rate');
  const input = $('#gu-input');
  const results = $('#gu-results');
  const startBtn = $('#gu-start');
  const cloudCopyBtn = $('#gu-cloud-copy');
  const cloudText = $('#gu-cloud-text');
  let lastParsed = null;
  let lastOperator = '';
  let cloudBuildToken = 0;

  function esc(v) {
    return String(v).replace(/[&<>\"']/g, (c) => ({'&':'&amp;','<':'&lt;','>':'&gt;','\"':'&quot;',"'":'&#39;'}[c]));
  }
  function cnIndex(i) {
    const c = ['一','二','三','四','五','六','七','八','九','十'];
    return i <= 10 ? c[i - 1] : String(i);
  }
  function guCloudDate() {
    const d = new Date();
    return `${d.getMonth() + 1}/${d.getDate()}`;
  }
  function guFixed6(v) {
    const n = Number(v);
    return Number.isFinite(n) ? n.toFixed(6) : '0.000000';
  }
  function guRateText(v) {
    const raw = String(v == null ? '' : v).trim();
    if (raw) return raw;
    const n = Number(v);
    return Number.isFinite(n) ? String(n) : '';
  }
  function guBuildCloudText(parsed, operator) {
    if (!parsed?.ok || !Array.isArray(parsed.items) || !parsed.items.length) return '';
    const who = String(operator || '').trim() || '无法识别';
    const date = guCloudDate();
    const lines = [];
    for (const it of parsed.items) {
      const platform = String(it?.platform || 'OL').trim().toUpperCase() || 'OL';
      const rmb = Number(it?.rmb || 0);
      const virtual = Number(it?.virtual || 0);
      const rateText = guRateText(it?.rate);
      if (it?.type === '草换U') {
        lines.push(`${date}\t\t向${platform}借款\t${guFixed6(Math.abs(rmb))}\t${guFixed6(Math.abs(virtual))}\t${rateText}\t${who}`);
        lines.push(`${date}\t\t草换U\t${guFixed6(-Math.abs(rmb))}\t${guFixed6(-Math.abs(virtual))}\t${rateText}\t${who}`);
      } else if (it?.type === 'U换草') {
        lines.push(`${date}\t\tU换草\t${guFixed6(Math.abs(rmb))}\t${guFixed6(Math.abs(virtual))}\t${rateText}\t${who}`);
        lines.push(`${date}\t\t借款给${platform}\t${guFixed6(-Math.abs(rmb))}\t${guFixed6(-Math.abs(virtual))}\t${rateText}\t${who}`);
      }
    }
    return lines.join('\n');
  }

  async function guRefreshCloudContent(parsed) {
    const token = ++cloudBuildToken;
    cloudCopyBtn.disabled = true;
    cloudText.textContent = parsed?.ok ? '正在读取 MS 操作者...' : '解析成功后自动生成云端内容';
    if (!parsed?.ok) return;
    let operator = '';
    try {
      const resp = await chrome.runtime.sendMessage({type:'grassUGetCloudOperator'});
      operator = String(resp?.operator || '').trim();
    } catch (_) {}
    if (token !== cloudBuildToken) return;
    lastOperator = operator;
    const txt = guBuildCloudText(parsed, operator);
    cloudText.textContent = txt || '无法生成云端内容';
    cloudCopyBtn.disabled = !txt || !operator;
    cloudCopyBtn.title = operator ? `操作者：${operator}` : '无法识别 MS 右上角操作者';
  }

  function renderParsed() {
    startBtn.disabled = true;
    cloudCopyBtn.disabled = true;
    cloudText.textContent = '解析成功后自动生成云端内容';
    if (!input.value.trim()) {
      results.innerHTML = '<div class="gu-empty">请先输入资料</div>';
      return;
    }
    if (!globalThis.GrassUParser) {
      results.innerHTML = '<div class="gu-empty">解析器载入失败，请重新载入套件</div>';
      return;
    }
    const parsed = globalThis.GrassUParser.parse(input.value, {defaultRate: rate.value.trim() || '6.9'});
    lastParsed = parsed;
    let html = '';
    if (parsed.globalErrors.length) {
      html += `<div class="gu-item gu-global-error">${parsed.globalErrors.map(e => `<div class="gu-error">⚠ ${esc(e)}</div>`).join('')}</div>`;
    }
    parsed.items.forEach((it, idx) => {
      html += '<div class="gu-item">';
      html += `<div class="gu-item-title">${cnIndex(idx + 1)}. ${esc(it.type)}</div>`;
      it.warnings.forEach(w => { html += `<div class="gu-warning">⚠ ${esc(w)}</div>`; });
      it.errors.forEach(e => { html += `<div class="gu-error">❌ ${esc(e)}</div>`; });
      html += `<div class="gu-route">${esc(it.route)}</div>`;
      html += `<div class="gu-row"><strong>虚拟币：</strong>${esc(globalThis.GrassUParser.fmt(it.virtual, 12))}</div>`;
      html += `<div class="gu-row"><strong>汇率：</strong>${esc(globalThis.GrassUParser.fmt(it.rate, 8))}</div>`;
      html += `<div class="gu-row"><strong>人民币：</strong>${esc(globalThis.GrassUParser.fmt(it.rmb, 8))}</div>`;
      html += '</div>';
    });
    if (!html) html = '<div class="gu-empty">没有找到可拆解的作帐资料</div>';
    results.innerHTML = html;
    startBtn.disabled = !parsed.ok;
    const tag = $('#gu-demo-tag');
    tag.textContent = parsed.ok ? '解析成功' : '解析失败';
    tag.classList.toggle('ok', parsed.ok);
    tag.classList.toggle('bad', !parsed.ok);
    guRefreshCloudContent(parsed);
  }

  $('#gu-parse').addEventListener('click', renderParsed);
  $('#gu-clear').addEventListener('click', () => {
    input.value = '';
    lastParsed = null;
    lastOperator = '';
    cloudBuildToken++;
    startBtn.disabled = true;
    cloudCopyBtn.disabled = true;
    cloudText.textContent = '解析成功后自动生成云端内容';
    results.innerHTML = '<div class="gu-empty">输入资料后点击「解析」</div>';
    const tag = $('#gu-demo-tag');
    tag.textContent = '等待解析';
    tag.classList.remove('ok','bad');
  });

  cloudCopyBtn.addEventListener('click', async () => {
    if (cloudCopyBtn.disabled) return;
    const text = String(cloudText.textContent || '');
    if (!text.trim()) return;
    const old = cloudCopyBtn.textContent;
    try {
      await navigator.clipboard.writeText(text);
      cloudCopyBtn.textContent = '已复制，可直接贴上云端';
      setTimeout(() => { cloudCopyBtn.textContent = old; }, 1400);
    } catch (_) {
      try {
        const ta = document.createElement('textarea');
        ta.value = text;
        ta.style.position = 'fixed';
        ta.style.opacity = '0';
        document.body.appendChild(ta);
        ta.select();
        document.execCommand('copy');
        ta.remove();
        cloudCopyBtn.textContent = '已复制，可直接贴上云端';
        setTimeout(() => { cloudCopyBtn.textContent = old; }, 1400);
      } catch (_) {
        cloudCopyBtn.textContent = '复制失败，请手动复制框内内容';
        setTimeout(() => { cloudCopyBtn.textContent = old; }, 1800);
      }
    }
  });

  chrome.runtime.onMessage.addListener((msg) => {
    if (msg?.type !== 'grassUProgress') return;
    const status = page.querySelector('.gu-status');
    if (!status) return;
    if (msg.stage === 'running') {
      status.innerHTML = '<span class="gu-dot"></span> ' + esc(msg.text || '正在作帐');
      startBtn.textContent = `作帐中 ${msg.stepNo || ''}/${msg.totalSteps || ''}`;
    } else if (msg.stage === 'ms_ready') {
      status.innerHTML = '<span class="gu-dot gu-dot-ok"></span> ' + esc(msg.text || 'MS 工作页已准备完成');
    } else if (msg.stage === 'failed') {
      status.innerHTML = '<span class="gu-dot gu-dot-bad"></span> ❌ ' + esc(msg.text || '作帐失败');
    } else if (msg.stage === 'done') {
      status.innerHTML = '<span class="gu-dot gu-dot-ok"></span> ' + esc(msg.text || '作帐完成');
    }
  });

  startBtn.addEventListener('click', async () => {
    if (startBtn.disabled || !lastParsed?.ok) return;
    const status = page.querySelector('.gu-status');
    const oldText = startBtn.textContent;
    startBtn.disabled = true;
    startBtn.textContent = '准备 MS...';
    if (status) status.innerHTML = '<span class="gu-dot"></span> 正在复制 / 准备用户 MS 页面';
    try {
      const resp = await chrome.runtime.sendMessage({type:'grassUStartAccounting', items:lastParsed.items || []});
      if (!resp?.ok) {
        if (status) status.innerHTML = '<span class="gu-dot gu-dot-bad"></span> ❌ ' + esc(resp?.error || '作帐失败');
        if ((resp?.submittedCount || 0) > 0 || resp?.ambiguous) {
          startBtn.textContent = '部分完成｜请人工检查';
          startBtn.disabled = true;
        } else {
          startBtn.textContent = oldText;
          startBtn.disabled = false;
        }
        return;
      }
      if (status) status.innerHTML = '<span class="gu-dot gu-dot-ok"></span> 作帐完成：' + esc(String(resp.itemCount || lastParsed.items.length)) + ' 笔';
      startBtn.textContent = '开始作帐';
      startBtn.disabled = true;
    } catch (e) {
      if (status) status.innerHTML = '<span class="gu-dot gu-dot-bad"></span> ❌ ' + esc(e?.message || e);
      startBtn.textContent = oldText;
      startBtn.disabled = false;
    }
  });
})();
