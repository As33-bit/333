(() => {
  'use strict';

  const CHAINS = ['TRC', 'ERC', 'BSC', 'TON', 'SOL'];
  const UNSUPPORTED_PLATFORMS = ['TD','XO','XY','LS','XH','RF','HS','YD','YS','SH','JY','JD','MT','FB'];
  const S_ALIASES = ['DD仓库','DD倉庫','DD仓','DD倉','HS仓','HS倉','S仓','S倉'];

  const BANKS = {
    hardware: {
      TRC: 'OL TRC-USDT - 人民币',
      ERC: 'OL USDT - 人民币',
      BSC: 'OL BSC-USDT - 人民币',
      TON: 'OL TON-USDT - 人民币',
      SOL: 'OL SOL - 人民币'
    },
    flow1: {
      TRC: 'OL TRC - 分流1',
      ERC: 'OL ERC - 分流1',
      BSC: 'OL BSC - 分流1',
      TON: 'OL TON - 分流1',
      SOL: 'OL SOL - 分流1'
    },
    flow2: {
      TRC: 'OL TRC - 分流2'
    },
    ndHardware: {
      TRC: 'ND TUSDT - 人民币',
      ERC: 'ND USDT - 人民币',
      BSC: 'ND BSCUSDT - 人民币',
      TON: 'ND TONUSDT - 人民币',
      SOL: 'ND SOL - 人民币'
    }
  };

  function findUnsupportedPlatforms(text) {
    const src = String(text ?? '');
    const found = new Set();
    for (const code of UNSUPPORTED_PLATFORMS) {
      const re = new RegExp(`(^|[^A-Z0-9])${code}(?=$|[^A-Z0-9])`, 'gi');
      let m;
      while ((m = re.exec(src))) {
        const start = m.index + (m[1] ? m[1].length : 0);
        // HS仓 / HS倉 是 S仓既有别名，不视为其他平台。
        if (code === 'HS' && /^\s*[仓倉]/.test(src.slice(start + code.length))) continue;
        found.add(code);
      }
    }
    return [...found];
  }

  function normText(s) {
    return String(s ?? '')
      .replace(/\r\n?/g, '\n')
      .replace(/[＞》]/g, '>')
      .replace(/[➡➜➝⇒]/g, '→')
      .replace(/[＊×✕]/g, '*')
      .replace(/[÷]/g, '/')
      .replace(/，/g, ',')
      .replace(/：/g, ':')
      .replace(/\u00A0/g, ' ');
  }

  function trunc(value, digits) {
    const p = Math.pow(10, digits);
    const n = Number(value);
    if (!Number.isFinite(n)) return NaN;
    return Math.trunc((n + Number.EPSILON) * p) / p;
  }

  function fmt(n, maxDigits = 12) {
    if (!Number.isFinite(Number(n))) return '';
    let s = Number(n).toFixed(maxDigits);
    s = s.replace(/\.0+$/, '').replace(/(\.\d*?)0+$/, '$1');
    return s;
  }

  function parseNumeric(raw, unit = '') {
    const n = Number(String(raw).replace(/,/g, ''));
    if (!Number.isFinite(n)) return NaN;
    if (/[wW万萬]/.test(unit)) return n * 10000;
    return n;
  }

  function getNumMatches(line) {
    const re = /(?:\d{1,3}(?:,\d{3})+|\d+)(?:\.\d+)?\s*(?:[wW万萬](?:颗|顆)?|颗|顆)?/g;
    const out = [];
    let m;
    while ((m = re.exec(line))) {
      const full = m[0];
      const before = line.slice(Math.max(0, m.index - 4), m.index);
      if (/分流\s*$/.test(before)) continue;
      const nm = full.match(/^\s*((?:\d{1,3}(?:,\d{3})+|\d+)(?:\.\d+)?)\s*(.*)$/);
      if (!nm) continue;
      const unit = nm[2] || '';
      out.push({ raw: full.trim(), numRaw: nm[1], unit, value: parseNumeric(nm[1], unit), start: m.index, end: m.index + full.length });
    }
    return out;
  }

  function isPureRateLine(line) {
    const t = line.trim();
    if (!/^\d+(?:\.\d+)?$/.test(t)) return null;
    const n = Number(t);
    return n >= 5 && n <= 10 ? n : null;
  }

  function explicitRate(line) {
    const m = line.match(/汇率\s*[:：]?\s*(\d+(?:\.\d+)?)/i);
    if (!m) return null;
    const n = Number(m[1]);
    return Number.isFinite(n) && n >= 5 && n <= 10 ? n : null;
  }

  function findBank(line, preferredWallet = null) {
    const explicitND = /\bND\b/i.test(line);
    const explicitOL = /\bOL\b/i.test(line);
    const preferND = explicitND || (!explicitOL && preferredWallet === 'ndHardware');
    const defs = [
      { chain: 'TRC', wallet: 'ndHardware', platform: 'ND', re: /(?:ND\s*)?TUSDT\s*-\s*人民币/i },
      { chain: 'BSC', wallet: 'ndHardware', platform: 'ND', re: /(?:ND\s*)?BSCUSDT\s*-\s*人民币/i },
      { chain: 'TON', wallet: 'ndHardware', platform: 'ND', re: /(?:ND\s*)?TONUSDT\s*-\s*人民币/i },
      ...(preferND ? [
        { chain: 'ERC', wallet: 'ndHardware', platform: 'ND', re: /(?:ND\s*)?USDT\s*-\s*人民币/i },
        { chain: 'SOL', wallet: 'ndHardware', platform: 'ND', re: /(?:ND\s*)?SOL\s*-\s*人民币/i }
      ] : []),
      { chain: 'TRC', wallet: 'hardware', platform: 'OL', re: /(?:OL\s*)?TRC\s*-\s*USDT\s*-\s*人民币/i },
      { chain: 'BSC', wallet: 'hardware', platform: 'OL', re: /(?:OL\s*)?BSC\s*-\s*USDT\s*-\s*人民币/i },
      { chain: 'TON', wallet: 'hardware', platform: 'OL', re: /(?:OL\s*)?TON\s*-\s*USDT\s*-\s*人民币/i },
      { chain: 'SOL', wallet: 'hardware', platform: 'OL', re: /(?:OL\s*)?SOL\s*-\s*人民币/i },
      { chain: 'ERC', wallet: 'hardware', platform: 'OL', re: /(?:OL\s*)?USDT\s*-\s*人民币/i },
      { chain: 'TRC', wallet: 'flow2', platform: 'OL', re: /(?:OL\s*)?TRC\s*-?\s*分流\s*(?:2|二)/i },
      { chain: 'TRC', wallet: 'flow1', platform: 'OL', re: /(?:OL\s*)?TRC\s*-?\s*分流\s*(?:1|一)/i },
      { chain: 'ERC', wallet: 'flow1', platform: 'OL', re: /(?:OL\s*)?ERC\s*-?\s*分流\s*(?:1|一)/i },
      { chain: 'BSC', wallet: 'flow1', platform: 'OL', re: /(?:OL\s*)?BSC\s*-?\s*分流\s*(?:1|一)/i },
      { chain: 'TON', wallet: 'flow1', platform: 'OL', re: /(?:OL\s*)?TON\s*-?\s*分流\s*(?:1|一)/i },
      { chain: 'SOL', wallet: 'flow1', platform: 'OL', re: /(?:OL\s*)?SOL\s*-?\s*分流\s*(?:1|一)/i }
    ];
    for (const d of defs) {
      const m = d.re.exec(line);
      if (m) return { ...d, start: m.index, end: m.index + m[0].length, text: m[0] };
    }
    return null;
  }

  function detectWallet(line, bank) {
    const has1 = /分流\s*(?:1|一)/.test(line);
    const has2 = /分流\s*(?:2|二)/.test(line);
    const explicitND = /\bND\b/i.test(line);
    const explicitOL = /\bOL\b/i.test(line);
    const hasND = explicitND || bank?.platform === 'ND';
    if (explicitND && explicitOL) return { error: '平台冲突：OL / ND' };
    if (hasND && (has1 || has2)) return { error: 'ND 不支持分流1/分流2' };
    if (has1 && has2) return { error: '钱包冲突：同时出现分流1与分流2' };
    if (hasND) return { wallet: 'ndHardware', explicit: true };
    if (has2) return { wallet: 'flow2', explicit: true };
    if (has1) return { wallet: 'flow1', explicit: true };
    if (bank?.wallet) return { wallet: bank.wallet, explicit: true };
    if (/硬件/.test(line)) return { wallet: 'hardware', explicit: true };
    return { wallet: null, explicit: false };
  }

  function sPositions(line) {
    const out = [];
    const upper = line.toUpperCase();
    for (const alias of S_ALIASES) {
      let pos = 0;
      const a = alias.toUpperCase();
      while ((pos = upper.indexOf(a, pos)) !== -1) {
        out.push(pos); pos += a.length;
      }
    }
    return out.sort((a,b) => a-b);
  }

  function olPosition(line, bank) {
    const m = /\b(?:OL|ND)\b/i.exec(line);
    if (m) return m.index;
    if (bank) return bank.start;
    const wm = /(硬件|分流\s*(?:1|2|一|二))/.exec(line);
    return wm ? wm.index : -1;
  }

  function hasDirectionMarker(line) {
    return /(→|>|打到|打给|打給|转到|轉到|转给|轉給|\bto\b|到|给|給|转|轉)/i.test(line);
  }

  function detectDirection(line, bank) {
    const signals = [];
    const errors = [];

    if (/S寄金收回/i.test(line) || /U\s*[换換]\s*草/i.test(line)) signals.push({ dir: 'S2OL', src: 'U换草/S寄金收回' });
    if (/S寄金(?!收回)/i.test(line) || /草\s*[换換]\s*U/i.test(line)) signals.push({ dir: 'OL2S', src: '草换U/S寄金' });

    const salias = '(?:S[仓倉]|DD[仓倉](?:库|庫)?|HS[仓倉])';
    if (new RegExp('(?:打)?回\\s*' + salias, 'i').test(line) || /(?:打)?回\s*[仓倉]/.test(line)) {
      signals.push({ dir: 'OL2S', src: '回S仓' });
    }

    const spos = sPositions(line);
    const opos = olPosition(line, bank);
    if (hasDirectionMarker(line) && spos.length && opos >= 0) {
      const nearestS = spos.reduce((best,p) => Math.abs(p-opos) < Math.abs(best-opos) ? p : best, spos[0]);
      signals.push({ dir: nearestS < opos ? 'S2OL' : 'OL2S', src: '方向词' });
    }

    const dirs = [...new Set(signals.map(s => s.dir))];
    if (dirs.length > 1) errors.push('方向冲突');
    if (errors.length) return { error: errors[0], explicit: true };
    if (dirs.length === 1) return { direction: dirs[0], explicit: true, source: signals[0].src };

    if (spos.length && opos >= 0) {
      const firstS = spos[0];
      return { direction: firstS < opos ? 'S2OL' : 'OL2S', explicit: false, source: '出现顺序' };
    }
    return { direction: null, explicit: false };
  }

  function chainMentions(line, bank) {
    const out = [];
    const up = line.toUpperCase();
    for (const chain of CHAINS) {
      let pos = 0;
      while ((pos = up.indexOf(chain, pos)) !== -1) {
        const insideBank = bank && pos >= bank.start && pos < bank.end;
        if (!insideBank) out.push({ chain, pos });
        pos += chain.length;
      }
    }
    return out.sort((a,b) => a.pos - b.pos);
  }

  function nearestChainForAmount(amount, mentions, amountCount) {
    if (!mentions.length) return null;
    if (amountCount === 1) {
      const uniq = [...new Set(mentions.map(m => m.chain))];
      if (uniq.length > 1) return { conflict: uniq };
      return { chain: uniq[0], explicit: true };
    }
    const prev = mentions.filter(m => m.pos <= amount.start);
    if (prev.length) return { chain: prev[prev.length - 1].chain, explicit: true };
    const next = mentions.find(m => m.pos >= amount.end);
    return next ? { chain: next.chain, explicit: true } : null;
  }

  function detectTotal(line) {
    const hasKeyword = /(总共|總共|总额|總額|合计|合計|一共|(?:^|\s)共\s*\d|(?:^|\s)总\s*\d|(?:^|\s)總\s*\d)/.test(line);
    if (!hasKeyword) return null;
    const nums = getNumMatches(line);
    if (!nums.length) return null;
    const isRmb = /(人民币|人民幣|人币|人幣|RMB)/i.test(line);
    return { kind: isRmb ? 'rmb' : 'virtual', value: nums[0].value, raw: nums[0].raw };
  }

  function formulaData(line) {
    const normalized = line.replace(/\s+/g, ' ');
    if (!/[*/=]/.test(normalized)) return null;
    const nums = getNumMatches(normalized);
    if (nums.length < 2) return null;
    const rateCandidates = nums.filter(n => !/[wW万萬颗顆]/.test(n.unit) && n.value >= 5 && n.value <= 10);
    if (!rateCandidates.length) return null;
    const rateTok = rateCandidates[0];
    const rate = rateTok.value;
    const amounts = nums.filter(n => n !== rateTok);
    if (!amounts.length) return null;

    let virtual = null, rmb = null, userVirtual = false, userRmb = false;
    if (amounts.length >= 2) {
      const sorted = [...amounts].sort((a,b) => a.value - b.value);
      virtual = sorted[0].value;
      rmb = sorted[sorted.length - 1].value;
      userVirtual = userRmb = true;
    } else {
      const a = amounts[0];
      const star = /\*/.test(normalized);
      const slash = /\//.test(normalized);
      if (slash && !star) {
        rmb = a.value; userRmb = true;
        virtual = trunc(rmb / rate, 6);
      } else {
        virtual = a.value; userVirtual = true;
        rmb = trunc(virtual * rate, 2);
      }
    }

    const verify = userVirtual && userRmb ? Math.abs((virtual * rate) - rmb) : 0;
    return { virtual, rmb, rate, userVirtual, userRmb, verify, consumed: nums };
  }

  function bankFor(wallet, chain) {
    return BANKS[wallet]?.[chain] || null;
  }

  function makeItem({direction, wallet, walletExplicit, chain, chainExplicit, virtual, rate, rmb, verify = 0, errors = [], warnings = [], rawLine = '', lineIndex = -1}) {
    if (!direction) errors.push('方向不明');

    let finalWallet = wallet;
    let finalChain = chain;

    if (!finalWallet) {
      finalWallet = 'hardware';
      warnings.push('未指定钱包，默认硬件');
    }

    if (!finalChain) {
      if (finalWallet === 'flow2') {
        finalChain = 'TRC';
      } else {
        finalChain = 'TRC';
        warnings.push('未指定链别，默认 TRC');
      }
    }

    if (finalWallet === 'flow2' && finalChain !== 'TRC') errors.push(`${finalChain} 不存在分流2`);
    if (!bankFor(finalWallet, finalChain)) errors.push(`钱包与链别组合不存在：${finalChain}`);

    if (verify > 1e-9) warnings.push(`验算差异：${fmt(verify, 6)}`);

    const bank = bankFor(finalWallet, finalChain);
    const externalPlatform = finalWallet === 'ndHardware' ? 'ND' : 'OL';
    const type = direction === 'S2OL' ? 'U换草' : direction === 'OL2S' ? '草换U' : '方向不明';
    const route = direction === 'S2OL'
      ? `S仓 → ${bank || externalPlatform}`
      : direction === 'OL2S'
        ? `${bank || externalPlatform} → S仓`
        : `${bank || externalPlatform} ↔ S仓`;

    return {
      type, direction, wallet: finalWallet, platform: externalPlatform, chain: finalChain, bank, route,
      virtual, rate, rmb, warnings: [...new Set(warnings)], errors: [...new Set(errors)], rawLine, lineIndex
    };
  }

  function nearestMeta(meta, lineIndex, predicate, maxDistance = 5, preferAfter = false) {
    const candidates = meta.filter(m => predicate(m) && Math.abs(m.index - lineIndex) <= maxDistance);
    if (!candidates.length) return null;
    candidates.sort((a,b) => {
      const da = Math.abs(a.index - lineIndex), db = Math.abs(b.index - lineIndex);
      if (da !== db) return da - db;
      if (preferAfter) {
        const aa = a.index >= lineIndex ? 0 : 1;
        const bb = b.index >= lineIndex ? 0 : 1;
        if (aa !== bb) return aa - bb;
      }
      return a.index - b.index;
    });
    return candidates[0];
  }

  function rebuildDerived(item) {
    item.errors = item.errors.filter(e => e !== '方向不明' && !/不存在分流2$/.test(e) && !/^钱包与链别组合不存在/.test(e));

    if (!item.direction) item.errors.push('方向不明');
    if (!item.wallet) {
      item.wallet = 'hardware';
      if (!item.warnings.some(w => /^未指定钱包/.test(w))) item.warnings.push('未指定钱包，默认硬件');
    }
    if (!item.chain) {
      if (item.wallet === 'flow2') item.chain = 'TRC';
      else {
        item.chain = 'TRC';
        if (!item.warnings.some(w => /^未指定链别/.test(w))) item.warnings.push('未指定链别，默认 TRC');
      }
    }
    if (item.wallet === 'flow2' && item.chain !== 'TRC') item.errors.push(`${item.chain} 不存在分流2`);
    if (!bankFor(item.wallet, item.chain)) item.errors.push(`钱包与链别组合不存在：${item.chain}`);

    item.bank = bankFor(item.wallet, item.chain);
    item.platform = item.wallet === 'ndHardware' ? 'ND' : 'OL';
    item.type = item.direction === 'S2OL' ? 'U换草' : item.direction === 'OL2S' ? '草换U' : '方向不明';
    item.route = item.direction === 'S2OL'
      ? `S仓 → ${item.bank || item.platform || 'OL'}`
      : item.direction === 'OL2S'
        ? `${item.bank || item.platform || 'OL'} → S仓`
        : `${item.bank || item.platform || 'OL'} ↔ S仓`;
    item.warnings = [...new Set(item.warnings)];
    item.errors = [...new Set(item.errors)];
  }

  function resolveSplitLineContext(items, lines) {
    const meta = lines.map((raw, index) => {
      const line = raw.trim();
      const bank = line ? findBank(line) : null;
      const walletInfo = line ? detectWallet(line, bank) : {};
      const dirInfo = line ? detectDirection(line, bank) : {};
      const mentions = line ? chainMentions(line, bank) : [];
      const chains = [...new Set([...(bank?.chain ? [bank.chain] : []), ...mentions.map(x => x.chain)])];
      return {
        index, line, bank, walletInfo, dirInfo,
        chains,
        hasS: line ? sPositions(line).length > 0 : false,
        hasOL: line ? (olPosition(line, bank) >= 0) : false
      };
    });

    for (const item of items) {
      if (item.lineIndex < 0) continue;
      const own = meta[item.lineIndex];

      // Direction can be completed when S仓 and OL are split across nearby lines.
      if (!item.direction) {
        const preferAfterOL = !!own?.hasS;
        const preferAfterS = !!own?.hasOL;
        const sm = nearestMeta(meta, item.lineIndex, m => m.hasS, 5, preferAfterS);
        const om = nearestMeta(meta, item.lineIndex, m => m.hasOL, 5, preferAfterOL);
        if (sm && om) {
          if (sm.index !== om.index) item.direction = sm.index < om.index ? 'S2OL' : 'OL2S';
          else {
            const d = om.dirInfo?.direction;
            if (d) item.direction = d;
            else {
              const sp = sPositions(sm.line)[0];
              const op = olPosition(om.line, om.bank);
              if (sp >= 0 && op >= 0) item.direction = sp < op ? 'S2OL' : 'OL2S';
            }
          }
        } else {
          const dm = nearestMeta(meta, item.lineIndex, m => !!m.dirInfo?.direction, 4, false);
          if (dm) item.direction = dm.dirInfo.direction;
        }
      }

      // If wallet was only defaulted because the original fields were split across lines,
      // prefer a nearby explicit wallet/bank.
      if (item.warnings.some(w => /^未指定钱包/.test(w))) {
        const wm = nearestMeta(meta, item.lineIndex, m => !!m.walletInfo?.wallet, 4, !!own?.hasS);
        if (wm && !wm.walletInfo.error) { item.wallet = wm.walletInfo.wallet; item.warnings = item.warnings.filter(w => !/^未指定钱包/.test(w)); }
      }

      // Same for chain: a separate TRC/ERC/BSC/TON/SOL line can belong to the same entry.
      if (item.warnings.some(w => /^未指定链别/.test(w))) {
        const cm = nearestMeta(meta, item.lineIndex, m => m.chains?.length === 1, 3, false);
        if (cm) { item.chain = cm.chains[0]; item.warnings = item.warnings.filter(w => !/^未指定链别/.test(w)); }
      }

      // Flow2 uniquely implies TRC even if chain was omitted.
      if (item.wallet === 'flow2' && item.warnings.some(w => /^未指定链别/.test(w))) item.chain = 'TRC';
      rebuildDerived(item);
    }
  }

  function parse(text, options = {}) {
    const uiRate = Number(options.defaultRate || 6.9);
    let sharedRate = Number.isFinite(uiRate) && uiRate > 0 ? uiRate : 6.9;
    const lines = normText(text).split('\n');
    const items = [];
    const totals = [];
    const globalErrors = [];
    const globalWarnings = [];

    const unsupportedPlatforms = findUnsupportedPlatforms(text);
    if (unsupportedPlatforms.length) globalErrors.push('目前仅支持OL、ND');

    const ctx = {
      direction: null,
      wallet: null,
      walletExplicit: false,
      chain: null,
      chainExplicit: false
    };

    for (let li = 0; li < lines.length; li++) {
      const original = lines[li];
      const line = original.trim();
      if (!line) continue;

      const pureRate = isPureRateLine(line);
      if (pureRate != null) {
        sharedRate = pureRate;
        continue;
      }

      const er = explicitRate(line);
      const total = detectTotal(line);
      if (total) {
        totals.push({ ...total, line: li + 1 });
        if (/^\s*(?:人民币|人民幣|人币|人幣|RMB)?\s*(?:总共|總共|总额|總額|合计|合計|一共|共|总|總)/i.test(line)) {
          if (er != null) sharedRate = er;
          continue;
        }
      }
      if (er != null) sharedRate = er;

      const bank = findBank(line, ctx.wallet);
      const walletInfo = detectWallet(line, bank);
      const dirInfo = detectDirection(line, bank);
      const mentions = chainMentions(line, bank);
      const amounts = getNumMatches(line).filter(n => {
        if (er != null && Math.abs(n.value - er) < 1e-12 && !/[wW万萬颗顆]/.test(n.unit)) return false;
        return true;
      });

      const hasOlRef = /\b(?:OL|ND)\b/i.test(line) || !!bank || /(硬件|分流\s*(?:1|2|一|二))/.test(line);
      const hasSRef = sPositions(line).length > 0;
      const isNewRoute = !!dirInfo.direction || !!dirInfo.error || (hasOlRef && hasSRef);

      if (isNewRoute) {
        ctx.chain = null; ctx.chainExplicit = false;
        if (hasOlRef && !walletInfo.wallet && !walletInfo.error) {
          ctx.wallet = null; ctx.walletExplicit = false;
        }
      }

      if (dirInfo.direction) ctx.direction = dirInfo.direction;
      if (walletInfo.wallet) { ctx.wallet = walletInfo.wallet; ctx.walletExplicit = walletInfo.explicit; }

      if (!amounts.length && !formulaData(line) && mentions.length === 1 && !bank) {
        ctx.chain = mentions[0].chain; ctx.chainExplicit = true;
      }

      const formula = formulaData(line);
      if (formula) {
        const errs = [];
        const warns = [];
        if (dirInfo.error) errs.push(dirInfo.error);
        if (walletInfo.error) errs.push(walletInfo.error);

        let chain = bank?.chain || ctx.chain;
        let explicitChain = !!bank || ctx.chainExplicit;
        const uniqMentions = [...new Set(mentions.map(m => m.chain))];
        if (uniqMentions.length > 1) errs.push(`链别冲突：${uniqMentions.join(' / ')}`);
        else if (uniqMentions.length === 1) {
          if (bank?.chain && bank.chain !== uniqMentions[0]) errs.push(`链别冲突：${uniqMentions[0]} / ${bank.chain}`);
          chain = uniqMentions[0]; explicitChain = true;
        }

        const item = makeItem({
          direction: dirInfo.direction || ctx.direction,
          wallet: walletInfo.wallet || ctx.wallet,
          walletExplicit: walletInfo.wallet ? walletInfo.explicit : ctx.walletExplicit,
          chain,
          chainExplicit: explicitChain,
          virtual: formula.virtual,
          rate: formula.rate,
          rmb: formula.rmb,
          verify: formula.verify,
          errors: errs,
          warnings: warns,
          rawLine: original,
          lineIndex: li
        });
        items.push(item);
        if (chain) { ctx.chain = chain; ctx.chainExplicit = explicitChain; }
        continue;
      }

      if (!amounts.length) continue;

      const localAmounts = amounts.filter(a => {
        if (total && Math.abs(a.value - total.value) < 1e-12 && a.raw === total.raw) return false;
        return true;
      });
      if (!localAmounts.length) continue;

      for (const amount of localAmounts) {
        const errs = [];
        const warns = [];
        if (dirInfo.error) errs.push(dirInfo.error);
        if (walletInfo.error) errs.push(walletInfo.error);

        let chain = null;
        let chainExplicit = false;
        const near = nearestChainForAmount(amount, mentions, localAmounts.length);
        if (near?.conflict) {
          errs.push(`链别冲突：${near.conflict.join(' / ')}`);
        } else if (near?.chain) {
          chain = near.chain; chainExplicit = true;
        }

        if (bank?.chain) {
          if (chain && chain !== bank.chain) errs.push(`链别冲突：${chain} / ${bank.chain}`);
          if (!chain) { chain = bank.chain; chainExplicit = true; }
        }

        if (!chain && ctx.chain) { chain = ctx.chain; chainExplicit = ctx.chainExplicit; }

        const rate = er != null ? er : sharedRate;
        const virtual = amount.value;
        const rmb = trunc(virtual * rate, 2);
        const item = makeItem({
          direction: dirInfo.direction || ctx.direction,
          wallet: walletInfo.wallet || ctx.wallet,
          walletExplicit: walletInfo.wallet ? walletInfo.explicit : ctx.walletExplicit,
          chain,
          chainExplicit,
          virtual,
          rate,
          rmb,
          errors: errs,
          warnings: warns,
          rawLine: original,
          lineIndex: li
        });
        items.push(item);
      }

      if (mentions.length) {
        ctx.chain = mentions[mentions.length - 1].chain;
        ctx.chainExplicit = true;
      } else if (bank?.chain) {
        ctx.chain = bank.chain;
        ctx.chainExplicit = true;
      }
    }

    resolveSplitLineContext(items, lines);

    // Total checks: current test version treats a supplied total as the total for all parsed transactions.
    for (const t of totals) {
      const actual = t.kind === 'rmb'
        ? items.reduce((s, it) => s + (Number(it.rmb) || 0), 0)
        : items.reduce((s, it) => s + (Number(it.virtual) || 0), 0);
      const tol = t.kind === 'rmb' ? 0.009999 : 0.0000009;
      if (Math.abs(actual - t.value) > tol) {
        globalErrors.push(`总额不符：总额 ${fmt(t.value, 6)} / 拆分 ${fmt(actual, 6)} / 差额 ${fmt(Math.abs(t.value - actual), 6)}`);
      }
    }

    if (!items.length) globalErrors.push('没有找到可拆解的作帐资料');
    const hasItemErrors = items.some(it => it.errors.length > 0);
    const ok = items.length > 0 && !hasItemErrors && globalErrors.length === 0;

    return { ok, items, totals, globalErrors, globalWarnings, defaultRate: uiRate };
  }

  globalThis.GrassUParser = { parse, fmt, trunc, BANKS };
})();
