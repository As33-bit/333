chrome.action.onClicked.addListener(async (tab) => {
  if (!tab.id || !tab.url) return;
  if (
    tab.url.startsWith("chrome://") ||
    tab.url.startsWith("edge://") ||
    tab.url.startsWith("chrome-extension://")
  ) return;

  try {
    await chrome.scripting.executeScript({
      target: { tabId: tab.id },
      files: ["content.js"]
    });
  } catch (e) {
    console.error("COW inject failed:", e);
  }
});

function cowTabOpenModeKey(tabId) {
  return `cowTabOpenMode_${tabId}`;
}

function cowTabTitleNameKey(tabId) {
  return `cowTabTitleName_${tabId}`;
}

async function cowSetTabOpenMode(tabId, mode) {
  if (!Number.isInteger(tabId)) return;
  try {
    await chrome.storage.local.set({ [cowTabOpenModeKey(tabId)]: mode });
  } catch (_) {}
}

async function cowGetTabOpenMode(tabId) {
  if (!Number.isInteger(tabId)) return "";
  try {
    const key = cowTabOpenModeKey(tabId);
    const data = await chrome.storage.local.get([key]);
    return String(data?.[key] || "");
  } catch (_) {
    return "";
  }
}

function cowBuildTabTitle(name, mode = "") {
  const suffix = mode ? ` ${mode}` : "";
  return `COW | ${name}${suffix}`;
}

async function keepCowTitle(tabId, title) {
  try {
    await chrome.scripting.executeScript({
      target: { tabId },
      func: (wantedTitle) => {
        const KEY = "__cowTitleKeeper";

        if (window[KEY] && window[KEY].observer) {
          try { window[KEY].observer.disconnect(); } catch (_) {}
        }

        const apply = () => {
          if (document.title !== wantedTitle) {
            document.title = wantedTitle;
          }
        };

        apply();

        const observer = new MutationObserver(apply);
        const target = document.querySelector("title") || document.documentElement;
        observer.observe(target, {
          subtree: true,
          childList: true,
          characterData: true
        });

        window[KEY] = { title: wantedTitle, observer };
      },
      args: [title]
    });
  } catch (e) {
    console.warn("COW title inject failed:", e);
  }
}

function normalizeItem(item) {
  if (typeof item === "string") {
    return { name: "頁面", url: item };
  }
  return {
    name: item?.name || "頁面",
    url: item?.url || ""
  };
}

async function attachCowTitle(tabId, name) {
  const mode = await cowGetTabOpenMode(tabId);
  const title = cowBuildTabTitle(name, mode);

  const listener = async (updatedTabId, changeInfo) => {
    if (updatedTabId !== tabId || changeInfo.status !== "complete") return;
    chrome.tabs.onUpdated.removeListener(listener);
    await keepCowTitle(tabId, title);
  };

  chrome.tabs.onUpdated.addListener(listener);
  setTimeout(() => keepCowTitle(tabId, title), 1500);
}

function cowUrlMatchesTarget(tabUrl, targetUrl) {
  try {
    const a = new URL(String(tabUrl || ""));
    const b = new URL(String(targetUrl || ""));
    if (!/^https?:$/.test(a.protocol) || !/^https?:$/.test(b.protocol)) return false;

    // v0.2.9：複製來源以「同一個網站 hostname」判斷，不再要求功能頁路徑相同。
    // 例如使用者 MS 已停在 /management/other/income-expenditure，仍視為已開啟 MS，
    // 先複製該已登入分頁到 COW 視窗 B；真正查詢時再在 B 內切到需要的功能頁。
    return a.hostname === b.hostname;
  } catch (_) {
    return false;
  }
}

async function cowFindCloneSource(targetUrl, excludeWindowIds = []) {
  const excluded = new Set((excludeWindowIds || []).filter(Number.isInteger));
  const tabs = await chrome.tabs.query({});
  const matches = tabs.filter(tab => {
    if (!tab || !tab.id || excluded.has(tab.windowId)) return false;
    if (/^COW\s*[|｜]/.test(String(tab.title || ""))) return false;
    return cowUrlMatchesTarget(tab.url, targetUrl);
  });

  if (!matches.length) return null;
  // 優先目前正在使用的頁籤，其次用最近存取的頁籤。
  matches.sort((a, b) => {
    const activeDiff = Number(Boolean(b.active)) - Number(Boolean(a.active));
    if (activeDiff) return activeDiff;
    return Number(b.lastAccessed || 0) - Number(a.lastAccessed || 0);
  });
  return matches[0];
}

async function cowDuplicateIntoWindow(sourceTabId, windowId, active = false) {
  const dup = await chrome.tabs.duplicate(sourceTabId);
  if (!dup || !dup.id) throw new Error("複製已登入分頁失敗");
  const moved = await chrome.tabs.move(dup.id, { windowId, index: -1 });
  const tab = Array.isArray(moved) ? moved[0] : moved;
  if (tab?.id) {
    await cowSetTabOpenMode(tab.id, "复制");
    try { await chrome.tabs.update(tab.id, { active: Boolean(active) }); } catch (_) {}
  }
  return tab;
}

async function openCowGroup(items) {
  const validItems = items.map(normalizeItem).filter(x => x.url);
  if (!validItems.length) return { ok: false, error: "沒有可開啟的網址" };

  // 每次「檢查登入」建立新的獨立視窗 B。
  // 優先複製使用者原本視窗 A 內已開啟的登入頁籤；找不到才用網址新開。
  const oldCowWindowId = await cowGetDedicatedWindowId();
  const excludeWindowIds = Number.isInteger(oldCowWindowId) ? [oldCowWindowId] : [];
  const sources = [];
  for (const item of validItems) {
    let source = null;
    try { source = await cowFindCloneSource(item.url, excludeWindowIds); } catch (_) {}
    sources.push(source);
  }

  let win = null;
  let firstTab = null;
  let firstOpenMode = "新开";
  const first = validItems[0];
  const firstSource = sources[0];

  if (firstSource?.id) {
    try {
      const dup = await chrome.tabs.duplicate(firstSource.id);
      if (dup?.id) {
        win = await chrome.windows.create({
          tabId: dup.id,
          type: "normal",
          width: 1680,
          height: 990,
          focused: true
        });
        if (win?.id) {
          firstOpenMode = "复制";
          const firstTabs = await chrome.tabs.query({ windowId: win.id });
          firstTab = firstTabs[0] || null;
        }
      }
    } catch (_) {
      win = null;
      firstTab = null;
    }
  }

  if (!win?.id) {
    win = await chrome.windows.create({
      url: first.url,
      type: "normal",
      width: 1680,
      height: 990,
      focused: true
    });
    if (!win || !win.id) return { ok: false, error: "無法建立 COW 視窗" };
    const firstTabs = await chrome.tabs.query({ windowId: win.id });
    firstTab = firstTabs[0] || null;
  }

  await chrome.storage.local.set({ cowDedicatedWindowId: win.id });

  if (firstTab?.id) {
    await cowSetTabOpenMode(firstTab.id, firstOpenMode);
    await cowMuteTab(firstTab.id);
    await cowWaitTabComplete(firstTab.id, 30000);
    await cowMuteTab(firstTab.id);
    await cowSetCowTitle(firstTab.id, first.name);
  }

  for (let i = 1; i < validItems.length; i++) {
    const item = validItems[i];
    const source = sources[i];
    let tab = null;

    if (source?.id) {
      try {
        tab = await cowDuplicateIntoWindow(source.id, win.id, false);
      } catch (_) {
        tab = null;
      }
    }

    if (!tab?.id) {
      tab = await chrome.tabs.create({
        windowId: win.id,
        url: item.url,
        active: false
      });
      if (tab?.id) await cowSetTabOpenMode(tab.id, "新开");
    }

    if (tab?.id) {
      await cowMuteTab(tab.id);
      await cowWaitTabComplete(tab.id, 30000);
      await cowMuteTab(tab.id);
      await cowSetCowTitle(tab.id, item.name);
    }
  }

  return {
    ok: true,
    windowId: win.id,
    count: validItems.length,
    copiedCount: sources.filter(Boolean).length
  };
}


// ===== COW 使用統計：補回按鈕點擊 =====
// 每次有效點擊「操作+MS作帳」：
// 1) 本機 chrome.storage.local +1；
// 2) 同步呼叫 Supabase RPC cow_increment_repay，依「日期 + 平台」累加 1。
// 遠端統計失敗不會影響原本補回流程。
const COW_STATS_SUPABASE_URL = "https://pqraknjtxyruvswgrlwg.supabase.co";
const COW_STATS_SUPABASE_KEY = "sb_publishable_FcGKft63Ke2d0pnaXSoS7Q_4W1chpvp";
const COW_STATS_RPC_URL = COW_STATS_SUPABASE_URL + "/rest/v1/rpc/cow_increment_repay";
const COW_SHORT_STATS_RPC_URL = COW_STATS_SUPABASE_URL + "/rest/v1/rpc/cow_increment_short";
const COW_INSTALL_ID_KEY = "cow_install_id_v1";
const COW_USAGE_STATS_KEY = "cow_usage_stats_v1";

function cowUsageDateKey(date = new Date()) {
  return `${date.getFullYear()}-${String(date.getMonth()+1).padStart(2, "0")}-${String(date.getDate()).padStart(2, "0")}`;
}

async function cowSendRepayStatToSupabase(platform) {
  const res = await fetch(COW_STATS_RPC_URL, {
    method: "POST",
    headers: {
      "apikey": COW_STATS_SUPABASE_KEY,
      "Authorization": "Bearer " + COW_STATS_SUPABASE_KEY,
      "Content-Type": "application/json",
      "Prefer": "return=minimal"
    },
    body: JSON.stringify({
      p_date: cowUsageDateKey(),
      p_platform: platform
    })
  });

  if (!res.ok) {
    const text = await res.text().catch(() => "");
    throw new Error(`COW Supabase 統計 HTTP ${res.status}${text ? `｜${text}` : ""}`);
  }
  return true;
}

async function cowSendShortStatToSupabase(platform) {
  const res = await fetch(COW_SHORT_STATS_RPC_URL, {
    method: "POST",
    headers: {
      "apikey": COW_STATS_SUPABASE_KEY,
      "Authorization": "Bearer " + COW_STATS_SUPABASE_KEY,
      "Content-Type": "application/json",
      "Prefer": "return=minimal"
    },
    body: JSON.stringify({
      p_date: cowUsageDateKey(),
      p_platform: platform
    })
  });

  if (!res.ok) {
    const text = await res.text().catch(() => "");
    throw new Error(`COW 有少统计 HTTP ${res.status}${text ? `｜${text}` : ""}`);
  }
  return true;
}

async function cowTrackShortClick(platformRaw) {
  const platform = String(platformRaw || "UNKNOWN").trim().toUpperCase() || "UNKNOWN";
  let remoteSent = false;
  let remoteError = "";

  try {
    await cowSendShortStatToSupabase(platform);
    remoteSent = true;
  } catch (err) {
    remoteError = String(err?.message || err || "");
    console.warn("COW 有少统计送出失败：", remoteError);
  }

  return { ok:true, platform, remoteSent, remoteError };
}

async function cowGetOrCreateInstallId() {
  const stored = await chrome.storage.local.get([COW_INSTALL_ID_KEY]);
  let installId = String(stored?.[COW_INSTALL_ID_KEY] || "").trim();
  if (!installId) {
    installId = (globalThis.crypto && typeof globalThis.crypto.randomUUID === "function")
      ? globalThis.crypto.randomUUID()
      : `cow_${Date.now()}_${Math.random().toString(36).slice(2, 12)}`;
    await chrome.storage.local.set({ [COW_INSTALL_ID_KEY]: installId });
  }
  return installId;
}

async function cowTrackRepayClick(platformRaw) {
  const platform = String(platformRaw || "UNKNOWN").trim().toUpperCase() || "UNKNOWN";
  const installId = await cowGetOrCreateInstallId();
  const now = new Date().toISOString();

  const stored = await chrome.storage.local.get([COW_USAGE_STATS_KEY]);
  const oldStats = stored?.[COW_USAGE_STATS_KEY] || {};
  const byPlatform = { ...(oldStats.byPlatform || {}) };
  byPlatform[platform] = Number(byPlatform[platform] || 0) + 1;
  const stats = {
    total: Number(oldStats.total || 0) + 1,
    byPlatform,
    lastPlatform: platform,
    lastUsedAt: now
  };
  await chrome.storage.local.set({ [COW_USAGE_STATS_KEY]: stats });

  // 遠端統計失敗絕對不能影響原本 COW 補回流程。
  let remoteSent = false;
  let remoteError = "";
  try {
    await cowSendRepayStatToSupabase(platform);
    remoteSent = true;
  } catch (err) {
    remoteError = String(err?.message || err || "");
    console.warn("COW 補回統計送出失敗：", remoteError);
  }

  return { ok:true, installId, platform, stats, remoteSent, remoteError };
}

chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (!message || message.type !== "open_urls") return;

  const items = Array.isArray(message.urls)
    ? message.urls
    : (Array.isArray(message.items) ? message.items : []);

  (async () => {
    try {
      const result = await openCowGroup(items);
      sendResponse(result);
    } catch (e) {
      sendResponse({ ok: false, error: String(e) });
    }
  })();

  return true;
});


const COW_SPECIAL_WG_PLATFORMS = new Set(["XY", "OL", "LS", "XH"]);

function cowSleep(ms) {
  return new Promise(resolve => setTimeout(resolve, ms));
}

function cowParseRepayText(raw) {
  const rawLines = String(raw || "")
    .replace(/\r/g, "\n")
    .split("\n")
    .map(s => s.trim())
    .filter(Boolean);

  const isDateLine = s => /^(?:\d{4}[/-])?\d{1,2}[/-]\d{1,2}$/.test(String(s || "").trim());
  const isMarkdownDivider = s => {
    const t = String(s || "").trim();
    if (!t.includes("|")) return false;
    const cells = t.replace(/^\|+|\|+$/g, "").split("|").map(x => x.trim()).filter(Boolean);
    return cells.length > 0 && cells.every(x => /^:?-{2,}:?$/.test(x));
  };
  const tableCells = s => {
    const t = String(s || "").trim();
    if (!t.includes("|")) return [];
    return t.replace(/^\|+|\|+$/g, "").split("|").map(x => x.trim()).filter(Boolean);
  };

  // 忽略 Markdown 表格的對齊分隔列與空表格列，但保留真正資料列。
  const lines = rawLines.filter(line => {
    if (isMarkdownDivider(line)) return false;
    if (/^\|(?:\s*\|)*\s*$/.test(line)) return false;
    return true;
  });

  if (lines.length < 2) {
    throw new Error("0.解析內容錯誤：內容不足，至少需要平台、單號、會員、補回金額");
  }

  // 日期可放在獨立一行、Markdown 表格欄位，或直接放在平台前面。
  // 例如：9/10 RF WKRL_77638 zd16888
  let dateText = null;
  for (const line of lines) {
    if (isDateLine(line)) {
      dateText = line;
      break;
    }

    const cells = tableCells(line);
    const dc = cells.find(isDateLine);
    if (dc) {
      dateText = dc;
      break;
    }

    // 一般空白 / Tab 分隔格式：9/10 RF WKRL_77638 zd16888
    const tokens = line.split(/\s+/).map(x => x.trim()).filter(Boolean);
    const dt = tokens.find(isDateLine);
    if (dt) {
      dateText = dt;
      break;
    }
  }

  const supported = new Set(["XY","OL","LS","XH","TD","RF","HS","YD","ND","YS","SH","JY","JD","MT","FB"]);
  let platform = "";
  let orderNo = "";
  let member = "";
  let platformIndex = -1;

  // 支援：
  // 1) XY P... nlba199012
  // 2) | XY | P... | nlba199012 |
  // 3) 舊格式：XY P...  下一行會員
  for (let i = 0; i < lines.length; i++) {
    const line = lines[i];
    const cells = tableCells(line);
    const parts = cells.length ? cells : line.split(/\s+/).filter(Boolean);
    for (let j = 0; j < parts.length; j++) {
      const p = String(parts[j] || "").trim().toUpperCase();
      if (!supported.has(p)) continue;
      if (parts.length <= j + 1) continue;
      platform = p;
      orderNo = String(parts[j + 1] || "").trim();
      if (parts.length > j + 2) {
        const candidate = String(parts[j + 2] || "").trim();
        if (candidate && !isDateLine(candidate) && !/[補补]回\s*[0-9]+(?:\.[0-9]+)?/.test(candidate)) {
          member = candidate;
        }
      }
      platformIndex = i;
      break;
    }
    if (platform) break;
  }

  if (!platform || !orderNo) {
    throw new Error("0.解析內容錯誤：找不到平台和商戶單號");
  }

  if (!member) {
    for (let i = platformIndex + 1; i < lines.length; i++) {
      const line = lines[i];
      if (isDateLine(line) || isMarkdownDivider(line)) continue;
      const compact = line.replace(/\s+/g, "");

      if (/[補补]回\s*[0-9]+(?:\.[0-9]+)?/.test(line)) continue;
      if (/^出款[0-9]+(?:\.[0-9]+)?$/.test(compact)) continue;
      if (/^拆[帳账][0-9]+(?:\.[0-9]+)?\+[0-9]+(?:\.[0-9]+)?$/.test(compact)) continue;
      if (compact === "2出款失败补回" || compact === "2出款失敗補回") continue;
      if (compact === "出款失敗補回" || compact === "出款失败补回") continue;
      if (compact.includes("出款失敗補回拆") || compact.includes("出款失败补回拆")) continue;

      const cells = tableCells(line);
      const parts = cells.length ? cells : line.split(/\s+/).filter(Boolean);
      if (!parts.length) continue;
      if (supported.has(String(parts[0] || "").toUpperCase())) continue;

      member = String(parts[0] || "").trim();
      break;
    }
  }

  if (!member) {
    throw new Error("0.解析內容錯誤：找不到會員名");
  }

  let repayAmount = null;
  let expectedActualPayout = null;
  let expectedSplitText = null;

  for (const line of lines) {
    let m = line.match(/[補补]回\s*([0-9]+(?:\.[0-9]+)?)/);
    if (m) repayAmount = Number(m[1]);

    const compact = line.replace(/\s+/g, "").replace(/\|/g, "");

    m = compact.match(/^出款([0-9]+(?:\.[0-9]+)?)$/);
    if (m) expectedActualPayout = Number(m[1]);

    m = compact.match(/^拆[帳账]([0-9]+(?:\.[0-9]+)?\+[0-9]+(?:\.[0-9]+)?)$/);
    if (m) expectedSplitText = m[1];
  }

  if (repayAmount == null) {
    throw new Error("0.解析內容錯誤：找不到補回金額");
  }
  if (!(repayAmount > 0)) {
    throw new Error("0.解析內容錯誤：補回金額必須大於0");
  }

  return {
    platform,
    orderNo,
    member,
    repayAmount,
    dateText,
    hasDate: !!dateText,
    expectedActualPayout,
    expectedSplitText
  };
}

async function cowFindTabByUrlPart(parts) {
  const tabs = await chrome.tabs.query({});
  return tabs.find(tab => {
    const url = String(tab.url || "");
    return parts.some(part => url.includes(part));
  }) || null;
}

async function cowExec(tabId, func, args = []) {
  const result = await chrome.scripting.executeScript({
    target: { tabId },
    func,
    args
  });
  return result && result[0] ? result[0].result : null;
}


async function cowWaitTabComplete(tabId, timeoutMs = 30000) {
  const started = Date.now();
  while (Date.now() - started < timeoutMs) {
    try {
      const tab = await chrome.tabs.get(tabId);
      if (tab && tab.status === "complete") return true;
    } catch (e) {
      return false;
    }
    await cowSleep(200);
  }
  return false;
}

async function cowReloadAndWait(tabId) {
  try {
    await chrome.tabs.reload(tabId);
  } catch (e) {
    return false;
  }
  return await cowWaitTabComplete(tabId, 30000);
}

async function cowWaitPageReady(tabId, pageType, reloadMarker = null) {
  // 不依賴固定秒數；持續檢查真正要操作的 DOM 元件是否已出現。
  // 最長 60 秒只作為異常保護。
  const started = Date.now();
  const hardLimitMs = 60000;

  while (Date.now() - started < hardLimitMs) {
    try {
      const ready = await cowExec(tabId, (type, marker) => {
        if (marker && document.documentElement?.dataset?.cowReloadMarker === marker) {
          // 還在刷新前的舊文件，不能操作。
          return false;
        }

        function visible(el) {
          if (!el) return false;
          const r = el.getBoundingClientRect();
          const s = getComputedStyle(el);
          return r.width > 0 &&
                 r.height > 0 &&
                 s.display !== "none" &&
                 s.visibility !== "hidden";
        }

        if (!document.body) return false;

        if (type === "sfp") {
          const input = [...document.querySelectorAll(
            'input[placeholder="请输入商户单号"]'
          )].find(visible);

          const button = [...document.querySelectorAll("button")].find(el => {
            if (!visible(el)) return false;
            const t = (el.innerText || el.textContent || "").replace(/\s+/g, "");
            return t === "查询" || t === "查詢";
          });

          return !!(input && button);
        }

        if (type === "ms") {
          const input = [...document.querySelectorAll(
            'input[placeholder="请输入单号"]'
          )].find(visible);

          const button = [...document.querySelectorAll("button")].find(el => {
            if (!visible(el)) return false;
            const t = (el.innerText || el.textContent || "").replace(/\s+/g, "");
            return t === "查询" || t === "查詢";
          });

          return !!(input && button);
        }

        return false;
      }, [pageType, reloadMarker]);

      if (ready) return true;
    } catch (e) {
      // SPA 重整切換期間可能暫時無法注入；繼續下一輪。
    }

    await cowSleep(200);
  }

  return false;
}


async function cowReloadNeededTabs(tabIds = []) {
  // 只刷新這次流程真正需要的分頁，而且同時刷新。
  // 刷新前先在「舊文件」放 marker，後續必須等 marker 消失，
  // 才能開始貼單號，避免 reload 尚未真正開始時誤操作舊畫面。
  const uniqueIds = [...new Set(tabIds.filter(id => Number.isInteger(id)))];
  const markers = {};

  await Promise.allSettled(
    uniqueIds.map(async tabId => {
      const marker = `cow_reload_${Date.now()}_${tabId}_${Math.random().toString(36).slice(2)}`;
      markers[tabId] = marker;

      try {
        await cowMuteTab(tabId);

        try {
          await cowExec(tabId, (m) => {
            if (document.documentElement) {
              document.documentElement.dataset.cowReloadMarker = m;
            }
          }, [marker]);
        } catch (e) {}

        await chrome.tabs.reload(tabId);
      } catch (e) {}
    })
  );

  return markers;
}

async function cowSetCowTitle(tabId, titleName) {
  try {
    // 記住這個 COW 分頁的角色。四方等網站若之後又 redirect / reload，
    // background 的 onUpdated 會依這個角色重新套回 COW 標題。
    try {
      await chrome.storage.local.set({ [cowTabTitleNameKey(tabId)]: String(titleName || "") });
    } catch (_) {}

    const mode = await cowGetTabOpenMode(tabId);
    const desiredTitle = cowBuildTabTitle(titleName, mode);

    await cowExec(tabId, (desired) => {
      const apply = () => {
        if (document.title !== desired) document.title = desired;
      };

      apply();

      // 每次呼叫都更新目前希望維持的標題，避免同頁跳轉後被舊 closure 改回。
      window.__cowDesiredTitle = desired;

      if (!window.__cowTitleKeeperInstalled) {
        window.__cowTitleKeeperInstalled = true;
        const keepCurrent = () => {
          const wanted = window.__cowDesiredTitle || desired;
          if (document.title !== wanted) document.title = wanted;
        };
        const observer = new MutationObserver(keepCurrent);
        observer.observe(document.documentElement, {
          subtree: true,
          childList: true,
          characterData: true
        });

        // 某些 SPA 會延後改 title，再補一層保險。
        setInterval(keepCurrent, 1000);
      }
    }, [desiredTitle]);
  } catch (e) {}
}

// COW 分頁發生完整導頁 / reload 時，頁面內的 MutationObserver 會隨舊文件消失。
// 用 background 再補一次，確保四方不會被網站改回「管理系统」。
chrome.tabs.onUpdated.addListener(async (tabId, changeInfo, tab) => {
  if (changeInfo.status !== "complete") return;
  try {
    const dedicatedWindowId = await cowGetDedicatedWindowId();
    if (!Number.isInteger(dedicatedWindowId) || tab?.windowId !== dedicatedWindowId) return;

    const key = cowTabTitleNameKey(tabId);
    const data = await chrome.storage.local.get([key]);
    const titleName = String(data?.[key] || "").trim();
    if (!titleName) return;

    // 讓網站自己的載入後 title 更新先跑完，再重新套 COW 標題。
    setTimeout(() => { cowSetCowTitle(tabId, titleName).catch(() => {}); }, 250);
  } catch (_) {}
});

chrome.tabs.onRemoved.addListener((tabId) => {
  try {
    chrome.storage.local.remove([cowTabOpenModeKey(tabId), cowTabTitleNameKey(tabId)]);
  } catch (_) {}
});

async function cowMuteTab(tabId) {
  try {
    await chrome.tabs.update(tabId, { muted: true });
  } catch (e) {}
}

async function cowGetDedicatedWindowId() {
  try {
    const saved = await chrome.storage.local.get(["cowDedicatedWindowId"]);
    const id = saved?.cowDedicatedWindowId;
    if (Number.isInteger(id)) {
      try {
        await chrome.windows.get(id);
        return id;
      } catch (e) {
        await chrome.storage.local.remove(["cowDedicatedWindowId"]);
      }
    }
  } catch (e) {}

  // COW 的查詢與操作只能使用「檢查登入」建立的獨立視窗 B。
  // 不再從所有 Chrome 視窗中猜測 / 接管既有 COW 標題頁，避免誤操作
  // 使用者原本工作中的視窗 A。若 B 不存在，cowEnsureTab 會新建一個 B。
  return null;
}

async function cowEnsureTab(urlParts, createUrl, titleName) {
  let cowWindowId = await cowGetDedicatedWindowId();

  // 只重用獨立 COW 視窗 B 裡的頁面，避免操作原本工作視窗 A。
  if (Number.isInteger(cowWindowId)) {
    try {
      const tabs = await chrome.tabs.query({ windowId: cowWindowId });
      const expectedTitlePrefix = `COW | ${titleName}`;
      const tab = tabs.find(t => String(t.title || "").startsWith(expectedTitlePrefix))
        || tabs.find(t => cowUrlMatchesTarget(t.url, createUrl))
        || tabs.find(t => {
          const url = String(t.url || "");
          return urlParts.some(part => url.includes(part));
        })
        || null;

      if (tab?.id) {
        await cowMuteTab(tab.id);
        await cowSetCowTitle(tab.id, titleName);
        return await chrome.tabs.get(tab.id);
      }
    } catch (e) {
      cowWindowId = null;
    }
  }

  let source = null;
  try {
    source = await cowFindCloneSource(
      createUrl,
      Number.isInteger(cowWindowId) ? [cowWindowId] : []
    );
  } catch (_) {}

  let created = null;

  if (Number.isInteger(cowWindowId)) {
    // B 已存在但缺少此頁面：優先從 A 複製已登入頁籤進 B。
    if (source?.id) {
      try { created = await cowDuplicateIntoWindow(source.id, cowWindowId, false); } catch (_) {}
    }
    if (!created?.id) {
      created = await chrome.tabs.create({
        windowId: cowWindowId,
        url: createUrl,
        active: false
      });
      if (created?.id) await cowSetTabOpenMode(created.id, "新开");
    }
  } else {
    // 沒有 B：優先用 A 的已登入頁籤複製品建立新的 B。
    if (source?.id) {
      try {
        const dup = await chrome.tabs.duplicate(source.id);
        if (dup?.id) {
          const win = await chrome.windows.create({
            tabId: dup.id,
            type: "normal",
            width: 1680,
            height: 990,
            focused: true
          });
          if (win?.id) {
            cowWindowId = win.id;
            await chrome.storage.local.set({ cowDedicatedWindowId: cowWindowId });
            const tabs = await chrome.tabs.query({ windowId: cowWindowId });
            created = tabs[0] || null;
            if (created?.id) await cowSetTabOpenMode(created.id, "复制");
          }
        }
      } catch (_) {
        created = null;
      }
    }

    if (!created?.id) {
      const win = await chrome.windows.create({
        url: createUrl,
        type: "normal",
        width: 1680,
        height: 990,
        focused: true
      });

      if (!win || !win.id) {
        throw new Error(`無法建立 COW 獨立視窗：${titleName}`);
      }

      cowWindowId = win.id;
      await chrome.storage.local.set({ cowDedicatedWindowId: cowWindowId });
      const tabs = await chrome.tabs.query({ windowId: cowWindowId });
      created = tabs[0];
      if (created?.id) await cowSetTabOpenMode(created.id, "新开");
    }
  }

  if (!created?.id) {
    throw new Error(`無法自動開啟 ${titleName}`);
  }

  await cowMuteTab(created.id);
  await cowWaitTabComplete(created.id, 30000);
  await cowMuteTab(created.id);
  await cowSetCowTitle(created.id, titleName);

  return await chrome.tabs.get(created.id);
}

function cowQueryDateParts(dateText) {
  const m = String(dateText || "").trim().match(/(?:(\d{4})[/-])?(\d{1,2})[/-](\d{1,2})/);
  if (!m) return null;
  const now = new Date(), y = m[1] ? +m[1] : now.getFullYear(), mo = +m[2], d = +m[3];
  const a = new Date(y, mo - 1, d);
  if (a.getFullYear() !== y || a.getMonth() !== mo - 1 || a.getDate() !== d) return null;
  const b = new Date(y, mo - 1, d); b.setDate(b.getDate() + 1);
  return {
    start:{y:a.getFullYear(),m:a.getMonth()+1,d:a.getDate()},
    end:{y:b.getFullYear(),m:b.getMonth()+1,d:b.getDate()}
  };
}

async function cowSetQueryDateRange(tabId, kind, dateText) {
  const range = cowQueryDateParts(dateText);
  if (!range) return {ok:false,error:`日期格式錯誤：${dateText}`};

  return await cowExec(tabId, async (kind, start, end) => {
    const sleep = ms => new Promise(r => setTimeout(r, ms));
    const visible = el => {
      if (!el) return false;
      const r=el.getBoundingClientRect(), cs=getComputedStyle(el);
      return r.width>0 && r.height>0 && cs.display!=="none" && cs.visibility!=="hidden";
    };
    const txt = el => String(el?.innerText || el?.textContent || "").replace(/\s+/g,"").trim();
    const ymd = x => `${x.y}/${String(x.m).padStart(2,"0")}/${String(x.d).padStart(2,"0")}`;

    function headerYM(t) {
      t=String(t||"");
      let m=t.match(/(\d{4})\s*年\s*(\d{1,2})\s*月/);
      if (m) return {y:+m[1],m:+m[2]};
      m=t.match(/(\d{4})\s*年?\s*(Jan|Feb|Mar|Apr|May|Jun|Jul|Aug|Sep|Oct|Nov|Dec)/i);
      if (m) return {y:+m[1],m:["jan","feb","mar","apr","may","jun","jul","aug","sep","oct","nov","dec"].indexOf(m[2].toLowerCase())+1};
      return null;
    }
    function root() {
      return [...document.querySelectorAll(".ant-calendar-picker-container,.ant-picker-dropdown,.ant-calendar")].filter(visible).pop() || null;
    }
    function panels(r) {
      let ps=[...r.querySelectorAll(".ant-calendar-range-part,.ant-picker-panel")].filter(visible);
      if (!ps.length) ps=[r];
      return ps.map(panel => {
        const hs=[...panel.querySelectorAll(".ant-calendar-header,.ant-picker-header-view,.ant-calendar-month-select")].filter(visible);
        let ym=null;
        for (const h of hs) { ym=headerYM(h.innerText); if (ym) break; }
        if (!ym) ym=headerYM(panel.innerText);
        return ym ? {panel,ym} : null;
      }).filter(Boolean);
    }
    function nav(r, dir) {
      const sel=dir<0?".ant-calendar-prev-month-btn,.ant-picker-header-prev-btn":".ant-calendar-next-month-btn,.ant-picker-header-next-btn";
      return [...r.querySelectorAll(sel)].find(visible) || null;
    }
    async function move(r,target) {
      for(let n=0;n<24;n++) {
        const ps=panels(r);
        if(ps.some(x=>x.ym.y===target.y&&x.ym.m===target.m)) return true;
        if(!ps.length) return false;
        const left=ps[0].ym, right=ps[ps.length-1].ym;
        const targetN=target.y*12+target.m, leftN=left.y*12+left.m, rightN=right.y*12+right.m;
        const dir=targetN<leftN?-1:targetN>rightN?1:0;
        if(!dir) return true;
        const b=nav(r,dir); if(!b) return false;
        b.click(); await sleep(120);
      }
      return false;
    }
    function day(r,target) {
      const p=panels(r).find(x=>x.ym.y===target.y&&x.ym.m===target.m);
      if(!p) return null;
      const cells=[...p.panel.querySelectorAll("td,.ant-picker-cell,.ant-calendar-date")].filter(visible);
      for(const el of cells) {
        if(txt(el)!==String(target.d)) continue;
        const cls=String(el.className||"")+" "+String(el.parentElement?.className||"");
        if(/last-month|next-month|disabled|ant-picker-cell-disabled/i.test(cls)) continue;
        const title=el.getAttribute("title")||el.parentElement?.getAttribute("title")||"";
        const m=title.match(/(\d{4})[-/](\d{1,2})[-/](\d{1,2})/);
        if(m && (+m[1]!==target.y || +m[2]!==target.m || +m[3]!==target.d)) continue;
        return el.closest("td,.ant-picker-cell")||el;
      }
      return null;
    }

    const inputs=[...document.querySelectorAll("input")].filter(visible);
    let dateInput=inputs.find(el=>/开始日期|開始日期|Start date/i.test(el.placeholder||""));
    if(!dateInput && kind==="ms") dateInput=inputs.find(el=>/^\d{4}[-/]\d{2}[-/]\d{2}$/.test(el.value||""));
    if(!dateInput) return {ok:false,error:`${kind==="sfp"?"四方":"MS"}找不到日期欄位`};

    dateInput.click();
    let r=null;
    for(let n=0;n<50;n++){ r=root(); if(r) break; await sleep(100); }
    if(!r) return {ok:false,error:`${kind==="sfp"?"四方":"MS"}日期選單沒有開啟`};

    if(!await move(r,start)) return {ok:false,error:`${kind==="sfp"?"四方":"MS"}無法切換到開始月份`};
    let c=day(r,start); if(!c) return {ok:false,error:`${kind==="sfp"?"四方":"MS"}找不到開始日期 ${ymd(start)}`};
    c.click(); await sleep(120);

    r=root()||r;
    if(!await move(r,end)) return {ok:false,error:`${kind==="sfp"?"四方":"MS"}無法切換到結束月份`};
    c=day(r,end); if(!c) return {ok:false,error:`${kind==="sfp"?"四方":"MS"}找不到結束日期 ${ymd(end)}`};
    c.click(); await sleep(120);

    if(kind==="sfp") {
      r=root()||r;
      const ok=[...r.querySelectorAll("button,a")].find(el=>visible(el)&&["确定","確定"].includes(txt(el)));
      if(!ok) return {ok:false,error:"四方找不到日期確定按鈕"};
      ok.click();
    }

    const a=ymd(start), b=ymd(end);
    const normalizeDateText = value => String(value || "")
      .replace(/-/g, "/")
      .replace(/\s+/g, " ")
      .trim();

    // 不要求一定是兩個獨立 input。
    // 有些頁面會把日期範圍放在同一個欄位，或日期後面帶時間。
    // 只要頁面目前可見的日期欄位中，同時能看到開始日與結束日，就視為設定成功。
    for(let n=0;n<50;n++) {
      const vals=[...document.querySelectorAll("input")]
        .filter(visible)
        .map(el=>normalizeDateText(el.value));

      const joined = vals.join(" | ");
      if(joined.includes(a) && joined.includes(b)) {
        return {ok:true,start:a,end:b};
      }

      // MS 必須以「實際日期輸入欄」為準。
      // 不再用整頁文字判斷，避免查詢結果內剛好出現日期而誤判成功。
      if (kind !== "ms") {
        const rr = root();
        if (!rr) {
          const pageText = normalizeDateText(document.body.innerText);
          if (pageText.includes(a) && pageText.includes(b)) {
            return {ok:true,start:a,end:b};
          }
        }
      }

      await sleep(100);
    }
    return {ok:false,error:`${kind==="sfp"?"四方":"MS"}日期設定驗證失敗：預期 ${a} ～ ${b}`};
  }, [kind, range.start, range.end]);
}


async function cowBringTabToFront(tabId) {
  try {
    const tab = await chrome.tabs.get(tabId);
    if (tab && Number.isInteger(tab.windowId)) {
      // 先讓 COW 視窗成為前景，再切換到實際要操作的分頁。
      await chrome.windows.update(tab.windowId, { focused:true });
    }
    await chrome.tabs.update(tabId, { active:true });
    return true;
  } catch (e) {
    return false;
  }
}


async function cowWaitOrderInputReady(tabId, kind) {
  for (let i = 0; i < 300; i++) {
    try {
      const ready = await cowExec(tabId, (kind) => {
        const visible = el => {
          if (!el) return false;
          const r = el.getBoundingClientRect();
          const cs = getComputedStyle(el);
          return r.width > 0 && r.height > 0 && cs.display !== "none" && cs.visibility !== "hidden";
        };

        const selector = kind === "sfp"
          ? 'input[placeholder="请输入商户单号"]'
          : 'input[placeholder="请输入单号"]';

        const input = [...document.querySelectorAll(selector)].find(visible);
        if (!input) return false;

        // 日期選單若仍蓋在頁面上，先不要貼單號。
        const popups = [...document.querySelectorAll(
          ".ant-calendar-picker-container,.ant-picker-dropdown,.ant-calendar"
        )].filter(visible);

        return popups.length === 0;
      }, [kind]);

      if (ready) return true;
    } catch (e) {}

    await cowSleep(100);
  }
  return false;
}

async function cowQuerySfp(tabId, orderNo, reloadMarker = null, dateText = null) {
  await cowMuteTab(tabId);
  await cowBringTabToFront(tabId);
  await cowSetCowTitle(tabId, "四方");

  const pageReady = await cowWaitPageReady(tabId, "sfp", reloadMarker);
  if (!pageReady) {
    return { ok:false, error:"1.查詢四方錯誤：四方頁面等待完成逾時，仍找不到商戶單號欄或查詢按鈕" };
  }

  if (dateText) {
    const dr = await cowSetQueryDateRange(tabId, "sfp", dateText);
    if (!dr?.ok) return { ok:false, error:"1.查詢四方錯誤：" + (dr?.error || "日期設定失敗") };

    const orderReady = await cowWaitOrderInputReady(tabId, "sfp");
    if (!orderReady) {
      return { ok:false, error:"1.查詢四方錯誤：日期設定完成，但商戶單號欄尚未恢復可操作" };
    }
  }

  const start = await cowExec(tabId, async (order) => {
    function visible(el) {
      if (!el) return false;
      const r = el.getBoundingClientRect();
      const s = getComputedStyle(el);
      return r.width > 0 && r.height > 0 && s.display !== "none" && s.visibility !== "hidden";
    }

    function setNativeValue(el, value) {
      const proto = Object.getPrototypeOf(el);
      const desc = Object.getOwnPropertyDescriptor(proto, "value");
      if (desc && desc.set) desc.set.call(el, value);
      else el.value = value;
      el.dispatchEvent(new Event("input", { bubbles: true }));
      el.dispatchEvent(new Event("change", { bubbles: true }));
    }

    const input = [...document.querySelectorAll('input[placeholder="请输入商户单号"]')].find(visible);
    if (!input) return { ok:false, error:"1.查詢四方錯誤：找不到可見的商戶單號輸入框" };

    input.focus();
    setNativeValue(input, "");
    setNativeValue(input, order);

    const buttons = [...document.querySelectorAll("button")].filter(visible);
    const btn = buttons.find(el => {
      const t = (el.innerText || el.textContent || "").replace(/\s+/g, "");
      return t === "查询" || t === "查詢";
    }) || buttons.find(el => {
      const t = (el.innerText || el.textContent || "").replace(/\s+/g, "");
      return t.includes("查询") || t.includes("查詢");
    });

    if (!btn) return { ok:false, error:"1.查詢四方錯誤：找不到可見的查詢按鈕" };

    btn.scrollIntoView({ block:"center", inline:"center" });
    btn.click();
    return { ok:true };
  }, [orderNo]);

  if (!start || !start.ok) return start || { ok:false, error:"1.查詢四方錯誤" };

  // 不再比較前後表格內容；只等待這次查詢的目標單號真正出現在結果列
  for (let i = 0; i < 40; i++) {
    await cowSleep(250);
    const result = await cowExec(tabId, (order) => {
      const num = (v) => {
        const m = String(v ?? "").replace(/,/g, "").match(/-?\d+(?:\.\d+)?/);
        return m ? Number(m[0]) : 0;
      };

      const rows = [...document.querySelectorAll("tr")].map(tr =>
        [...tr.querySelectorAll("th,td")].map(td => (td.innerText || td.textContent || "").trim())
      ).filter(r => r.length);

      const row = rows.find(r => r.some(c => String(c).includes(order)));
      if (!row) return null;

      if (row.length < 15) {
        return { ok:false, error:"1.查詢四方錯誤：資料欄位不足", row };
      }

      const operationText = row[17] ? String(row[17]).trim() : "";
      if (!operationText.includes("加扣款")) {
        return {
          ok:false,
          error:"1.查詢四方錯誤：操作欄位沒有加扣款",
          row,
          operationText
        };
      }

      return {
        ok:true,
        internalOrderNo:String(row[0] || "").trim(),
        merchantOrderNo:String(row[3] || "").trim(),
        merchantFee:num(row[13]),
        channelFee:num(row[14]),
        operationText,
        row
      };
    }, [orderNo]);

    if (result) return result;
  }

  return { ok:false, error:`1.查詢四方錯誤：重新整理並查詢後，仍查無單號 ${orderNo}` };
}


async function cowSelectMsPlatform(tabId, platformCode) {
  return await cowExec(tabId, async (platformCode) => {
    const wanted = String(platformCode || "").trim().toUpperCase();

    const visible = el => {
      if (!el) return false;
      const r = el.getBoundingClientRect();
      const s = getComputedStyle(el);
      return r.width > 0 && r.height > 0 && s.display !== "none" &&
             s.visibility !== "hidden" && Number(s.opacity || "1") !== 0;
    };

    const norm = v => String(v == null ? "" : v).replace(/\s+/g, "").trim().toUpperCase();

    const setNativeValue = (el, value) => {
      const proto = Object.getPrototypeOf(el);
      const desc = Object.getOwnPropertyDescriptor(proto, "value");
      if (desc && desc.set) desc.set.call(el, value);
      else el.value = value;
      el.dispatchEvent(new Event("input", { bubbles:true }));
      el.dispatchEvent(new Event("change", { bubbles:true }));
    };

    const waitFor = (predicate, timeoutMs = 15000) => new Promise(resolve => {
      let done = false, observer = null, timer = null;
      const finish = value => {
        if (done) return;
        done = true;
        if (observer) observer.disconnect();
        if (timer) clearTimeout(timer);
        resolve(value);
      };
      const check = () => {
        try {
          const value = predicate();
          if (value) finish(value);
        } catch (_) {}
      };
      observer = new MutationObserver(check);
      observer.observe(document.documentElement || document.body, {
        childList:true, subtree:true, attributes:true,
        attributeFilter:["class","style","value","title","aria-label"]
      });
      timer = setTimeout(() => finish(null), timeoutMs);
      check();
    });

    const readVisiblePlatform = () => {
      const texts = [];

      for (const el of document.querySelectorAll("input.ant-cascader-input,input")) {
        if (!visible(el)) continue;
        const value = norm(el.value);
        if (value) texts.push(value);
      }

      for (const el of document.querySelectorAll(
        ".ant-cascader-picker-label,.ant-select-selection-selected-value,.ant-select-selection-item,.ant-select-selector,.ant-cascader-picker,span,div"
      )) {
        if (!visible(el)) continue;
        const t = norm(el.innerText || el.textContent);
        if (t && t.length <= 40) texts.push(t);
      }

      const body = norm(document.body?.innerText || "");
      if (body.includes("平台:" + wanted) || body.includes("平台：" + wanted)) return wanted;

      if (texts.some(t => t === wanted)) return wanted;

      if (texts.some(t =>
        t === "平台:" + wanted ||
        t === "平台：" + wanted ||
        t.endsWith("平台:" + wanted) ||
        t.endsWith("平台：" + wanted)
      )) return wanted;

      return "";
    };

    if (readVisiblePlatform() === wanted) {
      return { ok:true, platform:wanted, unchanged:true, verifyMethod:"visible_platform" };
    }

    const platformInput = [...document.querySelectorAll("input.ant-cascader-input")].find(visible);
    if (!platformInput) {
      return { ok:false, error:"2.查詢MS錯誤：找不到平台欄位" };
    }

    platformInput.click();
    setNativeValue(platformInput, "");
    setNativeValue(platformInput, wanted);

    const option = await waitFor(() => {
      const options = [...document.querySelectorAll(".ant-cascader-menu-item")].filter(visible);
      return options.find(el => {
        const t = norm(el.innerText || el.textContent);
        return t === wanted || t.includes(wanted);
      }) || null;
    }, 10000);

    if (option) {
      option.click();
    } else {
      platformInput.dispatchEvent(new KeyboardEvent("keydown", {
        key:"Enter", code:"Enter", bubbles:true
      }));
      platformInput.dispatchEvent(new KeyboardEvent("keyup", {
        key:"Enter", code:"Enter", bubbles:true
      }));
    }

    const committed = await waitFor(() => readVisiblePlatform() === wanted, 15000);

    if (!committed) {
      return {
        ok:false,
        error:`2.查詢MS錯誤：平台 ${wanted} 選擇後畫面未確認完成`
      };
    }

    return { ok:true, platform:wanted, verifyMethod:"visible_platform" };
  }, [platformCode]);
}

async function cowQueryMs(tabId, platform, orderNo, reloadMarker = null, dateText = null) {
  await cowMuteTab(tabId);
  await cowBringTabToFront(tabId);
  await cowSetCowTitle(tabId, "MS");

  const pageReady = await cowWaitPageReady(tabId, "ms", reloadMarker);
  if (!pageReady) {
    return { ok:false, error:"2.查詢MS錯誤：MS頁面等待完成逾時，仍找不到單號欄或查詢按鈕" };
  }

  // IMPORTANT: MS platform selection can re-render/reset the filter form.
  // Therefore platform must be committed FIRST, and only then set the date.
  const platformResult = await cowSelectMsPlatform(tabId, platform);
  if (!platformResult?.ok) {
    return platformResult || { ok:false, error:"2.查詢MS錯誤：平台選擇失敗" };
  }

  if (dateText) {
    const dr = await cowSetQueryDateRange(tabId, "ms", dateText);
    if (!dr?.ok) return { ok:false, error:"2.查詢MS錯誤：" + (dr?.error || "日期設定失敗") };

    const orderReady = await cowWaitOrderInputReady(tabId, "ms");
    if (!orderReady) {
      return { ok:false, error:"2.查詢MS錯誤：日期設定完成，但單號欄尚未恢復可操作" };
    }
  }

  const prep = await cowExec(tabId, async (order) => {
    function visible(el) {
      if (!el) return false;
      const r = el.getBoundingClientRect();
      const s = getComputedStyle(el);
      return r.width > 0 && r.height > 0 && s.display !== "none" && s.visibility !== "hidden";
    }

    function setNativeValue(el, value) {
      const proto = Object.getPrototypeOf(el);
      const desc = Object.getOwnPropertyDescriptor(proto, "value");
      if (desc && desc.set) desc.set.call(el, value);
      else el.value = value;
      el.dispatchEvent(new Event("input", { bubbles: true }));
      el.dispatchEvent(new Event("change", { bubbles: true }));
    }

    const input = [...document.querySelectorAll('input[placeholder="请输入单号"]')].find(visible);
    if (!input) return { ok:false, error:"2.查詢MS錯誤：找不到可見的單號輸入框" };

    input.focus();
    setNativeValue(input, "");
    setNativeValue(input, order);

    const buttons = [...document.querySelectorAll("button")].filter(visible);
    const btn = buttons.find(el => {
      const t = (el.innerText || el.textContent || "").replace(/\s+/g, "");
      return t === "查询" || t === "查詢";
    }) || buttons.find(el => {
      const t = (el.innerText || el.textContent || "").replace(/\s+/g, "");
      return t.includes("查询") || t.includes("查詢");
    });

    if (!btn) return { ok:false, error:"2.查詢MS錯誤：找不到可見的查詢按鈕" };

    btn.scrollIntoView({ block:"center", inline:"center" });
    btn.click();
    return { ok:true };
  }, [orderNo]);

  if (!prep || !prep.ok) return prep || { ok:false, error:"2.查詢MS錯誤" };

  for (let i = 0; i < 40; i++) {
    await cowSleep(250);
    const result = await cowExec(tabId, (order) => {
      const num = (v) => {
        const m = String(v ?? "").replace(/,/g, "").match(/-?\d+(?:\.\d+)?/);
        return m ? Number(m[0]) : 0;
      };

      const rows = [...document.querySelectorAll("tr")].map(tr =>
        [...tr.querySelectorAll("th,td")].map(td => (td.innerText || td.textContent || "").trim())
      ).filter(r => r.length);

      const row = rows.find(r => r.some(c => String(c).includes(order)));
      if (!row) return null;

      let idx = row.findIndex(c => String(c).trim() === order);
      if (idx < 0) idx = row.findIndex(c => String(c).includes(order));
      if (idx < 0) return null;
      if (row.length <= idx + 7) {
        return { ok:false, error:"2.查詢MS錯誤：資料欄位不足", row };
      }

      return {
        ok:true,
        orderNo:String(row[idx] || "").trim(),
        status:String(row[idx+1] || "").trim(),
        member:String(row[idx+2] || "").trim(),
        bank:String(row[idx+3] || "").trim(),
        rmbAmount:num(row[idx+4]),
        systemFee:num(row[idx+5]),
        bankFee:num(row[idx+6]),
        actualPayout:num(row[idx+7]),
        row
      };
    }, [orderNo]);

    if (result) return result;
  }

  return { ok:false, error:`2.查詢MS錯誤：重新整理並查詢後，仍查無單號 ${orderNo}` };
}


const COW_PAYOUT_FEE_FLOOR_PLATFORMS = new Set(["XY","OL","LS","XH"]);

function cowNum(value) {
  const n = Number(value);
  return Number.isFinite(n) ? n : 0;
}

function cowFmt(value) {
  const n = cowNum(value);
  if (Math.abs(n - Math.trunc(n)) < 1e-9) return String(Math.trunc(n));
  return n.toFixed(8).replace(/0+$/, "").replace(/\.$/, "");
}

function cowAmountValue(value) {
  if (value == null) return null;
  const n = cowNum(value);
  return Math.abs(n - Math.trunc(n)) < 1e-9 ? Math.trunc(n) : n;
}

function cowParseInputDate(dateText) {
  if (!dateText) return null;
  const text = String(dateText).trim();
  const m = text.match(/(?:(\d{4})[/-])?(\d{1,2})[/-](\d{1,2})/);
  if (!m) return null;

  const now = new Date();
  const year = m[1] ? Number(m[1]) : now.getFullYear();
  const month = Number(m[2]);
  const day = Number(m[3]);

  const d = new Date(year, month - 1, day);
  if (d.getFullYear() !== year || d.getMonth() !== month - 1 || d.getDate() !== day) return null;
  return d;
}

function cowEffectiveDateText(dateText) {
  if (!dateText) return null;
  const d = cowParseInputDate(dateText);
  if (!d) return String(dateText).trim();

  const now = new Date();
  const isToday =
    d.getFullYear() === now.getFullYear() &&
    d.getMonth() === now.getMonth() &&
    d.getDate() === now.getDate();

  return isToday ? null : String(dateText).trim();
}

function cowPrefixDate(dateText) {
  const effective = cowEffectiveDateText(dateText);
  return effective ? effective + " " : "";
}

function cowNormSplitText(value) {
  if (value == null) return null;
  return String(value).trim().replace(/\s+/g, "").replace(/拆账/g, "").replace(/拆账/g, "");
}

function cowCompareExpected(parsed, actualPayoutN, splitText) {
  const hasExpectedActual = parsed.expectedActualPayout != null;
  const hasExpectedSplit = !!parsed.expectedSplitText;

  if (!hasExpectedActual && !hasExpectedSplit) {
    return { status:null, message:null };
  }

  const errors = [];

  if (hasExpectedActual) {
    const expected = cowNum(parsed.expectedActualPayout);
    if (Math.abs(expected - actualPayoutN) >= 1e-9) {
      errors.push(`出款不同：輸入出款${cowFmt(expected)}，查詢出款${cowFmt(actualPayoutN)}`);
    }
  }

  if (hasExpectedSplit) {
    const expectedSplit = cowNormSplitText(parsed.expectedSplitText);
    const actualSplit = cowNormSplitText(splitText);
    if (expectedSplit !== actualSplit) {
      errors.push(`拆账不同：輸入拆账${expectedSplit}，計算拆账${actualSplit}`);
    }
  }

  if (errors.length) {
    return { status:"比對不同", message:errors.join("；") };
  }

  return { status:"比對相同", message:"輸入出款/拆账與查詢計算結果相同" };
}

function cowBuildPreview(parsed, sfp, ms) {
  const platform = parsed.platform || null;
  const orderNo = parsed.orderNo || null;
  const member = parsed.member || null;
  const repayAmount = cowNum(parsed.repayAmount);
  const dateText = parsed.dateText || null;
  const effectiveDateText = cowEffectiveDateText(dateText);

  const merchantFeeN = cowNum(sfp?.merchantFee);
  const channelFeeN = cowNum(sfp?.channelFee);
  const rmbAmountN = cowNum(ms?.rmbAmount);
  const actualPayoutN = cowNum(ms?.actualPayout);
  const bankFeeN = cowNum(ms?.bankFee);
  const systemFeeN = cowNum(ms?.systemFee);

  const base = {
    ok:false,
    status:"異常",
    error:null,
    platform,
    orderNo,
    member,
    dateText,
    effectiveDateText,
    repayAmount:cowAmountValue(repayAmount),
    merchantFee:cowAmountValue(merchantFeeN),
    channelFee:cowAmountValue(channelFeeN),
    rmbAmount:cowAmountValue(rmbAmountN),
    actualPayout:cowAmountValue(actualPayoutN),
    bankFee:cowAmountValue(bankFeeN),
    systemFee:cowAmountValue(systemFeeN),
    splitText:null,
    isSplit:false,
    isSpecial:false,
    payoutFeeRepay:0,
    msAmount:null,
    msRemark:null,
    sfpOrderAmount:null,
    sfpRemarkPrefix:null,
    platformFirstAmount:null,
    platformFirstRemark:null,
    platformSecondAmount:null,
    platformSecondRemark:null,
    needPlatformSecond:false,
    expectedActualPayout:cowAmountValue(parsed.expectedActualPayout),
    expectedSplitText:parsed.expectedSplitText || null,
    compareStatus:null,
    compareMessage:null
  };

  if (!orderNo) {
    base.error = "0.解析錯誤：缺少單號";
    return base;
  }
  if (!member) {
    base.error = "0.解析錯誤：缺少會員名";
    return base;
  }
  if (!(repayAmount > 0)) {
    base.error = "0.解析錯誤：補回金額必須大於0";
    return base;
  }

  const sfpOrderText = String(sfp?.internalOrderNo || "").trim();
  const sfpMerchantOrderText = String(sfp?.merchantOrderNo || "").trim();
  const msOrderText = String(ms?.orderNo || "").trim();
  const inputOrderText = String(orderNo).trim();
  const platformText = String(platform || "").toUpperCase().trim();

  if (COW_SPECIAL_WG_PLATFORMS.has(platformText)) {
    if (sfpOrderText && msOrderText && sfpOrderText !== msOrderText) {
      base.error = `3.比對單號錯誤：四方單號 ${sfpOrderText} 與 MS 單號 ${msOrderText} 不一致`;
      return base;
    }
  } else {
    if (sfpMerchantOrderText && sfpMerchantOrderText !== inputOrderText) {
      base.error = `3.比對單號錯誤：四方商戶單號 ${sfpMerchantOrderText} 與輸入單號 ${inputOrderText} 不一致`;
      return base;
    }

    if (msOrderText && msOrderText !== inputOrderText) {
      base.error = `3.比對單號錯誤：輸入單號 ${inputOrderText} 與 MS 單號 ${msOrderText} 不一致`;
      return base;
    }
  }

  const isFullRepay = Math.abs(repayAmount - actualPayoutN) < 1e-9;
  const isRmbActualPlusFee = Math.abs(rmbAmountN - (actualPayoutN + systemFeeN)) < 1e-9;
  const isSpecial = systemFeeN > 0 && isRmbActualPlusFee && isFullRepay;

  const isSplit = Math.abs(actualPayoutN - repayAmount) >= 1e-9;
  const splitText = isSplit
    ? `${cowFmt(actualPayoutN - repayAmount)}+${cowFmt(repayAmount)}`
    : "無拆账";

  const compared = cowCompareExpected(parsed, actualPayoutN, splitText);

  if (compared.status === "比對不同") {
    return {
      ...base,
      error:"5.比對錯誤：" + compared.message,
      isSpecial,
      isSplit,
      splitText,
      compareStatus:compared.status,
      compareMessage:compared.message
    };
  }

  if (isSpecial) {
    if (repayAmount + systemFeeN > rmbAmountN + 1e-9) {
      return {
        ...base,
        error:`5.判斷金額錯誤：補回金額${cowFmt(repayAmount)}+系統手续费${cowFmt(systemFeeN)}大於人民幣金額${cowFmt(rmbAmountN)}`,
        isSpecial:true,
        isSplit,
        splitText,
        compareStatus:compared.status,
        compareMessage:compared.message
      };
    }
  } else {
    if (repayAmount > actualPayoutN + 1e-9) {
      return {
        ...base,
        error:`5.判斷金額錯誤：補回金額${cowFmt(repayAmount)}大於實際出款金額${cowFmt(actualPayoutN)}`,
        isSpecial:false,
        isSplit,
        splitText,
        compareStatus:compared.status,
        compareMessage:compared.message
      };
    }
  }

  let payoutFeeRepay = 0;
  if (actualPayoutN > 0 && systemFeeN > 0 && !isSpecial) {
    const raw = repayAmount / actualPayoutN * systemFeeN;
    payoutFeeRepay = COW_PAYOUT_FEE_FLOOR_PLATFORMS.has(platformText)
      ? Math.floor(raw)
      : Math.ceil(raw);
  }

  const datePrefix = cowPrefixDate(dateText);

  let msRemark;
  let msAmount;
  let platformFirstAmount;
  let platformFirstRemark;
  let needPlatformSecond;
  let platformSecondAmount;
  let platformSecondRemark;

  if (isSpecial) {
    msRemark =
      datePrefix +
      String(member) +
      `第三方出款失败补回（提款${cowFmt(rmbAmountN)}手续费${cowFmt(systemFeeN)}）`;

    msAmount = repayAmount;
    platformFirstAmount = rmbAmountN;
    platformFirstRemark = datePrefix + "2出款失败补回";
    needPlatformSecond = false;
    platformSecondAmount = null;
    platformSecondRemark = null;
  } else {
    msRemark = isSplit
      ? datePrefix + String(member) + "第三方出款失败补回拆账"
      : datePrefix + String(member) + "第三方出款失败补回";

    msAmount = repayAmount;
    platformFirstAmount = repayAmount;
    platformFirstRemark = datePrefix + "2出款失败补回";

    needPlatformSecond = payoutFeeRepay > 0;
    if (needPlatformSecond) {
      platformSecondAmount = payoutFeeRepay;
      platformSecondRemark = datePrefix + "出款手续费补回";
    } else {
      platformSecondAmount = null;
      platformSecondRemark = null;
    }
  }

  return {
    ...base,
    ok:true,
    status:"查詢完成",
    error:null,
    splitText,
    isSplit,
    isSpecial,
    payoutFeeRepay:cowAmountValue(payoutFeeRepay),
    msAmount:cowAmountValue(msAmount),
    msRemark,
    sfpOrderAmount:cowAmountValue(repayAmount),
    sfpRemarkPrefix:effectiveDateText,
    platformFirstAmount:cowAmountValue(platformFirstAmount),
    platformFirstRemark,
    platformSecondAmount:platformSecondAmount == null ? null : cowAmountValue(platformSecondAmount),
    platformSecondRemark,
    needPlatformSecond,
    compareStatus:compared.status,
    compareMessage:compared.message
  };
}


const COW_MS_WORK_URL = "https://ms.rcppay.com/management/payment/third-party";
const COW_SFP_WORK_URL = "https://sfp.csussr.com/management/transaction-record/withdrawal-slips";
const COW_SFP_MERCHANT_BALANCE_URL = "https://sfp.csussr.com/management/tenant-manage/tenant-balance-transactions";
const COW_SFP_CHANNEL_BALANCE_URL = "https://sfp.csussr.com/management/account-manage/payment-account-balance-transactions";

function cowNumberSame(a, b) {
  const na = Number(a), nb = Number(b);
  if (Number.isFinite(na) && Number.isFinite(nb)) return Math.abs(na - nb) < 1e-9;
  return String(a ?? "").trim() === String(b ?? "").trim();
}

function cowTextSame(a, b) {
  return String(a ?? "").replace(/\s+/g, "").trim() === String(b ?? "").replace(/\s+/g, "").trim();
}

async function cowEnsureWorkPage(tabId, targetUrl, titleName) {
  if (!Number.isInteger(tabId)) throw new Error(`找不到 ${titleName} 分頁`);
  let tab = await chrome.tabs.get(tabId);
  let correct = false;
  try {
    const current = new URL(String(tab.url || ""));
    const target = new URL(targetUrl);
    correct = current.hostname === target.hostname && current.pathname === target.pathname;
  } catch (_) {}

  if (!correct) {
    await chrome.tabs.update(tabId, { url: targetUrl });
    const loaded = await cowWaitTabComplete(tabId, 30000);
    if (!loaded) throw new Error(`${titleName} 自動定位到指定頁面逾時`);
    tab = await chrome.tabs.get(tabId);
  }

  await cowMuteTab(tabId);
  await cowSetCowTitle(tabId, titleName);
  return tab;
}

function cowValidateMsSnapshot(saved, current) {
  if (!saved || !current) return { ok:false, error:"MS 缺少比對資料" };
  const diffs = [];
  if (!cowTextSame(saved.orderNo, current.orderNo)) diffs.push(`單號 ${saved.orderNo || "-"} → ${current.orderNo || "-"}`);
  if (!cowTextSame(saved.member, current.member)) diffs.push(`會員 ${saved.member || "-"} → ${current.member || "-"}`);
  if (!cowNumberSame(saved.rmbAmount, current.rmbAmount)) diffs.push(`人民幣金額 ${saved.rmbAmount} → ${current.rmbAmount}`);
  if (!cowNumberSame(saved.actualPayout, current.actualPayout)) diffs.push(`實際出款 ${saved.actualPayout} → ${current.actualPayout}`);
  if (!cowNumberSame(saved.systemFee, current.systemFee)) diffs.push(`系統手續費 ${saved.systemFee} → ${current.systemFee}`);
  if (!cowNumberSame(saved.bankFee, current.bankFee)) diffs.push(`出款手續費 ${saved.bankFee} → ${current.bankFee}`);
  return diffs.length
    ? { ok:false, error:`MS 資料與原查詢不一致：${diffs.join("；")}` }
    : { ok:true };
}

function cowValidateSfpSnapshot(saved, current) {
  if (!saved || !current) return { ok:false, error:"四方缺少比對資料" };
  const diffs = [];
  if (!cowTextSame(saved.internalOrderNo, current.internalOrderNo)) diffs.push(`四方單號 ${saved.internalOrderNo || "-"} → ${current.internalOrderNo || "-"}`);
  if (!cowTextSame(saved.merchantOrderNo, current.merchantOrderNo)) diffs.push(`商戶單號 ${saved.merchantOrderNo || "-"} → ${current.merchantOrderNo || "-"}`);
  if (!cowNumberSame(saved.merchantFee, current.merchantFee)) diffs.push(`商戶手續費 ${saved.merchantFee} → ${current.merchantFee}`);
  if (!cowNumberSame(saved.channelFee, current.channelFee)) diffs.push(`通道手續費 ${saved.channelFee} → ${current.channelFee}`);
  return diffs.length
    ? { ok:false, error:`四方資料與原查詢不一致：${diffs.join("；")}` }
    : { ok:true };
}

async function cowRunRepayQuery(rawText) {
  let parsed;
  try {
    parsed = cowParseRepayText(rawText);
  } catch (e) {
    return { ok:false, error:String(e.message || e) };
  }

  let sfpTab;
  let msTab;

  try {
    sfpTab = await cowEnsureTab(
      ["sfp.csussr.com"],
      COW_SFP_WORK_URL,
      "四方"
    );
  } catch (e) {
    return { ok:false, error:"1.查詢四方錯誤：自動開啟四方失敗：" + String(e.message || e) };
  }

  try {
    msTab = await cowEnsureTab(
      ["ms.rcppay.com"],
      COW_MS_WORK_URL,
      "MS"
    );
  } catch (e) {
    return { ok:false, error:"2.查詢MS錯誤：自動開啟MS失敗：" + String(e.message || e) };
  }

  if (!sfpTab || !sfpTab.id) {
    return { ok:false, error:"1.查詢四方錯誤：無法取得四方頁面" };
  }
  if (!msTab || !msTab.id) {
    return { ok:false, error:"2.查詢MS錯誤：無法取得MS頁面" };
  }

  // 查詢前不依賴使用者目前停留頁面；四方與 MS 都先自動定位到固定工作頁。
  try {
    sfpTab = await cowEnsureWorkPage(sfpTab.id, COW_SFP_WORK_URL, "四方");
  } catch (e) {
    return { ok:false, error:"1.查詢四方錯誤：切換到四方提現記錄頁失敗：" + String(e.message || e) };
  }

  try {
    msTab = await cowEnsureWorkPage(msTab.id, COW_MS_WORK_URL, "MS");
  } catch (e) {
    return { ok:false, error:"2.查詢MS錯誤：切換到MS第三方出款頁失敗：" + String(e.message || e) };
  }

  await cowMuteTab(sfpTab.id);
  await cowMuteTab(msTab.id);
  await cowSetCowTitle(sfpTab.id, "四方");
  await cowSetCowTitle(msTab.id, "MS");

  // 查詢開始時，只把這次查詢需要的四方 + MS 同時刷新。
  // 其他平台 / WG 分頁不動。
  const reloadMarkers = await cowReloadNeededTabs([sfpTab.id, msTab.id]);

  const sfp = await cowQuerySfp(
    sfpTab.id,
    parsed.orderNo,
    reloadMarkers[sfpTab.id] || null,
    parsed.dateText || null
  );
  if (!sfp || !sfp.ok) {
    return { ok:false, error:sfp?.error || "1.查詢四方失敗", parsed, sfp };
  }

  const msQueryOrderNo = COW_SPECIAL_WG_PLATFORMS.has(parsed.platform)
    ? sfp.internalOrderNo
    : parsed.orderNo;

  if (!msQueryOrderNo) {
    return { ok:false, error:"1.查詢四方錯誤：找不到四方單號，無法查詢 MS", parsed, sfp };
  }

  const ms = await cowQueryMs(
    msTab.id,
    parsed.platform,
    msQueryOrderNo,
    reloadMarkers[msTab.id] || null,
    parsed.dateText || null
  );
  if (!ms || !ms.ok) {
    return { ok:false, error:ms?.error || "2.查詢MS失敗", parsed, sfp, ms };
  }

  const preview = cowBuildPreview(parsed, sfp, ms);
  if (!preview.ok) {
    return {
      ok:false,
      error:preview.error || "5.判斷錯誤",
      parsed,
      sfp,
      ms,
      preview,
      msQueryOrderNo,
      queryMode:COW_SPECIAL_WG_PLATFORMS.has(parsed.platform) ? "WG" : "normal"
    };
  }

  return {
    ok:true,
    parsed,
    sfp,
    ms,
    preview,
    msQueryOrderNo,
    queryMode:COW_SPECIAL_WG_PLATFORMS.has(parsed.platform) ? "WG" : "normal"
  };

}


async function cowFindCurrentMsTab() {
  const cowWindowId = await cowGetDedicatedWindowId();
  if (!Number.isInteger(cowWindowId)) return null;

  // 只在 COW 獨立視窗 B 內找 MS；絕不掃描 / 操作使用者原本視窗 A。
  const tabs = await chrome.tabs.query({ windowId: cowWindowId });
  const cowNamed = tabs.find(t => /^COW\s*[|｜]\s*MS/.test(String(t.title || "")));
  if (cowNamed) return cowNamed;

  const sameSite = tabs.find(tab => {
    try { return new URL(String(tab.url || "")).hostname === "ms.rcppay.com"; }
    catch (_) { return false; }
  });
  return sameSite || null;
}

async function cowOperateMsRepay(lastQuery) {
  if (!lastQuery || !lastQuery.ok || !lastQuery.preview) {
    return { ok:false, error:"6.操作MS錯誤：請先完成查詢" };
  }

  const p = lastQuery.preview || {};
  const sfp = lastQuery.sfp || {};
  const orderNo = String(lastQuery.msQueryOrderNo || lastQuery.ms?.orderNo || "").trim();
  const amount = p.msAmount;
  const merchantFee = p.isSplit ? 0 : (sfp.merchantFee ?? p.merchantFee ?? 0);
  const remark = String(p.msRemark || "");

  if (!orderNo) {
    return { ok:false, error:"6.操作MS錯誤：缺少MS單號" };
  }
  if (amount === null || amount === undefined || amount === "") {
    return { ok:false, error:"6.操作MS錯誤：缺少MS補回金額" };
  }
  if (!remark) {
    return { ok:false, error:"6.操作MS錯誤：缺少MS備註" };
  }

  let tab = await cowFindCurrentMsTab();
  if (!tab || !tab.id) {
    return { ok:false, error:"6.操作MS錯誤：找不到已查詢的MS頁面" };
  }

  // 防呆：操作前重新定位到 MS 第三方出款，並用「原查詢單號」再查一次。
  // 不相信使用者目前畫面上的查詢結果，避免查詢後又手動查了別的會員/單號而誤操作。
  try {
    tab = await cowEnsureWorkPage(tab.id, COW_MS_WORK_URL, "MS");
  } catch (e) {
    return { ok:false, error:"6.操作MS錯誤：自動定位第三方出款失敗：" + String(e.message || e) };
  }

  const msRecheck = await cowQueryMs(
    tab.id,
    String(lastQuery.parsed?.platform || ""),
    orderNo,
    null,
    lastQuery.parsed?.dateText || null
  );
  if (!msRecheck?.ok) {
    return { ok:false, error:"6.操作MS錯誤：操作前重新查詢原單失敗：" + (msRecheck?.error || "查無資料") };
  }
  const msSnapshotCheck = cowValidateMsSnapshot(lastQuery.ms, msRecheck);
  if (!msSnapshotCheck.ok) {
    return { ok:false, error:"6.操作MS錯誤：安全檢查停止操作；" + msSnapshotCheck.error };
  }

  await cowMuteTab(tab.id);
  await cowSetCowTitle(tab.id, "MS");
  await cowBringTabToFront(tab.id);

  let results;
  try {
    results = await chrome.scripting.executeScript({
      target: { tabId: tab.id },
      args: [orderNo, String(amount), String(merchantFee ?? 0), remark],
      func: async (orderNo, amountText, feeText, remarkText) => {
        const norm = v => String(v == null ? "" : v).replace(/\s+/g, "").trim();

        const visible = el => {
          if (!el) return false;
          const r = el.getBoundingClientRect();
          const s = getComputedStyle(el);
          return r.width > 0 && r.height > 0 && s.display !== "none" &&
                 s.visibility !== "hidden" && Number(s.opacity || "1") !== 0;
        };

        const waitFor = (predicate, timeoutMs = 30000) => new Promise(resolve => {
          let finished = false;
          let observer = null;
          let timer = null;

          const finish = value => {
            if (finished) return;
            finished = true;
            if (observer) observer.disconnect();
            if (timer) clearTimeout(timer);
            resolve(value);
          };

          const check = () => {
            try {
              const value = predicate();
              if (value) finish(value);
            } catch (_) {}
          };

          observer = new MutationObserver(check);
          observer.observe(document.documentElement || document.body, {
            childList:true, subtree:true, attributes:true,
            attributeFilter:["class","style","disabled","value"]
          });

          timer = setTimeout(() => finish(null), timeoutMs);
          check();
        });

        const clickLikeUser = el => {
          if (!el) return false;
          el.scrollIntoView({ block:"center", inline:"center" });
          for (const type of ["mouseover","mousedown","mouseup","click"]) {
            el.dispatchEvent(new MouseEvent(type, {
              bubbles:true, cancelable:true, view:window
            }));
          }
          return true;
        };

        const setNativeValue = (el, value) => {
          if (!el) return false;
          el.focus();

          const proto = el instanceof HTMLTextAreaElement
            ? HTMLTextAreaElement.prototype
            : HTMLInputElement.prototype;

          const setter = Object.getOwnPropertyDescriptor(proto, "value")?.set;
          if (!setter) return false;

          setter.call(el, "");
          el.dispatchEvent(new Event("input", { bubbles:true }));
          el.dispatchEvent(new Event("change", { bubbles:true }));

          setter.call(el, String(value));
          el.dispatchEvent(new Event("input", { bubbles:true }));
          el.dispatchEvent(new Event("change", { bubbles:true }));
          el.dispatchEvent(new KeyboardEvent("keyup", { bubbles:true, key:"Unidentified" }));
          el.blur();
          el.dispatchEvent(new Event("blur", { bubbles:true }));
          return true;
        };

        const findVisible = selector =>
          Array.from(document.querySelectorAll(selector)).find(visible) || null;

        // 1. Find current queried row and click "出款失败补回".
        const rows = Array.from(document.querySelectorAll("tr")).filter(visible);
        let targetRow = rows.find(tr => norm(tr.innerText || tr.textContent).includes(norm(orderNo))) || null;

        let action = null;
        if (targetRow) {
          action = Array.from(targetRow.querySelectorAll("button,a,span,div"))
            .find(el => visible(el) && norm(el.innerText || el.textContent) === "出款失败补回") || null;
        }

        if (!action) {
          action = Array.from(document.querySelectorAll("button,a,span,div"))
            .find(el => visible(el) && norm(el.innerText || el.textContent) === "出款失败补回") || null;
        }

        if (!action) {
          return {
            ok:false,
            error:"6.操作MS錯誤：目前查詢結果找不到「出款失敗補回」按鈕"
          };
        }

        clickLikeUser(action.closest("button,a") || action);

        // 2. Observe modal until amount / fee / remark fields exist.
        const fields = await waitFor(() => {
          const amount = findVisible('input[placeholder="请输入人民币金额"]');
          const fee = findVisible('input[placeholder="请输入手续费"]');
          const remark = findVisible('textarea[placeholder="请输入备注"]');
          return amount && fee && remark ? { amount, fee, remark } : null;
        }, 30000);

        if (!fields) {
          return {
            ok:false,
            error:"6.操作MS錯誤：已點擊出款失敗補回，但找不到補回彈窗欄位"
          };
        }

        // 3. Fill amount, fee, remark. Date field is deliberately untouched.
        setNativeValue(fields.amount, amountText);
        setNativeValue(fields.fee, feeText);
        setNativeValue(fields.remark, remarkText);

        const actualAmount = String(fields.amount.value ?? "").trim();
        const actualFee = String(fields.fee.value ?? "").trim();
        const actualRemark = String(fields.remark.value ?? "").trim();

        const numericEqual = (a, b) => {
          const na = Number(String(a).replace(/,/g, ""));
          const nb = Number(String(b).replace(/,/g, ""));
          return Number.isFinite(na) && Number.isFinite(nb)
            ? Math.abs(na - nb) < 1e-9
            : String(a) === String(b);
        };

        if (!numericEqual(actualAmount, amountText)) {
          return {
            ok:false,
            error:`6.操作MS錯誤：補回金額填寫失敗（預期 ${amountText}，目前 ${actualAmount}）`
          };
        }
        if (!numericEqual(actualFee, feeText)) {
          return {
            ok:false,
            error:`6.操作MS錯誤：手续费填寫失敗（預期 ${feeText}，目前 ${actualFee}）`
          };
        }
        if (actualRemark !== remarkText) {
          return {
            ok:false,
            error:"6.操作MS錯誤：備註填寫失敗"
          };
        }

        // 4. Click visible modal confirm.
        const modal = fields.amount.closest('.ant-modal, .ant-modal-wrap, [role="dialog"]') ||
                      fields.amount.closest("form") ||
                      document.body;

        let confirm = Array.from(modal.querySelectorAll("button,a"))
          .find(el => visible(el) && norm(el.innerText || el.textContent) === "确定") || null;

        if (!confirm) {
          confirm = Array.from(document.querySelectorAll("button,a"))
            .find(el => visible(el) && norm(el.innerText || el.textContent) === "确定") || null;
        }

        if (!confirm) {
          return {
            ok:false,
            error:"6.操作MS錯誤：找不到「確定」按鈕"
          };
        }

        clickLikeUser(confirm);

        // 5. Success = repay modal closes OR a visible success message appears.
        const submitResult = await waitFor(() => {
          const amountStillVisible = Array.from(
            document.querySelectorAll('input[placeholder="请输入人民币金额"]')
          ).some(visible);

          const successText = Array.from(document.querySelectorAll(
            '.ant-message, .ant-message-notice, .ant-notification, .ant-notification-notice, [role="alert"]'
          )).filter(visible).map(el => norm(el.innerText || el.textContent)).join("|");

          if (/成功|操作成功|处理成功|處理成功/.test(successText)) {
            return { type:"success_message", text:successText };
          }

          if (!amountStillVisible) {
            return { type:"modal_closed" };
          }

          return null;
        }, 30000);

        if (!submitResult) {
          const modalText = norm((modal.innerText || modal.textContent || "")).slice(0, 500);
          return {
            ok:false,
            error:"6.操作MS錯誤：點擊確定後補回彈窗仍未關閉" + (modalText ? `（${modalText}）` : "")
          };
        }

        return {
          ok:true,
          orderNo,
          amount:amountText,
          merchantFee:feeText,
          remark:remarkText,
          successType:submitResult.type
        };
      }
    });
  } catch (e) {
    return { ok:false, error:"6.操作MS錯誤：" + String(e.message || e) };
  }

  const result = results && results[0] ? results[0].result : null;
  if (!result) {
    return { ok:false, error:"6.操作MS錯誤：MS頁面沒有回傳操作結果" };
  }

  return result;
}


async function cowFindCurrentSfpTab() {
  const cowWindowId = await cowGetDedicatedWindowId();
  if (!Number.isInteger(cowWindowId)) return null;

  // 只在 COW 獨立視窗 B 內找四方；絕不掃描 / 操作使用者原本視窗 A。
  const tabs = await chrome.tabs.query({ windowId: cowWindowId });
  const cowNamed = tabs.find(t => /^COW\s*[|｜]\s*四方/.test(String(t.title || "")));
  if (cowNamed) return cowNamed;

  const sameSite = tabs.find(tab => {
    try { return new URL(String(tab.url || "")).hostname === "sfp.csussr.com"; }
    catch (_) { return false; }
  });
  return sameSite || null;
}

async function cowPrepareSfpRepay(lastQuery) {
  if (!lastQuery || !lastQuery.ok || !lastQuery.preview || !lastQuery.sfp) {
    return { ok:false, error:"7.操作四方錯誤：請先完成查詢" };
  }

  const p = lastQuery.preview || {};
  const sfp = lastQuery.sfp || {};
  const parsed = lastQuery.parsed || {};

  const inputOrderNo = String(parsed.orderNo || "").trim();
  const internalOrderNo = String(sfp.internalOrderNo || "").trim();
  const orderAmount = p.sfpOrderAmount;
  const merchantFee = p.isSplit ? 0 : (sfp.merchantFee ?? 0);
  const channelFee = p.isSplit ? 0 : (sfp.channelFee ?? 0);
  const datePrefix = String(p.effectiveDateText || parsed.dateText || "").trim();

  let tab = await cowFindCurrentSfpTab();
  if (!tab || !tab.id) {
    return { ok:false, error:"7.操作四方錯誤：找不到已查詢的四方頁面" };
  }

  // 防呆：操作前重新定位到四方「提現記錄」，並用原商戶單號再查一次。
  // 即使使用者查詢完成後又手動查了其他單號，也只會重新抓回本次鎖定的原單。
  try {
    tab = await cowEnsureWorkPage(tab.id, COW_SFP_WORK_URL, "四方");
  } catch (e) {
    return { ok:false, error:"7.操作四方錯誤：自動定位提現記錄失敗：" + String(e.message || e) };
  }

  const sfpRecheck = await cowQuerySfp(
    tab.id,
    inputOrderNo,
    null,
    parsed.dateText || null
  );
  if (!sfpRecheck?.ok) {
    return { ok:false, error:"7.操作四方錯誤：操作前重新查詢原單失敗：" + (sfpRecheck?.error || "查無資料") };
  }
  const sfpSnapshotCheck = cowValidateSfpSnapshot(lastQuery.sfp, sfpRecheck);
  if (!sfpSnapshotCheck.ok) {
    return { ok:false, error:"7.操作四方錯誤：安全檢查停止操作；" + sfpSnapshotCheck.error };
  }

  await cowMuteTab(tab.id);
  await cowSetCowTitle(tab.id, "四方");
  await cowBringTabToFront(tab.id);

  let results;
  try {
    results = await chrome.scripting.executeScript({
      target: { tabId: tab.id },
      args: [inputOrderNo, internalOrderNo, String(orderAmount), String(merchantFee), String(channelFee), datePrefix],
      func: async (inputOrderNo, internalOrderNo, orderAmount, merchantFee, channelFee, datePrefix) => {
        const norm = v => String(v == null ? "" : v).replace(/\s+/g, "").trim();
        const visible = el => {
          if (!el) return false;
          const r = el.getBoundingClientRect();
          const s = getComputedStyle(el);
          return r.width > 0 && r.height > 0 && s.display !== "none" &&
                 s.visibility !== "hidden" && Number(s.opacity || "1") !== 0;
        };
        const waitFor = (predicate, timeoutMs = 30000) => new Promise(resolve => {
          let done = false, observer = null, timer = null;
          const finish = v => {
            if (done) return;
            done = true;
            if (observer) observer.disconnect();
            if (timer) clearTimeout(timer);
            resolve(v);
          };
          const check = () => {
            try {
              const v = predicate();
              if (v) finish(v);
            } catch (_) {}
          };
          observer = new MutationObserver(check);
          observer.observe(document.documentElement || document.body, {
            childList:true, subtree:true, attributes:true,
            attributeFilter:["class","style","disabled","value"]
          });
          timer = setTimeout(() => finish(null), timeoutMs);
          check();
        });
        const clickLikeUser = el => {
          if (!el) return false;
          el.scrollIntoView({block:"center", inline:"center"});
          for (const type of ["mouseover","mousedown","mouseup","click"]) {
            el.dispatchEvent(new MouseEvent(type, {bubbles:true,cancelable:true,view:window}));
          }
          return true;
        };
        const setNativeValue = (el, value) => {
          if (!el) return false;
          el.focus();
          const proto = el instanceof HTMLTextAreaElement ? HTMLTextAreaElement.prototype : HTMLInputElement.prototype;
          const setter = Object.getOwnPropertyDescriptor(proto, "value")?.set;
          if (!setter) return false;
          setter.call(el, "");
          el.dispatchEvent(new Event("input",{bubbles:true}));
          el.dispatchEvent(new Event("change",{bubbles:true}));
          setter.call(el, String(value));
          el.dispatchEvent(new Event("input",{bubbles:true}));
          el.dispatchEvent(new Event("change",{bubbles:true}));
          el.blur();
          return true;
        };
        const numericEqual = (a,b) => {
          const na=Number(String(a).replace(/,/g,"")), nb=Number(String(b).replace(/,/g,""));
          return Number.isFinite(na)&&Number.isFinite(nb) ? Math.abs(na-nb)<1e-9 : String(a)===String(b);
        };

        // Find queried row and its 加扣款 action.
        const rows = Array.from(document.querySelectorAll("tr")).filter(visible);
        const keys = [inputOrderNo, internalOrderNo].filter(Boolean).map(norm);
        let row = rows.find(tr => {
          const t = norm(tr.innerText || tr.textContent);
          return keys.some(k => k && t.includes(k));
        }) || null;

        const exactText = el => norm(el.innerText || el.textContent) === "加扣款";

        // Detect the real editable form. This is used both before and after clicking.
        const findAddDeductForm = () => {
          const containers = [
            ...document.querySelectorAll(
              '.ant-modal, .ant-modal-content, .ant-modal-wrap, [role="dialog"], .ant-modal-root'
            )
          ].filter(visible);

          for (const el of containers) {
            const t = norm(el.innerText || el.textContent);
            if (t.includes("财务谷歌验证码") || t.includes("財務谷歌驗證碼")) continue;

            const editables = Array.from(el.querySelectorAll("input,textarea"))
              .filter(x => visible(x) && !x.disabled && !x.readOnly &&
                !["hidden","button","submit","checkbox","radio"].includes((x.type || "").toLowerCase()));

            if (
              (t.includes("加扣款") || t.includes("订单金额") || t.includes("訂單金額")) &&
              editables.length >= 3
            ) return el;
          }

          const remark = Array.from(document.querySelectorAll("textarea,input"))
            .find(el => {
              if (!visible(el) || el.disabled || el.readOnly) return false;
              return /销提现单|銷提現單|提现单|提現單/.test(String(el.value || ""));
            });

          if (remark) {
            let el = remark;
            for (let i = 0; i < 10 && el; i++, el = el.parentElement) {
              const t = norm(el.innerText || el.textContent);
              const editables = Array.from(el.querySelectorAll?.("input,textarea") || [])
                .filter(x => visible(x) && !x.disabled && !x.readOnly &&
                  !["hidden","button","submit","checkbox","radio"].includes((x.type || "").toLowerCase()));
              if (editables.length >= 3 && (
                t.includes("订单金额") || t.includes("訂單金額") || t.includes("商户手续费") ||
                t.includes("商戶手续费") || t.includes("加扣款")
              )) return el;
            }
          }

          return null;
        };

        // If the dialog is already open from a previous attempt, use it directly.
        let modal = findAddDeductForm();

        if (!modal) {
          let actionCandidates = [];

          if (row) {
            actionCandidates = Array.from(row.querySelectorAll("button,a,[role='button'],span,div"))
              .filter(el => visible(el) && exactText(el));
          }

          if (!actionCandidates.length) {
            actionCandidates = Array.from(document.querySelectorAll("button,a,[role='button'],span,div"))
              .filter(el => visible(el) && exactText(el));
          }

          // Prefer the actual orange button element shown on the page, then anchors/role buttons,
          // and only after that fall back to a span/div wrapper.
          const score = el => {
            const tag = el.tagName;
            let s = 100;
            if (tag === "BUTTON") s = 0;
            else if (tag === "A") s = 10;
            else if (el.getAttribute("role") === "button") s = 20;
            else if (tag === "SPAN") s = 30;
            else if (tag === "DIV") s = 40;
            const r = el.getBoundingClientRect();
            return s + Math.min(50, (r.width * r.height) / 1000);
          };

          actionCandidates.sort((a,b) => score(a) - score(b));

          // Also include clickable ancestors of the exact-text node, but deduplicate.
          const expanded = [];
          const seen = new Set();
          for (const el of actionCandidates) {
            for (const candidate of [
              el,
              el.closest("button"),
              el.closest("a"),
              el.closest("[role='button']")
            ]) {
              if (candidate && visible(candidate) && !seen.has(candidate)) {
                seen.add(candidate);
                expanded.push(candidate);
              }
            }
          }

          if (!expanded.length) {
            return {ok:false,error:"7.操作四方錯誤：目前查詢結果找不到「加扣款」按鈕"};
          }

          const waitFormAfterClick = () => new Promise(resolve => {
            let done = false, observer = null, timer = null;
            const finish = v => {
              if (done) return;
              done = true;
              if (observer) observer.disconnect();
              if (timer) clearTimeout(timer);
              resolve(v);
            };
            const check = () => {
              const form = findAddDeductForm();
              if (form) finish(form);
            };
            observer = new MutationObserver(check);
            observer.observe(document.documentElement || document.body, {
              childList:true, subtree:true, attributes:true,
              attributeFilter:["class","style"]
            });
            timer = setTimeout(() => finish(null), 5000);
            check();
          });

          let lastActionInfo = null;

          // Try candidates one at a time. Never double-click the same target.
          for (const candidate of expanded) {
            const r = candidate.getBoundingClientRect();
            lastActionInfo = {
              tag:candidate.tagName,
              cls:String(candidate.className || ""),
              text:norm(candidate.innerText || candidate.textContent),
              x:Math.round(r.x), y:Math.round(r.y),
              w:Math.round(r.width), h:Math.round(r.height)
            };

            candidate.scrollIntoView({block:"center", inline:"center"});
            candidate.focus?.();

            // Real center-point target is useful when the visible text is nested.
            const rr = candidate.getBoundingClientRect();
            const cx = rr.left + rr.width / 2;
            const cy = rr.top + rr.height / 2;
            const pointEl = document.elementFromPoint(cx, cy);
            const target = pointEl && candidate.contains(pointEl) ? pointEl : candidate;

            try {
              target.dispatchEvent(new PointerEvent("pointerdown", {
                bubbles:true,cancelable:true,pointerType:"mouse",isPrimary:true,clientX:cx,clientY:cy
              }));
              target.dispatchEvent(new MouseEvent("mousedown", {
                bubbles:true,cancelable:true,view:window,clientX:cx,clientY:cy
              }));
              target.dispatchEvent(new PointerEvent("pointerup", {
                bubbles:true,cancelable:true,pointerType:"mouse",isPrimary:true,clientX:cx,clientY:cy
              }));
              target.dispatchEvent(new MouseEvent("mouseup", {
                bubbles:true,cancelable:true,view:window,clientX:cx,clientY:cy
              }));
              target.dispatchEvent(new MouseEvent("click", {
                bubbles:true,cancelable:true,view:window,clientX:cx,clientY:cy
              }));
            } catch (_) {
              try { candidate.click(); } catch (_) {}
            }

            modal = await waitFormAfterClick();
            if (modal) break;
          }

          if (!modal) {
            const visibleText = norm(document.body?.innerText || "").slice(-1200);
            return {
              ok:false,
              error:"7.操作四方錯誤：已找到並點擊「加扣款」，但頁面沒有開啟加扣款欄位" +
                (lastActionInfo ? `（按鈕:${lastActionInfo.tag}.${lastActionInfo.cls} ${lastActionInfo.w}x${lastActionInfo.h}）` : "") +
                (visibleText ? `（頁面末段：${visibleText.slice(-260)}）` : "")
            };
          }
        }

        // Map fields by header cell order shown on the actual page.
        const trs = Array.from(modal.querySelectorAll("tr"));
        let editRow = trs.find(tr => {
          const inputs = Array.from(tr.querySelectorAll("input,textarea")).filter(el => !el.disabled && !el.readOnly && visible(el));
          return inputs.length >= 3;
        }) || null;

        let amountInput=null, merchantFeeInput=null, channelFeeInput=null, remarkInput=null;

        if (editRow) {
          const cells = Array.from(editRow.querySelectorAll("td"));
          if (cells.length >= 8) {
            amountInput = Array.from(cells[2].querySelectorAll("input")).find(visible) || null;
            merchantFeeInput = Array.from(cells[3].querySelectorAll("input")).find(visible) || null;
            channelFeeInput = Array.from(cells[6].querySelectorAll("input")).find(visible) || null;
            remarkInput = Array.from(cells[7].querySelectorAll("textarea,input")).find(visible) || null;
          }
        }

        // Fallback based on editable field visual order.
        if (!amountInput || !merchantFeeInput || !channelFeeInput || !remarkInput) {
          const editables = Array.from(modal.querySelectorAll("input,textarea"))
            .filter(el => visible(el) && !el.disabled && !el.readOnly &&
                          !["hidden","button","submit","checkbox","radio"].includes((el.type||"").toLowerCase()));
          const textareas = editables.filter(el => el.tagName === "TEXTAREA");
          const inputs = editables.filter(el => el.tagName === "INPUT");
          amountInput = amountInput || inputs[0] || null;
          merchantFeeInput = merchantFeeInput || inputs[1] || null;
          channelFeeInput = channelFeeInput || inputs[2] || null;
          remarkInput = remarkInput || textareas[0] || inputs[3] || null;
        }

        if (!amountInput || !merchantFeeInput || !channelFeeInput || !remarkInput) {
          return {ok:false,error:"7.操作四方錯誤：找不到訂單金額 / 商戶手续费 / 通道手续费 / 備註欄位"};
        }

        setNativeValue(amountInput, orderAmount);
        setNativeValue(merchantFeeInput, merchantFee);
        setNativeValue(channelFeeInput, channelFee);

        let finalRemark = String(remarkInput.value || "");
        if (datePrefix) {
          const cleanDate = datePrefix.replace(/\s+$/,"");
          if (!finalRemark.startsWith(cleanDate)) finalRemark = cleanDate + finalRemark;
          setNativeValue(remarkInput, finalRemark);
        }

        if (!numericEqual(amountInput.value, orderAmount))
          return {ok:false,error:`7.操作四方錯誤：訂單金額填寫失敗（預期 ${orderAmount}，目前 ${amountInput.value}）`};
        if (!numericEqual(merchantFeeInput.value, merchantFee))
          return {ok:false,error:`7.操作四方錯誤：商戶手续费填寫失敗（預期 ${merchantFee}，目前 ${merchantFeeInput.value}）`};
        if (!numericEqual(channelFeeInput.value, channelFee))
          return {ok:false,error:`7.操作四方錯誤：通道手续费填寫失敗（預期 ${channelFee}，目前 ${channelFeeInput.value}）`};

        const confirm = Array.from(modal.querySelectorAll("button,a"))
          .find(el => visible(el) && ["确定","確定"].includes(norm(el.innerText || el.textContent))) || null;
        if (!confirm) return {ok:false,error:"7.操作四方錯誤：找不到加扣款彈窗的「確定」按鈕"};

        clickLikeUser(confirm);

        // Wait until financial Google verification modal is visible.
        const verify = await waitFor(() => {
          const candidates = Array.from(document.querySelectorAll('.ant-modal, [role="dialog"]')).filter(visible);
          return candidates.find(el => {
            const t = norm(el.innerText || el.textContent);
            return t.includes("财务谷歌验证码") || t.includes("財務谷歌驗證碼");
          }) || null;
        }, 30000);

        if (!verify) return {ok:false,error:"7.操作四方錯誤：已點擊確定，但沒有出現財務谷歌驗證碼視窗"};

        return {
          ok:true,
          status:"waiting_verification",
          orderAmount,
          merchantFee,
          channelFee,
          remark:finalRemark
        };
      }
    });
  } catch (e) {
    return {ok:false,error:"7.操作四方錯誤：" + String(e.message || e)};
  }

  const result = results && results[0] ? results[0].result : null;
  return result || {ok:false,error:"7.操作四方錯誤：四方頁面沒有回傳操作結果"};
}

async function cowSubmitSfpVerification(code) {
  code = String(code || "").trim();
  if (!code) return {ok:false,error:"四方驗證碼不可空白"};

  const tab = await cowFindCurrentSfpTab();
  if (!tab || !tab.id) return {ok:false,error:"四方驗證碼錯誤：找不到四方頁面"};

  await cowMuteTab(tab.id);
  await cowSetCowTitle(tab.id, "四方");
  await cowBringTabToFront(tab.id);

  let results;
  try {
    results = await chrome.scripting.executeScript({
      target:{tabId:tab.id},
      args:[code],
      func: async code => {
        const norm=v=>String(v==null?"":v).replace(/\s+/g,"").trim();
        const visible=el=>{
          if(!el)return false;
          const r=el.getBoundingClientRect(),s=getComputedStyle(el);
          return r.width>0&&r.height>0&&s.display!=="none"&&s.visibility!=="hidden";
        };
        const waitFor=(predicate,timeoutMs=30000)=>new Promise(resolve=>{
          let done=false,observer=null,timer=null;
          const finish=v=>{if(done)return;done=true;if(observer)observer.disconnect();if(timer)clearTimeout(timer);resolve(v);};
          const check=()=>{try{const v=predicate();if(v)finish(v);}catch(_){}};
          observer=new MutationObserver(check);
          observer.observe(document.documentElement||document.body,{childList:true,subtree:true,attributes:true,attributeFilter:["class","style","disabled","value"]});
          timer=setTimeout(()=>finish(null),timeoutMs);
          check();
        });
        const setNativeValue=(el,value)=>{
          el.focus();
          const proto=HTMLInputElement.prototype;
          const setter=Object.getOwnPropertyDescriptor(proto,"value")?.set;
          if(!setter)return false;
          setter.call(el,"");
          el.dispatchEvent(new Event("input",{bubbles:true}));
          setter.call(el,String(value));
          el.dispatchEvent(new Event("input",{bubbles:true}));
          el.dispatchEvent(new Event("change",{bubbles:true}));
          return true;
        };
        const clickLikeUser=el=>{
          el.scrollIntoView({block:"center",inline:"center"});
          for(const type of ["mouseover","mousedown","mouseup","click"]){
            el.dispatchEvent(new MouseEvent(type,{bubbles:true,cancelable:true,view:window}));
          }
        };

        const getVerifyModal=()=>Array.from(document.querySelectorAll('.ant-modal,[role="dialog"]'))
          .filter(visible)
          .find(el=>{
            const t=norm(el.innerText||el.textContent);
            return t.includes("财务谷歌验证码")||t.includes("財務谷歌驗證碼");
          })||null;

        const modal=getVerifyModal();
        if(!modal)return {ok:false,error:"四方驗證碼錯誤：目前沒有財務谷歌驗證碼視窗"};

        const input=Array.from(modal.querySelectorAll("input"))
          .find(el=>visible(el)&&!el.disabled&&!el.readOnly&&
            (/财务谷歌验证码|財務谷歌驗證碼/.test(el.placeholder||"") || (el.type||"").toLowerCase()==="text")) || null;
        if(!input)return {ok:false,error:"四方驗證碼錯誤：找不到財務谷歌驗證碼輸入欄"};

        setNativeValue(input,code);

        const confirm=Array.from(modal.querySelectorAll("button,a"))
          .find(el=>visible(el)&&["确定","確定"].includes(norm(el.innerText||el.textContent)))||null;
        if(!confirm)return {ok:false,error:"四方驗證碼錯誤：找不到驗證碼「確定」按鈕"};

        clickLikeUser(confirm);

        const result=await waitFor(()=>{
          const current=getVerifyModal();
          const messages=Array.from(document.querySelectorAll(
            '.ant-message,.ant-message-notice,.ant-notification,.ant-notification-notice,[role="alert"],.ant-form-explain,.ant-form-item-explain'
          )).filter(visible).map(el=>norm(el.innerText||el.textContent)).filter(Boolean);
          const msg=messages.join("|");

          if(/验证码|驗證碼|谷歌/.test(msg) && /错误|錯誤|不正确|不正確|失败|失敗|已使用|过期|過期/.test(msg))
            return {status:"error",message:msg};
          if(/成功|操作成功|处理成功|處理成功/.test(msg))
            return {status:"success",message:msg};
          if(!current) return {status:"success",message:"verification_modal_closed"};
          return null;
        },30000);

        if(!result)return {ok:false,error:"四方驗證碼錯誤：送出後仍停留在驗證碼視窗"};
        if(result.status==="error")return {ok:false,error:"四方驗證碼錯誤：" + result.message};
        return {ok:true,status:"success",message:result.message};
      }
    });
  } catch(e) {
    return {ok:false,error:"四方驗證碼錯誤：" + String(e.message||e)};
  }

  const result=results&&results[0]?results[0].result:null;
  return result||{ok:false,error:"四方驗證碼錯誤：四方頁面沒有回傳驗證結果"};
}


const COW_REPAY_PLATFORM_URLS = {
  "XY": "https://be.ms1666888.com/ManualDeposit",
  "OL": "https://be.ms1666888.com/ManualDeposit",
  "LS": "https://be.ms1666888.com/ManualDeposit",
  "XH": "https://be.ms1666888.com/ManualDeposit",
  "TD": "https://gz76qha4.tdyule222.com",
  "RF": "https://ktphr2j6.rfyule555.com/",
  "HS": "https://txwhsiqk.hsly04.com/",
  "YD": "https://ymsvcncb.ydyule666.com",
  "ND": "https://xgjemo.hdmx57.com/",
  "YS": "https://bu69t1grl1.ysyla16888.com/",
  "SH": "https://m6hcy34zd9.sh0031.com/",
  "JY": "https://dfdkgv.jyna67.com/",
  "JD": "https://b22465e41r.jdvip1688.com/",
  "MT": "https://kka0pl5f2t.mtyl1388.com/",
  "FB": "http://fbyl369.com/"
};

async function cowOpenRepayPlatform(lastQuery) {
  const platform = String(lastQuery?.parsed?.platform || "").toUpperCase().trim();
  if (!platform || !COW_REPAY_PLATFORM_URLS[platform]) {
    return {ok:false,error:"8.操作平台錯誤：找不到平台代號或網址"};
  }

  const isWG = COW_SPECIAL_WG_PLATFORMS.has(platform);
  const url = COW_REPAY_PLATFORM_URLS[platform];
  const titleName = isWG ? "WG" : platform;
  const urlParts = isWG
    ? ["be.ms1666888.com/ManualDeposit"]
    : [new URL(url).hostname];

  let tab;
  try {
    tab = await cowEnsureTab(urlParts, url, titleName);
  } catch (e) {
    return {ok:false,error:"8.操作平台錯誤：開啟平台失敗：" + String(e.message || e)};
  }

  if (!tab || !tab.id) {
    return {ok:false,error:"8.操作平台錯誤：無法取得平台分頁"};
  }

  await cowMuteTab(tab.id);
  await cowSetCowTitle(tab.id, titleName);
  await cowBringTabToFront(tab.id);
  await cowMuteTab(tab.id);

  return {
    ok:true,
    platform,
    pageName:titleName,
    tabId:tab.id,
    url:String(tab.url || url),
    testingSkipSfpVerification:true
  };
}


async function cowExecAllFrames(tabId, func, args = []) {
  return await chrome.scripting.executeScript({
    target: { tabId, allFrames:true },
    func,
    args
  });
}

function cowPickOkFrame(results) {
  for (const item of results || []) {
    if (item?.result?.ok) return item.result;
  }
  return null;
}


const COW_MANUAL_DEPOSIT_URL = "https://be.ms1666888.com/ManualDeposit";
const COW_MANUAL_DEPOSIT_PLATFORM_LABELS = {
  XY: ["星亿(XY)", "星億(XY)", "XY"],
  OL: ["欧陆（OL）", "歐陸（OL）", "欧陆(OL)", "歐陸(OL)", "OL"],
  LS: ["蓝狮（LS）", "藍獅（LS）", "蓝狮(LS)", "藍獅(LS)", "LS"],
  XH: ["星輝（XH）", "星辉（XH）", "星輝(XH)", "星辉(XH)", "XH"]
};

async function cowManualDepositResetTab(tabId, titleName) {
  await cowMuteTab(tabId);
  await chrome.tabs.update(tabId, {url:COW_MANUAL_DEPOSIT_URL, active:true});
  await cowWaitTabComplete(tabId, 30000);
  await cowMuteTab(tabId);
  await cowSetCowTitle(tabId, titleName || "WG");
  await cowBringTabToFront(tabId);
  return await chrome.tabs.get(tabId);
}

async function cowManualDepositClickText(tabId, wantedTexts, timeoutMs=12000) {
  const started = Date.now();
  while (Date.now() - started < timeoutMs) {
    try {
      const results = await cowExecAllFrames(tabId, (wantedTexts) => {
        const visible = el => {
          if (!el) return false;
          const r=el.getBoundingClientRect(), s=getComputedStyle(el);
          return r.width>0 && r.height>0 && s.display!=="none" && s.visibility!=="hidden";
        };
        const norm = v => String(v||"").replace(/\s+/g,"").trim();
        const wanted = (wantedTexts||[]).map(norm);
        const nodes=[...document.querySelectorAll(
          "button,a,input[type='button'],input[type='submit'],[role='button'],span,div"
        )].filter(visible).map((el,i)=>{
          const r=el.getBoundingClientRect();
          const raw=el.innerText||el.textContent||el.value||"";
          const text=norm(raw).replace(/^[+＋]/,"");
          return {el,i,raw,text,tag:el.tagName,area:r.width*r.height,r:{x:r.x,y:r.y,w:r.width,h:r.height}};
        }).filter(x=>x.r.w>15 && x.r.h>10 && x.r.w<500 && x.r.h<110);

        for (const w of wanted) {
          const exact=nodes.filter(x=>x.text===w)
            .sort((a,b)=>{
              const ap=/^(BUTTON|A|INPUT)$/.test(a.tag)?0:1;
              const bp=/^(BUTTON|A|INPUT)$/.test(b.tag)?0:1;
              return ap-bp || a.area-b.area || a.r.y-b.r.y;
            });
          if (exact.length) {
            const x=exact[0];
            x.el.scrollIntoView({block:"center",inline:"center"});
            x.el.click();
            return {ok:true,text:String(x.raw||""),tag:x.tag,rect:x.r};
          }
        }
        return {ok:false,visible:nodes.slice(0,80).map(x=>({text:String(x.raw||""),tag:x.tag,rect:x.r}))};
      }, [wantedTexts]);
      const ok = cowPickOkFrame(results);
      if (ok) return ok;
    } catch (_) {}
    await cowSleep(180);
  }
  return {ok:false,error:"ManualDeposit 找不到按鈕：" + (wantedTexts||[]).join(" / ")};
}

async function cowManualDepositWaitCreateReady(tabId, timeoutMs=15000) {
  const started=Date.now();
  while(Date.now()-started<timeoutMs){
    try{
      const results=await cowExecAllFrames(tabId,()=>{
        const visible=el=>{
          if(!el)return false;
          const r=el.getBoundingClientRect(),s=getComputedStyle(el);
          return r.width>0&&r.height>0&&s.display!=="none"&&s.visibility!=="hidden";
        };
        const text=String(document.body?.innerText||"");
        const selects=[...document.querySelectorAll("select")].filter(visible);
        const hasPlatformSelect=selects.some(sel=>[...sel.options].some(o=>/(XY|OL|LS|XH)/i.test(String(o.textContent||""))));
        return {ok:hasPlatformSelect || /新增批次人工存入|商戶號|商户号/.test(text),url:location.href,hasPlatformSelect};
      });
      const ok=cowPickOkFrame(results);
      if(ok)return ok;
    }catch(_){}
    await cowSleep(180);
  }
  return {ok:false,error:"ManualDeposit 批次新增頁面沒有準備完成"};
}

async function cowManualDepositSelectPlatform(tabId, platform, timeoutMs=12000) {
  const labels=COW_MANUAL_DEPOSIT_PLATFORM_LABELS[platform] || [platform];
  const started=Date.now();
  while(Date.now()-started<timeoutMs){
    try{
      const results=await cowExecAllFrames(tabId,(platform,labels)=>{
        const visible=el=>{
          if(!el)return false;
          const r=el.getBoundingClientRect(),s=getComputedStyle(el);
          return r.width>0&&r.height>0&&s.display!=="none"&&s.visibility!=="hidden";
        };
        const norm=v=>String(v||"").replace(/\s+/g,"").replace(/[（）]/g,m=>m==="（"?"(":")").trim().toUpperCase();
        const wanted=(labels||[]).map(norm);
        const code=String(platform||"").toUpperCase();
        const selects=[...document.querySelectorAll("select")].filter(visible);
        for(const sel of selects){
          const opts=[...sel.options];
          const opt=opts.find(o=>{
            const t=norm(o.textContent||"");
            return wanted.some(w=>t===w || (w.length>2 && t.includes(w))) || new RegExp("\\("+code+"\\)","i").test(t);
          });
          if(!opt)continue;
          sel.scrollIntoView({block:"center",inline:"center"});
          const setter=Object.getOwnPropertyDescriptor(HTMLSelectElement.prototype,"value")?.set;
          if(setter)setter.call(sel,opt.value); else sel.value=opt.value;
          sel.dispatchEvent(new Event("input",{bubbles:true}));
          sel.dispatchEvent(new Event("change",{bubbles:true}));
          return {ok:true,mode:"native",selected:String(opt.textContent||""),value:String(opt.value||"")};
        }
        return {ok:false,selects:selects.map((s,i)=>({i,options:[...s.options].map(o=>String(o.textContent||"")).slice(0,20)}))};
      },[platform,labels]);
      const ok=cowPickOkFrame(results);
      if(ok){
        await cowSleep(500);
        return ok;
      }
    }catch(_){}
    await cowSleep(180);
  }
  return {ok:false,error:`ManualDeposit 商戶號選擇失敗：${platform}`};
}

async function cowManualDepositAddRow(tabId) {
  return await cowManualDepositClickText(tabId,["新增"],10000);
}

async function cowManualDepositFillOneRow(tabId, itemText, member, amount, remark, timeoutMs=15000) {
  const started=Date.now();
  while(Date.now()-started<timeoutMs){
    try{
      const results=await cowExecAllFrames(tabId,(itemText,member,amount,remark)=>{
        const visible=el=>{
          if(!el)return false;
          const r=el.getBoundingClientRect(),s=getComputedStyle(el);
          return r.width>0&&r.height>0&&s.display!=="none"&&s.visibility!=="hidden";
        };
        const norm=v=>String(v||"").replace(/\s+/g,"").trim();
        const setValue=(el,value)=>{
          if(!el)return false;
          el.scrollIntoView({block:"center",inline:"center"});
          el.focus();
          const proto=el instanceof HTMLTextAreaElement?HTMLTextAreaElement.prototype:HTMLInputElement.prototype;
          const setter=Object.getOwnPropertyDescriptor(proto,"value")?.set;
          if(setter)setter.call(el,String(value??"")); else el.value=String(value??"");
          el.dispatchEvent(new Event("input",{bubbles:true}));
          el.dispatchEvent(new Event("change",{bubbles:true}));
          el.dispatchEvent(new Event("blur",{bubbles:true}));
          return true;
        };

        // 存入項目：以包含目標選項的 select 為準，避免誤動上方商戶號。
        const itemSelect=[...document.querySelectorAll("select")].filter(visible).find(sel=>
          [...sel.options].some(o=>norm(o.textContent).includes(norm(itemText)))
        ) || null;
        if(!itemSelect)return {ok:false,stage:"item_select_not_found"};
        const itemOpt=[...itemSelect.options].find(o=>norm(o.textContent).includes(norm(itemText)));
        if(!itemOpt)return {ok:false,stage:"item_option_not_found"};
        const selectSetter=Object.getOwnPropertyDescriptor(HTMLSelectElement.prototype,"value")?.set;
        if(selectSetter)selectSetter.call(itemSelect,itemOpt.value); else itemSelect.value=itemOpt.value;
        itemSelect.dispatchEvent(new Event("input",{bubbles:true}));
        itemSelect.dispatchEvent(new Event("change",{bubbles:true}));

        const candidateRows=[...document.querySelectorAll("tr,.el-table__row,.ant-table-row,.row,[class*='row'],[class*='form']")]
          .filter(visible).map((row,i)=>{
            const inputs=[...row.querySelectorAll("input,textarea")].filter(el=>{
              if(!visible(el))return false;
              const ph=norm(el.getAttribute("placeholder")||"");
              const nm=norm(el.getAttribute("name")||"").toLowerCase();
              const tp=String(el.getAttribute("type")||"").toLowerCase();
              if(tp==="password"||tp==="hidden")return false;
              if(/谷歌|动态密码|動態密碼|验证码|驗證碼/.test(ph))return false;
              if(/google|auth|password/.test(nm))return false;
              if(/startcreatetime|endcreatetime|minamount|maxamount/.test(nm))return false;
              return true;
            });
            const hasItem=row.contains(itemSelect);
            return {row,i,inputs,text:String(row.innerText||row.textContent||""),hasItem};
          }).filter(x=>x.inputs.length>=2 && !/查询|查詢/.test(x.text));

        let target=candidateRows.find(x=>x.hasItem) || candidateRows[candidateRows.length-1] || null;
        let inputs=target?.inputs || [];
        if(inputs.length<2){
          inputs=[...document.querySelectorAll("input,textarea")].filter(el=>{
            if(!visible(el))return false;
            const ph=norm(el.getAttribute("placeholder")||"");
            const nm=norm(el.getAttribute("name")||"").toLowerCase();
            const tp=String(el.getAttribute("type")||"").toLowerCase();
            if(["password","hidden","button","submit"].includes(tp))return false;
            if(/谷歌|动态密码|動態密碼|验证码|驗證碼/.test(ph))return false;
            if(/google|auth|password|startcreatetime|endcreatetime|minamount|maxamount/.test(nm))return false;
            return true;
          });
        }

        const accountInput=inputs.find(el=>{
          const t=norm([el.placeholder,el.name,el.id].join(" "));
          return /账号|帳號|account/i.test(t);
        }) || inputs[0] || null;
        const amountInput=inputs.find(el=>{
          if(el===accountInput)return false;
          const t=norm([el.placeholder,el.name,el.id].join(" "));
          return /存入金额|存入金額|金额|金額|amount/i.test(t);
        }) || inputs.find(el=>el!==accountInput) || null;
        const remarkInput=inputs.find(el=>{
          const t=norm([el.placeholder,el.name,el.id].join(" "));
          return /备注|備註|remark|memo/i.test(t);
        }) || inputs[inputs.length-1] || null;

        if(!accountInput||!amountInput||!remarkInput){
          return {ok:false,stage:"row_inputs_not_found",inputCount:inputs.length};
        }

        setValue(accountInput,member);
        setValue(amountInput,amount);
        setValue(remarkInput,remark);

        const accountOk=String(accountInput.value||"")===String(member);
        const amountOk=String(amountInput.value||"")===String(amount);
        const remarkOk=String(remarkInput.value||"")===String(remark);
        return {
          ok:accountOk&&amountOk&&remarkOk,
          item:String(itemOpt.textContent||""),
          account:String(accountInput.value||""),
          amount:String(amountInput.value||""),
          remark:String(remarkInput.value||""),
          accountOk,amountOk,remarkOk,
          inputCount:inputs.length
        };
      },[String(itemText),String(member),String(amount),String(remark||"")]);
      const ok=cowPickOkFrame(results);
      if(ok)return ok;
    }catch(_){}
    await cowSleep(220);
  }
  return {ok:false,error:`ManualDeposit ${itemText} 欄位填寫失敗`};
}

async function cowManualDepositSubmitAndWaitGoogle(tabId, timeoutMs=18000) {
  const submit=await cowManualDepositClickText(tabId,["送出","提交"],10000);
  if(!submit?.ok)return {ok:false,error:"ManualDeposit 找不到送出按鈕",submit};

  const started=Date.now();
  while(Date.now()-started<timeoutMs){
    try{
      const results=await cowExecAllFrames(tabId,()=>{
        const visible=el=>{
          if(!el)return false;
          const r=el.getBoundingClientRect(),s=getComputedStyle(el);
          return r.width>0&&r.height>0&&s.display!=="none"&&s.visibility!=="hidden";
        };
        const norm=v=>String(v||"").replace(/\s+/g,"").trim().toLowerCase();
        const inputs=[...document.querySelectorAll("input")].filter(visible);
        const google=inputs.find(el=>{
          const ph=norm(el.placeholder||""),nm=norm(el.name||""),id=norm(el.id||""),cls=norm(el.className||"");
          const tp=String(el.type||"").toLowerCase();
          return /谷歌|动态密码|動態密碼|验证码|驗證碼/.test(ph) || /google|auth|password/.test(nm+" "+id+" "+cls) || tp==="password";
        }) || null;
        if(!google)return {ok:false};
        google.scrollIntoView({block:"center",inline:"center"});
        google.focus();
        return {ok:true,id:google.id||"",name:google.name||"",placeholder:google.placeholder||"",type:google.type||""};
      });
      const ok=cowPickOkFrame(results);
      if(ok)return {ok:true,submit,google:ok,waitingVerification:true};
    }catch(_){}
    await cowSleep(220);
  }
  return {ok:false,error:"ManualDeposit 已按送出，但沒有出現谷歌動態密碼",submit};
}

async function cowPrepareOneManualDepositTab(tab, platform, member, item, amount, remark, titleName) {
  if(!tab?.id)return {ok:false,error:"ManualDeposit 找不到分頁"};

  await cowManualDepositResetTab(tab.id,titleName||"WG");

  const batch=await cowManualDepositClickText(tab.id,["批次新增","批量新增"],12000);
  if(!batch?.ok)return {ok:false,error:"8.操作DY錯誤：找不到批次新增",batch};

  const ready=await cowManualDepositWaitCreateReady(tab.id,15000);
  if(!ready?.ok)return {ok:false,error:"8.操作DY錯誤：批次新增頁面未完成",batch,ready};

  const platformSelect=await cowManualDepositSelectPlatform(tab.id,platform,12000);
  if(!platformSelect?.ok)return {ok:false,error:`8.操作DY錯誤：商戶號無法選擇 ${platform}`,platformSelect};

  const add=await cowManualDepositAddRow(tab.id);
  if(!add?.ok)return {ok:false,error:"8.操作DY錯誤：找不到新增按鈕",platformSelect,add};

  await cowSleep(700);
  const fill=await cowManualDepositFillOneRow(tab.id,item,member,amount,remark,15000);
  if(!fill?.ok)return {ok:false,error:fill?.error||`8.操作DY錯誤：${item} 填寫失敗`,platformSelect,add,fill};

  const submit=await cowManualDepositSubmitAndWaitGoogle(tab.id,18000);
  if(!submit?.ok)return {ok:false,error:submit?.error||"8.操作DY錯誤：送出後沒有進入驗證碼",platformSelect,add,fill,submit};

  await cowSetCowTitle(tab.id,titleName||"WG");
  return {
    ok:true,
    platform,
    member,
    item,
    amount,
    remark,
    tabId:tab.id,
    waitingVerification:true,
    platformSelect,
    fill,
    submit
  };
}

async function cowCreateSecondManualDepositTab(firstTab) {
  const tab=await chrome.tabs.duplicate(firstTab.id);
  if(!tab?.id)throw new Error("無法複製 DY 第二筆分頁");
  try{ await chrome.tabs.update(tab.id,{active:false}); }catch(_){}
  await cowSetTabOpenMode(tab.id,"复制");
  await cowMuteTab(tab.id);
  await cowWaitTabComplete(tab.id,30000);
  await cowMuteTab(tab.id);
  await cowSetCowTitle(tab.id,"WG-2");
  return await chrome.tabs.get(tab.id);
}

async function cowPrepareManualDepositRepay(lastQuery) {
  if(!lastQuery?.ok || !lastQuery?.preview || !lastQuery?.parsed){
    return {ok:false,error:"8.操作DY錯誤：請先完成查詢"};
  }

  const p=lastQuery.preview;
  const platform=String(lastQuery.parsed.platform||"").toUpperCase().trim();
  const member=String(lastQuery.parsed.member||"").trim();
  if(!COW_SPECIAL_WG_PLATFORMS.has(platform)){
    return {ok:false,error:`8.操作DY錯誤：${platform} 不是 DY 平台`};
  }
  if(!member)return {ok:false,error:"8.操作DY錯誤：會員帳號為空"};

  const tab=await cowEnsureTab(["be.ms1666888.com/ManualDeposit"],COW_MANUAL_DEPOSIT_URL,"WG");
  if(!tab?.id)return {ok:false,error:"8.操作DY錯誤：找不到 DY 分頁"};

  const first=await cowPrepareOneManualDepositTab(
    tab, platform, member, "充值-USDT",
    p.platformFirstAmount, p.platformFirstRemark, "WG"
  );
  if(!first?.ok)return {ok:false,error:first?.error||"8.操作DY錯誤：第一筆失敗",first};

  let second=null;
  if(p.needPlatformSecond){
    let tab2;
    try{
      tab2=await cowCreateSecondManualDepositTab(tab);
    }catch(e){
      return {ok:false,error:"8.操作DY錯誤：建立第二筆分頁失敗："+String(e.message||e),first};
    }
    second=await cowPrepareOneManualDepositTab(
      tab2, platform, member, "红利",
      p.platformSecondAmount, p.platformSecondRemark, "WG-2"
    );
    if(!second?.ok)return {ok:false,error:second?.error||"8.操作DY錯誤：第二筆失敗",first,second};
  }

  return {
    ok:true,
    platform,
    member,
    first,
    second,
    needSecond:!!p.needPlatformSecond,
    waitingVerification:true,
    message:p.needPlatformSecond
      ? `${platform} DY 兩筆已填寫並送出，等待兩組平台驗證碼`
      : `${platform} DY 第一筆已填寫並送出，等待平台驗證碼`
  };
}

async function cowPlatformWaitBatchReady(tabId, timeoutMs = 30000) {
  const started = Date.now();

  while (Date.now() - started < timeoutMs) {
    try {
      const results = await cowExecAllFrames(tabId, () => {
        const visible = el => {
          if (!el) return false;
          const r = el.getBoundingClientRect();
          const s = getComputedStyle(el);
          return r.width > 0 && r.height > 0 &&
                 s.display !== "none" && s.visibility !== "hidden";
        };

        const body = String(document.body?.innerText || "");
        const user = [...document.querySelectorAll(
          "#user_account,input[name='user_account'],input[placeholder*='用户账号'],input[placeholder*='會員'],input[placeholder*='会员']"
        )].find(visible) || null;

        const google = [...document.querySelectorAll(
          "#google_code,input[name='google_code'],input[placeholder*='谷歌'],input[placeholder*='Google'],input[placeholder*='验证码'],input[placeholder*='驗證碼']"
        )].find(visible) || null;

        const ready = !!(
          user &&
          (
            body.includes("批次加款扣款V2") ||
            body.includes("提现失败加款") ||
            body.includes("提現失敗加款") ||
            body.includes("系统加款") ||
            body.includes("系統加款") ||
            google
          )
        );

        return { ok:ready, url:location.href, title:document.title || "" };
      });

      const ok = cowPickOkFrame(results);
      if (ok) return ok;
    } catch (e) {}

    await cowSleep(120);
  }

  return null;
}

async function cowPlatformNavigateBatchV2(tabId, platform) {
  await cowMuteTab(tabId);
  await cowSetCowTitle(tabId, platform);
  await cowBringTabToFront(tabId);

  // If already on the batch page, keep current page.
  const already = await cowPlatformWaitBatchReady(tabId, 1200);
  if (already) return {ok:true, already:true};

  // Step 1: click 現金系統 / 现金系统 in top page.
  let cashClick;
  try {
    const results = await cowExecAllFrames(tabId, () => {
      const visible = el => {
        if (!el) return false;
        const r = el.getBoundingClientRect();
        const s = getComputedStyle(el);
        return r.width > 0 && r.height > 0 &&
               s.display !== "none" && s.visibility !== "hidden";
      };
      const norm = v => String(v || "").replace(/\s+/g, "").trim();

      const candidates = [...document.querySelectorAll(
        "a,button,[role='button'],li,span,div"
      )].filter(visible).filter(el => {
        const t = norm(el.innerText || el.textContent);
        return t === "现金系统" || t === "現金系統";
      });

      candidates.sort((a,b) => {
        const ar=a.getBoundingClientRect(), br=b.getBoundingClientRect();
        const aTag = a.tagName==="A" ? 0 : a.tagName==="BUTTON" ? 1 : 2;
        const bTag = b.tagName==="A" ? 0 : b.tagName==="BUTTON" ? 1 : 2;
        return aTag-bTag || ar.x-br.x || ar.y-br.y;
      });

      const target = candidates[0];
      if (!target) return {ok:false,error:"找不到現金系統"};

      const clickable = target.closest("a,button,[role='button'],li") || target;
      clickable.scrollIntoView({block:"center",inline:"center"});
      clickable.click();
      return {ok:true};
    });
    cashClick = cowPickOkFrame(results);
  } catch (e) {}

  if (!cashClick) {
    return {ok:false,error:"8.操作平台錯誤：找不到「現金系統」"};
  }

  // Observe until the submenu item appears, then click it.
  const submenuStarted = Date.now();
  let batchClicked = false;

  while (Date.now() - submenuStarted < 15000 && !batchClicked) {
    try {
      const results = await cowExecAllFrames(tabId, () => {
        const visible = el => {
          if (!el) return false;
          const r = el.getBoundingClientRect();
          const s = getComputedStyle(el);
          return r.width > 0 && r.height > 0 &&
                 s.display !== "none" && s.visibility !== "hidden";
        };
        const norm = v => String(v || "").replace(/\s+/g, "").trim();

        const candidates = [...document.querySelectorAll(
          "a,button,[role='button'],li,span,div"
        )].filter(visible).filter(el => {
          const t = norm(el.innerText || el.textContent);
          return t === "批次加款扣款V2";
        });

        candidates.sort((a,b) => {
          const ar=a.getBoundingClientRect(), br=b.getBoundingClientRect();
          const aTag = a.tagName==="A" ? 0 : a.tagName==="LI" ? 1 : 2;
          const bTag = b.tagName==="A" ? 0 : b.tagName==="LI" ? 1 : 2;
          return aTag-bTag || ar.y-br.y;
        });

        const target = candidates[0];
        if (!target) return {ok:false};

        const clickable = target.closest("a,button,[role='button'],li") || target;
        clickable.scrollIntoView({block:"center",inline:"center"});
        clickable.click();
        return {ok:true};
      });

      if (cowPickOkFrame(results)) {
        batchClicked = true;
        break;
      }
    } catch (e) {}

    await cowSleep(120);
  }

  if (!batchClicked) {
    return {ok:false,error:"8.操作平台錯誤：找不到「批次加款扣款V2」"};
  }

  const ready = await cowPlatformWaitBatchReady(tabId, 30000);
  if (!ready) {
    return {ok:false,error:"8.操作平台錯誤：已點批次加款扣款V2，但操作頁尚未完成"};
  }

  return {ok:true, already:false};
}

async function cowPlatformCleanupAllRows(tabId, maxRows = 100) {
  let deleted = 0;

  for (let round = 0; round < maxRows; round++) {
    let clicked = null;

    try {
      const results = await cowExecAllFrames(tabId, async () => {
        const visible = el => {
          if (!el) return false;
          const r = el.getBoundingClientRect();
          const s = getComputedStyle(el);
          return r.width > 0 && r.height > 0 &&
                 s.display !== "none" && s.visibility !== "hidden";
        };
        const norm = v => String(v || "").replace(/\s+/g, "").trim();

        const buttons = [...document.querySelectorAll(
          "button,a,input[type='button'],input[type='submit'],[role='button']"
        )].filter(visible).filter(el => {
          const labels = [
            el.innerText || "",
            el.textContent || "",
            el.value || "",
            el.title || "",
            el.getAttribute("aria-label") || ""
          ].map(norm).filter(Boolean);
          if (!labels.some(t => t === "删除" || t === "刪除" || /^(delete|remove)$/i.test(t))) return false;
          const r = el.getBoundingClientRect();
          return r.y > 100 && r.width < 180 && r.height < 80;
        });

        buttons.sort((a,b) => {
          const ar=a.getBoundingClientRect(), br=b.getBoundingClientRect();
          return ar.y-br.y || ar.x-br.x;
        });

        const target = buttons[0] || null;
        if (!target) return {ok:false,reason:"empty"};

        const beforeCount = buttons.length;
        const parent = target.closest("tr") || target.parentElement;
        const beforeText = String(parent?.innerText || "");

        const waitRemoved = () => new Promise(resolve => {
          let done=false, obs=null, timer=null;
          const finish=v=>{
            if(done)return;
            done=true;
            if(obs)obs.disconnect();
            if(timer)clearTimeout(timer);
            resolve(v);
          };
          const check=()=>{
            const nowButtons=[...document.querySelectorAll(
              "button,a,input[type='button'],input[type='submit'],[role='button']"
            )].filter(visible).filter(el=>{
              const labels=[
                el.innerText||"", el.textContent||"", el.value||"",
                el.title||"", el.getAttribute("aria-label")||""
              ].map(norm).filter(Boolean);
              return labels.some(t=>t==="删除" || t==="刪除" || /^(delete|remove)$/i.test(t));
            });
            if (!target.isConnected || nowButtons.length < beforeCount) finish(true);
          };
          obs=new MutationObserver(check);
          obs.observe(document.documentElement || document.body,{
            childList:true,subtree:true,attributes:true,attributeFilter:["class","style"]
          });
          timer=setTimeout(()=>finish(false),10000);
          check();
        });

        target.scrollIntoView({block:"center",inline:"center"});
        target.click();
        const removed = await waitRemoved();

        return {ok:removed, beforeCount, beforeText:beforeText.slice(0,200)};
      });

      clicked = cowPickOkFrame(results);
    } catch (e) {}

    if (clicked) {
      deleted += 1;
      continue;
    }

    // No deletable row anywhere: cleanup is complete.
    let anyDelete = false;
    try {
      const probes = await cowExecAllFrames(tabId, () => {
        const visible = el => {
          if (!el) return false;
          const r=el.getBoundingClientRect(), s=getComputedStyle(el);
          return r.width>0&&r.height>0&&s.display!=="none"&&s.visibility!=="hidden";
        };
        const norm = v => String(v || "").replace(/\s+/g,"").trim();
        const count=[...document.querySelectorAll(
          "button,a,input[type='button'],input[type='submit'],[role='button']"
        )].filter(visible).filter(el=>{
          const labels=[
            el.innerText||"", el.textContent||"", el.value||"",
            el.title||"", el.getAttribute("aria-label")||""
          ].map(norm).filter(Boolean);
          return labels.some(t=>t==="删除" || t==="刪除" || /^(delete|remove)$/i.test(t));
        }).length;
        return {ok:true,count};
      });
      anyDelete = (probes || []).some(x => Number(x?.result?.count || 0) > 0);
    } catch (e) {}

    if (!anyDelete) {
      return {ok:true,deletedCount:deleted};
    }

    return {ok:false,error:"8.操作平台錯誤：刪除舊資料後，該列沒有消失",deletedCount:deleted};
  }

  return {
    ok:false,
    error:`8.操作平台錯誤：舊資料超過 ${maxRows} 筆，停止清除`,
    deletedCount:deleted
  };
}

async function cowPlatformAddMember(tabId, member) {
  const started = Date.now();

  while (Date.now() - started < 20000) {
    try {
      const results = await cowExecAllFrames(tabId, async (member) => {
        const visible = el => {
          if (!el) return false;
          const r=el.getBoundingClientRect(), s=getComputedStyle(el);
          return r.width>0&&r.height>0&&s.display!=="none"&&s.visibility!=="hidden";
        };
        const norm = v => String(v || "").replace(/\s+/g,"").trim();

        const setValue = (el,value) => {
          el.scrollIntoView({block:"center",inline:"center"});
          el.focus();
          const proto = Object.getPrototypeOf(el);
          const setter = Object.getOwnPropertyDescriptor(proto,"value")?.set;
          if (setter) setter.call(el,String(value));
          else el.value=String(value);
          el.dispatchEvent(new Event("input",{bubbles:true}));
          el.dispatchEvent(new Event("change",{bubbles:true}));
          el.dispatchEvent(new KeyboardEvent("keyup",{bubbles:true}));
        };

        const user=[...document.querySelectorAll(
          "#user_account,input[name='user_account'],input[placeholder*='用户账号'],input[placeholder*='會員'],input[placeholder*='会员']"
        )].find(visible) || null;
        if(!user)return {ok:false};

        setValue(user,member);
        const ur=user.getBoundingClientRect();

        const adds=[...document.querySelectorAll(
          "button,a,input[type='button'],input[type='submit'],[role='button'],.btn,.button"
        )].filter(visible).filter(el=>{
          const labels=[el.innerText||"",el.textContent||"",el.value||""]
            .map(norm).filter(Boolean);
          if(!labels.some(t=>t==="添加"))return false;
          const r=el.getBoundingClientRect();
          return r.width<260&&r.height<90&&Math.abs(r.y-ur.y)<130;
        }).sort((a,b)=>{
          const ar=a.getBoundingClientRect(),br=b.getBoundingClientRect();
          return Math.abs(ar.y-ur.y)-Math.abs(br.y-ur.y) || ar.x-br.x;
        });

        const add=adds[0]||null;
        if(!add)return {ok:false};

        const waitMember = () => new Promise(resolve=>{
          let done=false,obs=null,timer=null;
          const finish=v=>{
            if(done)return;
            done=true;
            if(obs)obs.disconnect();
            if(timer)clearTimeout(timer);
            resolve(v);
          };
          const check=()=>{
            const text=String(document.body?.innerText||"");
            const hasMember=text.includes(member);
            const hasDelete=[...document.querySelectorAll(
              "button,a,input[type='button'],input[type='submit'],[role='button']"
            )].filter(visible).some(el=>{
              const labels=[el.innerText||"",el.textContent||"",el.value||""]
                .map(norm).filter(Boolean);
              return labels.some(t=>t==="删除"||t==="刪除");
            });
            if(hasMember&&hasDelete)finish(true);
          };
          obs=new MutationObserver(check);
          obs.observe(document.documentElement||document.body,{childList:true,subtree:true,attributes:true});
          timer=setTimeout(()=>finish(false),12000);
          check();
        });

        add.scrollIntoView({block:"center",inline:"center"});
        add.click();
        const appeared=await waitMember();

        return {ok:appeared,member};
      }, [member]);

      const ok = cowPickOkFrame(results);
      if (ok) return ok;
    } catch (e) {}

    await cowSleep(120);
  }

  return {ok:false,error:`8.操作平台錯誤：會員 ${member} 添加後沒有出現在操作區`};
}

async function cowPlatformFillRow(tabId, operationType, amount, remark) {
  const started = Date.now();

  while (Date.now() - started < 20000) {
    try {
      const results = await cowExecAllFrames(tabId, (operationType, amount, remark) => {
        const visible = el => {
          if (!el) return false;
          const r=el.getBoundingClientRect(), s=getComputedStyle(el);
          return r.width>0&&r.height>0&&s.display!=="none"&&s.visibility!=="hidden";
        };
        const norm=v=>String(v||"").replace(/\s+/g,"").trim();

        const setValue=(el,value)=>{
          el.scrollIntoView({block:"center",inline:"center"});
          el.focus();
          const proto=Object.getPrototypeOf(el);
          const setter=Object.getOwnPropertyDescriptor(proto,"value")?.set;
          if(setter)setter.call(el,String(value));
          else el.value=String(value);
          el.dispatchEvent(new Event("input",{bubbles:true}));
          el.dispatchEvent(new Event("change",{bubbles:true}));
          el.dispatchEvent(new KeyboardEvent("keydown",{bubbles:true}));
          el.dispatchEvent(new KeyboardEvent("keyup",{bubbles:true}));
          el.blur();
          el.focus();
        };

        const clickType=()=>{
          // Native select first.
          const selects=[...document.querySelectorAll("select")].filter(visible)
            .filter(sel=>[...sel.options].some(o=>norm(o.text).includes(norm(operationType))));
          if(selects.length){
            const sel=selects[0];
            const opt=[...sel.options].find(o=>norm(o.text).includes(norm(operationType)));
            if(opt){
              sel.value=opt.value;
              sel.dispatchEvent(new Event("input",{bubbles:true}));
              sel.dispatchEvent(new Event("change",{bubbles:true}));
              return true;
            }
          }

          // Radio/label/text layout used by YD/JD/etc.
          const texts=[...document.querySelectorAll(
            "label,span,a,button,div"
          )].filter(visible).filter(el=>norm(el.innerText||el.textContent)===norm(operationType));

          texts.sort((a,b)=>{
            const ar=a.getBoundingClientRect(),br=b.getBoundingClientRect();
            const aArea=ar.width*ar.height,bArea=br.width*br.height;
            return aArea-bArea || ar.y-br.y;
          });

          const el=texts[0]||null;
          if(!el)return false;

          const label=el.closest("label")||el;
          label.scrollIntoView({block:"center",inline:"center"});
          label.click();

          const radio=label.querySelector?.("input[type='radio']") ||
            label.previousElementSibling?.matches?.("input[type='radio']") && label.previousElementSibling;
          if(radio && !radio.checked) radio.click();
          return true;
        };

        const selected=clickType();
        if(!selected)return {ok:false};

        const editable=[...document.querySelectorAll("input,textarea")].filter(el=>{
          const type=(el.getAttribute("type")||"").toLowerCase();
          return visible(el)&&!el.disabled&&!el.readOnly&&
            !["hidden","button","submit","checkbox","radio","password"].includes(type);
        });

        const amountInputs=editable.filter(el=>{
          const t=[
            el.name||"",el.id||"",el.placeholder||"",String(el.className||"")
          ].join(" ");
          return /change_balance|金额|金額|amount|balance/i.test(t) &&
                 !/google|谷歌|验证码|驗證碼|user_account|会员|會員|账号|帳號|商户|商戶/i.test(t);
        });

        const remarkInputs=editable.filter(el=>{
          const t=[
            el.name||"",el.id||"",el.placeholder||"",String(el.className||"")
          ].join(" ");
          return /change_remark|备注|備註|remark/i.test(t) &&
                 !/google|谷歌|验证码|驗證碼/i.test(t);
        });

        const amountInput=amountInputs[0] ||
          editable.find(el=>/金额|金額/.test(el.placeholder||"")) || null;
        const remarkInput=remarkInputs[0] ||
          editable.find(el=>/备注|備註/.test(el.placeholder||"")) || null;

        if(!amountInput||!remarkInput)return {ok:false};

        setValue(amountInput,amount);
        setValue(remarkInput,remark);

        const google=[...document.querySelectorAll(
          "#google_code,input[name='google_code'],input[placeholder*='谷歌'],input[placeholder*='Google'],input[placeholder*='验证码'],input[placeholder*='驗證碼']"
        )].find(visible)||null;

        if(google){
          google.scrollIntoView({block:"center",inline:"center"});
          google.focus();
        }

        const amountOk=String(amountInput.value||"")===String(amount);
        const remarkOk=String(remarkInput.value||"")===String(remark);

        return {
          ok:amountOk&&remarkOk,
          amountOk,remarkOk,
          operationType,
          amount:String(amountInput.value||""),
          remark:String(remarkInput.value||""),
          hasGoogle:!!google
        };
      }, [operationType, String(amount), String(remark)]);

      const ok=cowPickOkFrame(results);
      if(ok)return ok;
    } catch(e){}

    await cowSleep(120);
  }

  return {
    ok:false,
    error:`8.操作平台錯誤：${operationType} 的金額或備註填寫失敗`
  };
}

async function cowCreateSecondPlatformTab(firstTab, url, platform) {
  const tab = await chrome.tabs.duplicate(firstTab.id);

  if(!tab?.id) throw new Error("無法複製平台第二筆分頁");

  try{ await chrome.tabs.update(tab.id,{active:false}); }catch(_){}
  await cowSetTabOpenMode(tab.id,"复制");
  await cowMuteTab(tab.id);
  await cowWaitTabComplete(tab.id,30000);
  await cowMuteTab(tab.id);
  await cowSetCowTitle(tab.id, platform + "-2");
  return await chrome.tabs.get(tab.id);
}

async function cowPrepareOneStandardPlatformTab(tab, platform, member, operationType, amount, remark) {
  await cowMuteTab(tab.id);
  await cowSetCowTitle(tab.id, platform);
  await cowBringTabToFront(tab.id);

  const nav=await cowPlatformNavigateBatchV2(tab.id,platform);
  if(!nav?.ok)return nav;

  const cleanup=await cowPlatformCleanupAllRows(tab.id,100);
  if(!cleanup?.ok)return cleanup;

  const add=await cowPlatformAddMember(tab.id,member);
  if(!add?.ok)return add;

  const fill=await cowPlatformFillRow(tab.id,operationType,amount,remark);
  if(!fill?.ok)return fill;

  return {
    ok:true,
    platform,
    member,
    operationType,
    amount,
    remark,
    deletedCount:cleanup.deletedCount || 0,
    waitingVerification:true
  };
}

async function cowPrepareStandardPlatformRepay(lastQuery) {
  if(!lastQuery?.ok || !lastQuery?.preview || !lastQuery?.parsed){
    return {ok:false,error:"8.操作平台錯誤：請先完成查詢"};
  }

  const p=lastQuery.preview;
  const platform=String(lastQuery.parsed.platform||"").toUpperCase().trim();
  const member=String(lastQuery.parsed.member||"").trim();

  if(COW_SPECIAL_WG_PLATFORMS.has(platform)){
    return {
      ok:true,
      skipped:true,
      reason:"WG platform",
      platform,
      message:"WG 尚未接入此標準平台流程"
    };
  }

  const url=COW_REPAY_PLATFORM_URLS[platform];
  if(!url)return {ok:false,error:`8.操作平台錯誤：找不到 ${platform} 網址`};

  const host=new URL(url).hostname;
  const tab=await cowEnsureTab([host],url,platform);
  if(!tab?.id)return {ok:false,error:`8.操作平台錯誤：找不到 ${platform} 分頁`};

  const first=await cowPrepareOneStandardPlatformTab(
    tab,
    platform,
    member,
    "提现失败加款",
    p.platformFirstAmount,
    p.platformFirstRemark
  );
  if(!first?.ok){
    return {ok:false,error:first?.error||"8.操作平台錯誤：第一筆填寫失敗",first};
  }

  let second=null;
  if(p.needPlatformSecond){
    let tab2;
    try{
      tab2=await cowCreateSecondPlatformTab(tab,url,platform);
    }catch(e){
      return {ok:false,error:"8.操作平台錯誤：建立第二筆平台分頁失敗："+String(e.message||e),first};
    }

    second=await cowPrepareOneStandardPlatformTab(
      tab2,
      platform,
      member,
      "系统加款",
      p.platformSecondAmount,
      p.platformSecondRemark
    );

    if(!second?.ok){
      return {ok:false,error:second?.error||"8.操作平台錯誤：第二筆填寫失敗",first,second};
    }
  }

  return {
    ok:true,
    platform,
    member,
    first,
    second,
    needSecond:!!p.needPlatformSecond,
    waitingVerification:true,
    message:p.needPlatformSecond
      ? "平台兩筆已填寫，等待兩組驗證碼"
      : "平台第一筆已填寫，等待驗證碼"
  };
}


chrome.runtime.onMessage.addListener((message,sender,sendResponse)=>{
  if(!message || message.type!=="cow_prepare_manual_deposit") return;
  (async()=>{
    try{
      sendResponse(await cowPrepareManualDepositRepay(message.lastQuery||null));
    }catch(e){
      sendResponse({ok:false,error:"8.操作DY錯誤："+String(e.message||e)});
    }
  })();
  return true;
});

chrome.runtime.onMessage.addListener((message,sender,sendResponse)=>{
  if(!message || message.type!=="cow_prepare_standard_platform") return;
  (async()=>{
    try{
      sendResponse(await cowPrepareStandardPlatformRepay(message.lastQuery||null));
    }catch(e){
      sendResponse({ok:false,error:"8.操作平台錯誤："+String(e.message||e)});
    }
  })();
  return true;
});


chrome.runtime.onMessage.addListener((message,sender,sendResponse)=>{
  if(!message || message.type!=="cow_open_repay_platform") return;
  (async()=>{
    try{sendResponse(await cowOpenRepayPlatform(message.lastQuery||null));}
    catch(e){sendResponse({ok:false,error:"8.操作平台錯誤："+String(e.message||e)});}
  })();
  return true;
});


chrome.runtime.onMessage.addListener((message,sender,sendResponse)=>{
  if(!message || message.type!=="cow_sfp_repay_prepare") return;
  (async()=>{
    try{sendResponse(await cowPrepareSfpRepay(message.lastQuery||null));}
    catch(e){sendResponse({ok:false,error:"7.操作四方錯誤："+String(e.message||e)});}
  })();
  return true;
});

chrome.runtime.onMessage.addListener((message,sender,sendResponse)=>{
  if(!message || message.type!=="cow_sfp_verify") return;
  (async()=>{
    try{sendResponse(await cowSubmitSfpVerification(message.code||""));}
    catch(e){sendResponse({ok:false,error:"四方驗證碼錯誤："+String(e.message||e)});}
  })();
  return true;
});


chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (!message || message.type !== "cow_ms_repay_execute") return;

  (async () => {
    try {
      const result = await cowOperateMsRepay(message.lastQuery || null);
      sendResponse(result);
    } catch (e) {
      sendResponse({ ok:false, error:"6.操作MS錯誤：" + String(e.message || e) });
    }
  })();

  return true;
});



// ===== v0.5.5 第三分页「（中）出款金额有少」查询测试 =====
const COW_SHORT_MERCHANT_MAP = {
  TD168A:{bank:"四方支付-01H700XFJ43NAP900RV3JKB4DP",channel:"TD回单支付",kind:"A",abbr:"回单"},
  TD168B:{bank:"四方支付宝-01HY37QXZYRQ5CH9XXWY85BJJN",channel:"TD回单支付宝",kind:"B",abbr:"四方支付宝"},
  TD168D:{bank:"四方-数字人民币-01JTNWJ6WXG6NRDNJC07R5C1M2",channel:"二类卡专用回单",kind:"D",abbr:"回单二类卡"},
  XY168A:{bank:"四方-01JWY2GGZN7W6FW75M6BAT5WQA",channel:"XY回单支付",kind:"A",abbr:"回单"},
  XY168B:{bank:"四方支付宝-01JWY2GSHY2CRSFF0DXTWYDXGX",channel:"XY回单支付宝",kind:"B",abbr:"四方支付宝"},
  XY168D:{bank:"四方数字人民币-01JWY2HNHX5YB17N7TSEK8J9VQ",channel:"二类卡专用回单",kind:"D",abbr:"回单二类卡"},
  OL168A:{bank:"四方支付-01H7Y5W09HA9BW2M5WGSKS29SY",channel:"OL回单支付",kind:"A",abbr:"回单"},
  OL168B:{bank:"四方支付宝-01HWCNS8GGYT8SQK1QMKZGDCS1",channel:"OL回单支付宝",kind:"B",abbr:"四方支付宝"},
  OL168D:{bank:"四方数字人民币-01JTNZYJ84N4DZ011926AMAC2M",channel:"二类卡专用回单",kind:"D",abbr:"回单二类卡"},
  LS168A:{bank:"四方支付-01H7Y5VP3DXYEEYM7EX8B53S38",channel:"LS回单支付",kind:"A",abbr:"回单"},
  LS168B:{bank:"四方支付宝-01HWCNT5P4ERGSMR6ZDVXTCXNG",channel:"LS回单支付宝",kind:"B",abbr:"四方支付宝"},
  LS168D:{bank:"四方数字人民币-01JTNZY5C9CSD5TFM55PD6J0HN",channel:"二类卡专用回单",kind:"D",abbr:"回单二类卡"},
  XH168A:{bank:"四方支付-01H7Y5SBBBVPRKX2WH96GRWY39",channel:"XH回单支付",kind:"A",abbr:"回单"},
  XH168B:{bank:"四方支付宝-01HZXB60JNJDADY6JZWRT4S8DA",channel:"XH回单支付宝",kind:"B",abbr:"四方支付宝"},
  XH168D:{bank:"四方数字人民币-01JTNZWJNT8YR7ZPMJ231ZPR1N",channel:"二类卡专用回单",kind:"D",abbr:"回单二类卡"},
  RF168A:{bank:"四方支付-01H700VGTBT6MZ47PDN348768E",channel:"RF回单支付",kind:"A",abbr:"回单"},
  RF168B:{bank:"四方支付宝-01HY37QPPJBJVV0TZCPTYVKXJS",channel:"RF回单支付宝",kind:"B",abbr:"四方支付宝"},
  RF168D:{bank:"四方-数字人民币-01JTNWHQQ970ZPQ0Z9Z4F30XNE",channel:"二类卡专用回单",kind:"D",abbr:"回单二类卡"},
  HS168A:{bank:"四方支付-01JDRF04RV37GYV62JXGAJ2KKT",channel:"HS回单支付",kind:"A",abbr:"回单"},
  HS168B:{bank:"四方支付宝-01JDRF0FBA6Y0ZTAQGYC9P6WAZ",channel:"HS回单支付宝",kind:"B",abbr:"四方支付宝"},
  HS168D:{bank:"四方-数字人民币-01JS9KBAN9PC7155GQ1SRK82X4",channel:"二类卡专用回单",kind:"D",abbr:"回单二类卡"},
  YD168A:{bank:"四方-01JWY5G6X2R7GJBWVXJGRRWW30",channel:"YD回单支付",kind:"A",abbr:"回单"},
  YD168B:{bank:"四方支付宝-01JWY5GEZEVKYE4511BNZWB7X1",channel:"YD回单支付宝",kind:"B",abbr:"四方支付宝"},
  YD168D:{bank:"四方数字人民币-01JWY5NB2BC7EB23F24QQ83VXT",channel:"二类卡专用回单",kind:"D",abbr:"回单二类卡"},
  ND168A:{bank:"四方支付-01J0R7D1YAF2Z1TWN8QPJ6G78W",channel:"ND回单支付",kind:"A",abbr:"回单"},
  ND168B:{bank:"四方支付宝-01J0R7DPBHHVT4R63GNXHJ7H5Y",channel:"ND回单支付宝",kind:"B",abbr:"四方支付宝"},
  ND168D:{bank:"四方数字人民币-01JTNWQZRE9HYR3S6WZZTKQJY6",channel:"二类卡专用回单",kind:"D",abbr:"回单二类卡"},
  YS168A:{bank:"四方-01H700ZPFBDFNYYT17TPGQ36GE",channel:"YS回单支付",kind:"A",abbr:"回单"},
  YS168B:{bank:"四方支付宝-01HWCQ7QT4FR28T1K9X4NZR6S4",channel:"YS回单支付宝",kind:"B",abbr:"四方支付宝"},
  YS168D:{bank:"四方数字人民币-01JTNWMQHP0YJ7TWJQANZEVGVW",channel:"二类卡专用回单",kind:"D",abbr:"回单二类卡"},
  SH168A:{bank:"四方-01H700YJ1YJ96YD2CJ9GABG6DJ",channel:"SH回单支付",kind:"A",abbr:"回单"},
  SH168B:{bank:"四方支付宝-01HY378TG9NRJAVZ2KPB1M9A47",channel:"SH回单支付宝",kind:"B",abbr:"四方支付宝"},
  SH168D:{bank:"四方数字人民币-01JTNWJH88J27R6AZK78ZHN6JN",channel:"二类卡专用回单",kind:"D",abbr:"回单二类卡"},
  JY168A:{bank:"四方-01HN2AW385NFA2PVRHEB189E9A",channel:"JY回单支付",kind:"A",abbr:"回单"},
  JY168B:{bank:"四方支付宝-01HWCQ8H6W09YANEFKB7SBV922",channel:"JY回单支付宝",kind:"B",abbr:"四方支付宝"},
  JY168D:{bank:"四方数字人民币-01JTNWNC13W6E9NCPJV295ZVGZ",channel:"二类卡专用回单",kind:"D",abbr:"回单二类卡"},
  JD168A:{bank:"四方-01H7FABE5HZZVYAC7V2YNWJM8F",channel:"JD回单支付",kind:"A",abbr:"回单"},
  JD168B:{bank:"四方支付宝-01HY37CVM62WK8ZGKTPY97T88Z",channel:"JD回单支付宝",kind:"B",abbr:"四方支付宝"},
  JD168D:{bank:"四方数字人民币-01JTNWQNX2N422J4J3VPF43XAN",channel:"二类卡专用回单",kind:"D",abbr:"回单二类卡"},
  MT168A:{bank:"四方-01H7FAATK64KZXN85HWXXY2DJ2",channel:"MT回单支付",kind:"A",abbr:"回单"},
  MT168B:{bank:"四方支付宝-01HWCNTS6EBJGNJDVTBKRA9RV5",channel:"MT回单支付宝",kind:"B",abbr:"四方支付宝"},
  MT168D:{bank:"四方数字人民币-01JTNWQ7HFBX4Q7THCA2RPJSGQ",channel:"二类卡专用回单",kind:"D",abbr:"回单二类卡"},
  FB168A:{bank:"四方支付-01H7FA8B27JXP67V6RMM2B5WAK",channel:"FB回单支付",kind:"A",abbr:"回单"},
  FB168B:{bank:"四方支付宝-01HY37KRJ6W2AB2K6A76RY0HK9",channel:"FB回单支付宝",kind:"B",abbr:"四方支付宝"},
  FB168D:{bank:"四方数字人民币-01JTNWNVY4WZ37KRVXFHYYA2G9",channel:"二类卡专用回单",kind:"D",abbr:"回单二类卡"}
};

function cowShortCleanMerchantCode(v) {
  return String(v || "").trim().replace(/\s+/g, "").replace(/\(.*?\)$/, "").toUpperCase();
}

function cowShortBankTypeOk(kind, bank) {
  const t = String(bank || "").replace(/\s+/g, "");
  if (kind === "A") return t.startsWith("四方支付-") || /^四方-01/.test(t);
  if (kind === "B") return t.startsWith("四方支付宝-");
  if (kind === "D") return t.startsWith("四方数字人民币-") || t.startsWith("四方-数字人民币-");
  return false;
}

async function cowQuerySfpShort(tabId, orderNo, reloadMarker = null, dateText = null) {
  await cowMuteTab(tabId);
  await cowBringTabToFront(tabId);
  await cowSetCowTitle(tabId, "四方");

  const pageReady = await cowWaitPageReady(tabId, "sfp", reloadMarker);
  if (!pageReady) return {ok:false,error:"1.查询四方错误：页面等待完成超时"};

  if (dateText) {
    const dr = await cowSetQueryDateRange(tabId, "sfp", dateText);
    if (!dr?.ok) return {ok:false,error:"1.查询四方错误：" + (dr?.error || "日期设置失败")};
    const orderReady = await cowWaitOrderInputReady(tabId, "sfp");
    if (!orderReady) return {ok:false,error:"1.查询四方错误：日期设置完成，但商户单号栏尚未恢复可操作"};
  }

  const start = await cowExec(tabId, (order) => {
    const visible = el => { if(!el) return false; const r=el.getBoundingClientRect(),s=getComputedStyle(el); return r.width>0&&r.height>0&&s.display!=="none"&&s.visibility!=="hidden"; };
    const setNativeValue=(el,value)=>{const proto=Object.getPrototypeOf(el),d=Object.getOwnPropertyDescriptor(proto,"value"); if(d&&d.set)d.set.call(el,value);else el.value=value; el.dispatchEvent(new Event("input",{bubbles:true}));el.dispatchEvent(new Event("change",{bubbles:true}));};
    const input=[...document.querySelectorAll('input[placeholder="请输入商户单号"]')].find(visible);
    if(!input)return {ok:false,error:"1.查询四方错误：找不到商户单号输入框"};
    setNativeValue(input,""); setNativeValue(input,order);
    const btn=[...document.querySelectorAll("button")].filter(visible).find(el=>(el.innerText||el.textContent||"").replace(/\s+/g,"")==="查询");
    if(!btn)return {ok:false,error:"1.查询四方错误：找不到查询按钮"};
    btn.click(); return {ok:true};
  }, [orderNo]);
  if(!start?.ok)return start||{ok:false,error:"1.查询四方错误"};

  for(let i=0;i<48;i++){
    await cowSleep(250);
    const result=await cowExec(tabId,(order)=>{
      const num=v=>{const m=String(v??"").replace(/,/g,"").match(/-?\d+(?:\.\d+)?/);return m?Number(m[0]):0;};
      const trs=[...document.querySelectorAll("tr")];
      for(const tr of trs){
        const cells=[...tr.querySelectorAll("th,td")];
        const row=cells.map(td=>(td.innerText||td.textContent||"").trim());
        if(!row.some(c=>String(c).includes(order)))continue;
        if(row.length<18)return {ok:false,error:"1.查询四方错误：资料栏位不足",row};
        const op=String(row[17]||"").trim();
        if(op.includes("加扣款"))return {ok:false,error:"加扣款按钮存在 请检查",row,operationText:op};
        return {
          ok:true,
          internalOrderNo:String(row[0]||"").trim(),
          merchantCode:String(row[1]||"").trim(),
          merchantOrderNo:String(row[3]||"").trim(),
          member:String(row[4]||"").trim(),
          actualAmount:num(row[12]),
          merchantFee:num(row[13]),
          channelFee:num(row[14]),
          status:String(row[16]||"").trim(),
          operationText:op,
          row
        };
      }
      return null;
    },[orderNo]);
    if(result)return result;
  }
  return {ok:false,error:`四方查无资料：${orderNo}`};
}

async function cowReadMsFullBank(tabId, orderNo) {
  return await cowExec(tabId, (order) => {
    const norm=v=>String(v??"").trim();
    const trs=[...document.querySelectorAll("tr")];
    for(const tr of trs){
      const cells=[...tr.querySelectorAll("th,td")];
      const texts=cells.map(td=>norm(td.innerText||td.textContent));
      let idx=texts.findIndex(c=>c===order);
      if(idx<0)idx=texts.findIndex(c=>c.includes(order));
      if(idx<0||idx+3>=cells.length)continue;
      const cell=cells[idx+3];
      const candidates=[cell,...cell.querySelectorAll("[title],[aria-label]")];
      for(const el of candidates){
        const title=norm(el.getAttribute?.("title"));
        if(title&&title.length>6)return title;
        const aria=norm(el.getAttribute?.("aria-label"));
        if(aria&&aria.length>6)return aria;
      }
      return norm(cell.textContent||cell.innerText);
    }
    return "";
  }, [orderNo]);
}

async function cowRunShortQuery(rawText) {
  // 第三分页日期输入同时支持：
  // 1) 日期独立一行：9/19\nTD WKRM_47428 tt25301884\n有少补回22
  // 2) 日期与资料同一行：9/19 TD WKRM_47428 tt25301884\n有少补回22
  let parsed;
  try {
    if (!/有少\s*[補补]回\s*[0-9]+(?:\.[0-9]+)?/.test(String(rawText||""))) {
      return {ok:false,error:"0.解析内容错误：找不到「有少补回」金额"};
    }
    parsed = cowParseRepayText(rawText);
  } catch(e) { return {ok:false,error:String(e.message||e)}; }

  if (!(Number(parsed.repayAmount) > 0)) return {ok:false,error:"输入金额异常 请检查"};

  let sfpTab, msTab;
  try { sfpTab=await cowEnsureTab(["sfp.csussr.com"],COW_SFP_WORK_URL,"四方"); }
  catch(e){ return {ok:false,error:"1.查询四方错误：自动开启四方失败："+String(e.message||e)}; }
  try { msTab=await cowEnsureTab(["ms.rcppay.com"],COW_MS_WORK_URL,"MS"); }
  catch(e){ return {ok:false,error:"2.查询MS错误：自动开启MS失败："+String(e.message||e)}; }

  try { sfpTab=await cowEnsureWorkPage(sfpTab.id,COW_SFP_WORK_URL,"四方"); }
  catch(e){ return {ok:false,error:"1.查询四方错误：切换提现记录页失败："+String(e.message||e)}; }
  try { msTab=await cowEnsureWorkPage(msTab.id,COW_MS_WORK_URL,"MS"); }
  catch(e){ return {ok:false,error:"2.查询MS错误：切换第三方出款页失败："+String(e.message||e)}; }

  const reloadMarkers=await cowReloadNeededTabs([sfpTab.id,msTab.id]);
  const sfp=await cowQuerySfpShort(sfpTab.id,parsed.orderNo,reloadMarkers[sfpTab.id]||null,parsed.dateText||null);
  if(!sfp?.ok)return {ok:false,error:sfp?.error||"1.查询四方失败",parsed,sfp};

  const merchantCode=cowShortCleanMerchantCode(sfp.merchantCode);
  if(!merchantCode.startsWith(String(parsed.platform||"").toUpperCase())) {
    return {ok:false,error:"四方商户平台不对应 请检查",parsed,sfp,merchantCode};
  }
  const map=COW_SHORT_MERCHANT_MAP[merchantCode];
  if(!map)return {ok:false,error:`四方商户 ${merchantCode} 未设置对应资料 请检查`,parsed,sfp,merchantCode};

  const msQueryOrderNo=COW_SPECIAL_WG_PLATFORMS.has(parsed.platform)?sfp.internalOrderNo:parsed.orderNo;
  const ms=await cowQueryMs(msTab.id,parsed.platform,msQueryOrderNo,reloadMarkers[msTab.id]||null,parsed.dateText||null);
  if(!ms?.ok)return {ok:false,error:ms?.error||"MS查无资料",parsed,sfp,ms};

  const fullBank=await cowReadMsFullBank(msTab.id,msQueryOrderNo);
  if(fullBank)ms.bank=fullBank;
  const bank=String(ms.bank||"").replace(/\s+/g,"").trim();
  const expectedBank=String(map.bank||"").replace(/\s+/g,"").trim();

  if(!cowShortBankTypeOk(map.kind,bank)) {
    return {ok:false,error:"四方、MS商户类型不对应 请检查",parsed,sfp,ms,merchantCode,expectedBank:map.bank};
  }
  if(bank!==expectedBank) {
    return {ok:false,error:"四方、MS商户不对应 请检查",parsed,sfp,ms,merchantCode,expectedBank:map.bank};
  }

  const shortAmount=Number(parsed.repayAmount);
  const actual=Number(ms.actualPayout||0);
  if(!(shortAmount>0))return {ok:false,error:"输入金额异常 请检查",parsed,sfp,ms};
  if(Math.abs(shortAmount-actual)<1e-9)return {ok:false,error:"输入金额＝出款金额 请检查",parsed,sfp,ms};
  if(shortAmount>actual)return {ok:false,error:"输入金额大于出款金额 请检查",parsed,sfp,ms};

  const adjust=actual-shortAmount;
  if(!(adjust>0))return {ok:false,error:"四方调整金额异常 请检查",parsed,sfp,ms};

  let payoutFeeRepay=0;
  if(actual>0 && Number(ms.systemFee||0)>0){
    const raw=shortAmount/actual*Number(ms.systemFee||0);
    payoutFeeRepay=COW_PAYOUT_FEE_FLOOR_PLATFORMS.has(String(parsed.platform||"").toUpperCase())?Math.floor(raw):Math.ceil(raw);
  }
  const datePrefix=cowPrefixDate(parsed.dateText||null);
  const fourRemark=datePrefix + String(parsed.platform).toUpperCase() + map.abbr + "人工提款" + sfp.internalOrderNo;
  const msRemark=datePrefix + String(parsed.member) + "第三方出款失败补回拆账";

  const preview={
    ok:true,
    status:"查询完成",
    platform:String(parsed.platform||"").toUpperCase(),
    orderNo:parsed.orderNo,
    member:parsed.member,
    dateText:parsed.dateText||null,
    shortAmount,
    repayAmount:shortAmount,
    rmbAmount:Number(ms.rmbAmount||0),
    actualPayout:actual,
    systemFee:Number(ms.systemFee||0),
    bankFee:Number(ms.bankFee||0),
    splitText:`${cowFmt(adjust)}+${cowFmt(shortAmount)}`,
    isSplit:true,
    sfpAdjustAmount:adjust,
    sfpOrderAmount:shortAmount,
    merchantCode,
    merchantType:map.kind,
    channelName:map.channel,
    msBank:bank,
    expectedMsBank:map.bank,
    sfpInternalOrderNo:sfp.internalOrderNo,
    sfpRemark:fourRemark,
    channelRemark:fourRemark,
    msAmount:shortAmount,
    msRemark,
    payoutFeeRepay,
    platformFirstAmount:shortAmount,
    platformFirstRemark:datePrefix+"2出款失败补回",
    needPlatformSecond:payoutFeeRepay>0,
    platformSecondAmount:payoutFeeRepay>0?payoutFeeRepay:null,
    platformSecondRemark:payoutFeeRepay>0?datePrefix+"出款手续费补回":null
  };

  return {ok:true,parsed,sfp,ms,preview,msQueryOrderNo,queryMode:COW_SPECIAL_WG_PLATFORMS.has(parsed.platform)?"WG":"normal"};
}



// ===== 出款金额有少：四方两笔（商户余额调整 + 通道余额调整）测试阶段 =====
// 自动化只做到：填写资料 -> 点击第一次“确定” -> 停在财务谷歌验证码弹窗。
// 不读取、不填写、也不提交验证码。
async function cowPrepareShortSfpAdjustments(lastQuery) {
  if (!lastQuery || !lastQuery.ok || !lastQuery.preview || !lastQuery.sfp) {
    return {ok:false,error:"操作四方错误：请先完成出款金额有少查询"};
  }

  const p = lastQuery.preview || {};
  const parsed = lastQuery.parsed || {};
  const sfp = lastQuery.sfp || {};
  const merchantCode = String(p.merchantCode || "").trim();
  const channelName = String(p.channelName || "").trim();
  const adjustAmount = Number(p.sfpAdjustAmount);
  const remark = String(p.sfpRemark || "").trim();

  if (!merchantCode) return {ok:false,error:"操作四方错误：缺少四方商户名"};
  if (!channelName) return {ok:false,error:"操作四方错误：缺少通道名称"};
  if (!(adjustAmount > 0)) return {ok:false,error:"操作四方错误：四方调整金额必须大于0"};
  if (!remark) return {ok:false,error:"操作四方错误：缺少四方备注"};

  let source = await cowFindCurrentSfpTab();
  if (!source?.id) return {ok:false,error:"操作四方错误：找不到已查询的四方页面"};

  // 操作前再次回到提现记录并重新查询原单，确认资料未被改变且仍然没有“加扣款”按钮。
  try { source = await cowEnsureWorkPage(source.id, COW_SFP_WORK_URL, "四方"); }
  catch(e){ return {ok:false,error:"操作四方错误：重新定位提现记录失败："+String(e.message||e)}; }

  // 出款金额有少查询使用的是专用 sfp 结果，其中 operationText 应为无加扣款。
  // 这里重新调用 short-query 的四方抓取函数比较困难，因此先用页面快照检查当前订单仍存在且无加扣款。
  const safety = await cowExec(source.id, (inputOrderNo, internalOrderNo) => {
    const norm=v=>String(v==null?"":v).replace(/\s+/g,"").trim();
    const visible=el=>{if(!el)return false;const r=el.getBoundingClientRect(),s=getComputedStyle(el);return r.width>0&&r.height>0&&s.display!=="none"&&s.visibility!=="hidden";};
    const rows=[...document.querySelectorAll('tr')].filter(visible);
    const keys=[inputOrderNo,internalOrderNo].filter(Boolean).map(norm);
    const row=rows.find(tr=>{const t=norm(tr.innerText||tr.textContent);return keys.some(k=>k&&t.includes(k));});
    if(!row) return {ok:false,error:"操作前安全检查：当前四方页面找不到原订单"};
    const hasAdd=[...row.querySelectorAll('button,a,[role="button"],span,div')].some(el=>visible(el)&&norm(el.innerText||el.textContent)==="加扣款");
    if(hasAdd) return {ok:false,error:"加扣款按钮存在 请检查"};
    return {ok:true};
  }, [String(parsed.orderNo||""), String(sfp.internalOrderNo||"")]);
  if(!safety?.ok) return safety || {ok:false,error:"操作前安全检查失败"};

  // 四方固定需要两个页面：当前页负责商户，复制页负责通道。
  let merchantTab = source;
  let channelTab = null;
  try {
    const dup = await chrome.tabs.duplicate(source.id);
    if (!dup?.id) throw new Error("复制四方页面失败");
    if (dup.windowId !== source.windowId) {
      const moved = await chrome.tabs.move(dup.id,{windowId:source.windowId,index:-1});
      channelTab = Array.isArray(moved)?moved[0]:moved;
    } else channelTab = dup;
    await cowSetTabOpenMode(channelTab.id,"复制");
    await cowMuteTab(channelTab.id);

    // 使用者电脑速度、侧栏展开状态可能不同。第二笔通道页直接定位到固定网址，
    // 不依赖左侧「通道管理」菜单是否已经加载出来。
    let channelReady = null;
    let channelLastError = null;
    for (let attempt = 0; attempt < 3; attempt++) {
      try {
        channelReady = await cowEnsureWorkPage(channelTab.id, COW_SFP_CHANNEL_BALANCE_URL, "四方-通道");
        if (channelReady?.id) break;
      } catch (e) {
        channelLastError = e;
        await new Promise(r => setTimeout(r, 1200));
      }
    }
    if (!channelReady?.id) {
      throw new Error("通道余额调整页面定位失败" + (channelLastError ? "：" + String(channelLastError.message || channelLastError) : ""));
    }
    channelTab = channelReady;
  } catch(e){
    return {ok:false,error:"操作四方错误：建立第二个四方页面失败："+String(e.message||e)};
  }

  const runForm = async (tabId, mode) => {
    await cowBringTabToFront(tabId);
    await cowMuteTab(tabId);
    await cowSetCowTitle(tabId, mode==="merchant"?"四方-商户":"四方-通道");

    let results;
    try {
      results = await chrome.scripting.executeScript({
        target:{tabId},
        args:[mode, merchantCode, channelName, String(adjustAmount), remark],
        func: async (mode, merchantCode, channelName, amountText, remarkText) => {
          const norm=v=>String(v==null?"":v).replace(/\s+/g,"").trim();
          const visible=el=>{if(!el)return false;const r=el.getBoundingClientRect(),s=getComputedStyle(el);return r.width>0&&r.height>0&&s.display!=="none"&&s.visibility!=="hidden"&&Number(s.opacity||"1")!==0;};
          const sleep=ms=>new Promise(r=>setTimeout(r,ms));
          const waitFor=async(fn,timeout=15000)=>{const end=Date.now()+timeout;while(Date.now()<end){try{const v=fn();if(v)return v;}catch(_){}await sleep(120);}return null;};
          const click=el=>{if(!el)return false;el.scrollIntoView({block:'center',inline:'center'});try{el.click();}catch(_){el.dispatchEvent(new MouseEvent('click',{bubbles:true,cancelable:true,view:window}));}return true;};
          const setValue=(el,val)=>{if(!el)return false;el.focus();const proto=el instanceof HTMLTextAreaElement?HTMLTextAreaElement.prototype:HTMLInputElement.prototype;const setter=Object.getOwnPropertyDescriptor(proto,'value')?.set;if(!setter)return false;setter.call(el,'');el.dispatchEvent(new Event('input',{bubbles:true}));el.dispatchEvent(new Event('change',{bubbles:true}));setter.call(el,String(val));el.dispatchEvent(new Event('input',{bubbles:true}));el.dispatchEvent(new Event('change',{bubbles:true}));return true;};
          const findText=(wanted,root=document)=>[...root.querySelectorAll('button,a,span,div,li')].filter(visible).find(el=>norm(el.innerText||el.textContent)===norm(wanted));
          const findMenu=(wanted)=>{
            const selectors=[
              '.ant-menu-item','.ant-menu-submenu-title','.ant-menu-title-content',
              '[role="menuitem"]','li','a','span','div'
            ];
            const all=[...document.querySelectorAll(selectors.join(','))].filter(visible);
            const exact=all.filter(el=>norm(el.innerText||el.textContent)===norm(wanted));
            if(exact.length){
              // 优先取最小、最接近实际可点击菜单项的元素，避免抓到包住整段侧栏的容器。
              exact.sort((a,b)=>{
                const pa=(a.matches('.ant-menu-item,.ant-menu-submenu-title,[role="menuitem"],a')?0:1);
                const pb=(b.matches('.ant-menu-item,.ant-menu-submenu-title,[role="menuitem"],a')?0:1);
                if(pa!==pb) return pa-pb;
                return a.querySelectorAll('*').length-b.querySelectorAll('*').length;
              });
              return exact[0];
            }
            return null;
          };
          const clickMenu=(el)=>{
            if(!el) return false;
            const target=el.closest('.ant-menu-item,.ant-menu-submenu-title,[role="menuitem"],a,li')||el;
            return click(target);
          };

          // 先确认目标余额调整页面。
          // 通道页优先由 background 直接定位固定 URL；只有路径不对时才回退到侧栏导航。
          const parentText = mode==='merchant'?'商户管理':'通道管理';
          const childText = mode==='merchant'?'商户余额调整':'通道余额调整';
          const targetPath = mode==='merchant'
            ? '/management/tenant-manage/tenant-balance-transactions'
            : '/management/account-manage/payment-account-balance-transactions';

          // 慢电脑先等页面 DOM 稳定。
          await waitFor(()=>document.readyState==='complete' || document.readyState==='interactive',12000);
          await sleep(mode==='channel'?1200:350);

          if(location.pathname !== targetPath){
            let child=null;
            // 最多重试 5 次，避免侧栏尚未加载时直接误报「找不到菜单」。
            for(let attempt=0; attempt<5 && !child; attempt++){
              child=findMenu(childText);
              if(child) break;

              const parent=findMenu(parentText);
              if(parent){
                clickMenu(parent);
                await sleep(800);
                child=await waitFor(()=>findMenu(childText),2200);
                if(child) break;
              }
              await sleep(900);
            }
            if(!child) return {ok:false,error:`找不到菜单「${childText}」`};
            clickMenu(child);
            await sleep(1300);
          }

          // 等页面切换完成，再点击右上“+加扣款”。
          const addBtn=await waitFor(()=>[...document.querySelectorAll('button,a')].filter(visible).find(el=>norm(el.innerText||el.textContent).replace(/^\+/, '')==='加扣款'),12000);
          if(!addBtn) return {ok:false,error:`${childText}页面找不到“加扣款”按钮`};
          click(addBtn);

          const dialog=await waitFor(()=>[...document.querySelectorAll('.ant-modal,[role="dialog"],.ant-modal-wrap')].filter(visible).find(el=>norm(el.innerText||el.textContent).includes(childText)),10000);
          if(!dialog) return {ok:false,error:`点击加扣款后没有出现${childText}弹窗`};

          const newBtn=[...dialog.querySelectorAll('button,a')].filter(visible).find(el=>norm(el.innerText||el.textContent).replace(/^\+/, '')==='新增');
          if(!newBtn) return {ok:false,error:'加扣款弹窗找不到“新增”按钮'};
          click(newBtn); await sleep(300);

          // 找表格：用表头文字映射每一列，避免依赖固定 index。
          const table=await waitFor(()=>[...dialog.querySelectorAll('table')].find(t=>{const tx=norm(t.innerText||t.textContent);return mode==='merchant'?tx.includes('商户名')&&tx.includes('账变类型'):tx.includes('支付平台')&&tx.includes('通道名称');}),5000);
          if(!table) return {ok:false,error:'找不到新增资料表格'};
          const headers=[...table.querySelectorAll('thead th')].map(th=>norm(th.innerText||th.textContent));
          const row=[...table.querySelectorAll('tbody tr')].find(visible);
          if(!row) return {ok:false,error:'找不到新增资料列'};
          const cells=[...row.querySelectorAll('td')];
          const idx=name=>headers.findIndex(h=>h===norm(name)||h.includes(norm(name)));
          const cell=name=>{const i=idx(name);return i>=0?cells[i]:null;};

          const chooseExact=async(targetCell,wanted,label)=>{
            if(!targetCell) return {ok:false,error:`找不到${label}栏位`};
            const input=[...targetCell.querySelectorAll('input')].find(visible);
            const selector=[...targetCell.querySelectorAll('.ant-select-selector,[role="combobox"]')].find(visible) || input || targetCell;
            click(selector);
            if(input){setValue(input,wanted); input.dispatchEvent(new KeyboardEvent('keyup',{bubbles:true,key:'Unidentified'}));}
            const opt=await waitFor(()=>{
              const roots=[...document.querySelectorAll('.ant-select-dropdown,.ant-dropdown,[role="listbox"]')].filter(visible);
              const opts=roots.flatMap(r=>[...r.querySelectorAll('.ant-select-item-option,[role="option"],li,div')].filter(visible));
              return opts.find(o=>norm(o.innerText||o.textContent)===norm(wanted));
            },7000);
            if(!opt) return {ok:false,error:`${label}找不到完全相同选项：${wanted}`};
            click(opt); await sleep(180);
            const shown=norm(targetCell.innerText||targetCell.textContent)+(input?norm(input.value):'');
            if(!shown.includes(norm(wanted))) return {ok:false,error:`${label}点选后未显示目标：${wanted}`};
            return {ok:true};
          };

          if(mode==='merchant'){
            let r=await chooseExact(cell('商户名'),merchantCode,'商户名'); if(!r.ok)return r;
            r=await chooseExact(cell('账变类型'),'商户人工提出','账变类型'); if(!r.ok)return r;
          }else{
            let r=await chooseExact(cell('支付平台'),'回单支付','支付平台'); if(!r.ok)return r;
            r=await chooseExact(cell('通道名称'),channelName,'通道名称'); if(!r.ok)return r;
            r=await chooseExact(cell('账变类型'),'人工提出通道','账变类型'); if(!r.ok)return r;
          }

          const amountCell=cell('变动金额');
          const remarkCell=cell('备注');
          const amountInput=amountCell&&[...amountCell.querySelectorAll('input')].find(visible);
          const remarkInput=remarkCell&&[...remarkCell.querySelectorAll('textarea,input')].find(visible);
          if(!amountInput) return {ok:false,error:'找不到变动金额栏位'};
          if(!remarkInput) return {ok:false,error:'找不到备注栏位'};
          setValue(amountInput,amountText);
          setValue(remarkInput,remarkText);
          if(Number(amountInput.value)!==Number(amountText)) return {ok:false,error:`变动金额填写失败（预期${amountText}，目前${amountInput.value}）`};
          if(String(remarkInput.value||'').trim()!==remarkText) return {ok:false,error:'备注填写失败'};

          const confirm=[...dialog.querySelectorAll('button,a')].filter(visible).find(el=>norm(el.innerText||el.textContent)==='确定');
          if(!confirm) return {ok:false,error:'找不到第一次“确定”按钮'};
          click(confirm);

          const verify=await waitFor(()=>[...document.querySelectorAll('.ant-modal,[role="dialog"],.ant-modal-wrap')].filter(visible).find(el=>norm(el.innerText||el.textContent).includes('财务谷歌验证码')),12000);
          if(!verify) return {ok:false,error:'已点击确定，但没有出现财务谷歌验证码弹窗'};
          return {ok:true,status:'waiting_verification',mode,merchantCode,channelName,amount:Number(amountText),remark:remarkText};
        }
      });
    } catch(e){ return {ok:false,error:String(e.message||e)}; }
    return results?.[0]?.result || {ok:false,error:'四方页面没有回传结果'};
  };

  // 先准备商户页，再准备通道页；两页最终都停在验证码弹窗。
  const merchant = await runForm(merchantTab.id,'merchant');
  if(!merchant?.ok) return {ok:false,error:'四方商户：'+String(merchant?.error||'操作失败'),merchant};

  const channel = await runForm(channelTab.id,'channel');
  if(!channel?.ok) return {ok:false,error:'四方通道：'+String(channel?.error||'操作失败'),merchant,channel};

  return {ok:true,status:'waiting_verification',merchant,channel,merchantTabId:merchantTab.id,channelTabId:channelTab.id};
}

chrome.runtime.onMessage.addListener((message,sender,sendResponse)=>{
  if(!message || message.type!=="cow_short_sfp_prepare") return;
  (async()=>{
    try{sendResponse(await cowPrepareShortSfpAdjustments(message.lastQuery||null));}
    catch(e){sendResponse({ok:false,error:"四方两笔操作错误："+String(e.message||e)});}
  })();
  return true;
});

chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if(!message || message.type!=="cow_short_query") return;
  (async()=>{
    try{ sendResponse(await cowRunShortQuery(message.text||"")); }
    catch(e){ sendResponse({ok:false,error:"查询流程错误："+String(e.message||e)}); }
  })();
  return true;
});

chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (!message || message.type !== "cow_repay_query") return;

  (async () => {
    try {
      const result = await cowRunRepayQuery(message.text || "");
      sendResponse(result);
    } catch (e) {
      sendResponse({ ok:false, error:"查詢流程錯誤：" + String(e.message || e) });
    }
  })();

  return true;
});


chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (!message || message.type !== "cow_track_repay_click") return;
  (async () => {
    try {
      sendResponse(await cowTrackRepayClick(message.platform || ""));
    } catch (e) {
      // 統計錯誤只回報給呼叫端，不中斷補回主流程。
      sendResponse({ ok:false, error:String(e?.message || e) });
    }
  })();
  return true;
});

chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (!message || message.type !== "cow_track_short_click") return;
  (async () => {
    try {
      sendResponse(await cowTrackShortClick(message.platform || ""));
    } catch (e) {
      // 有少统计错误不影响主流程。
      sendResponse({ ok:false, error:String(e?.message || e) });
    }
  })();
  return true;
});
