(() => {
  const existing = document.getElementById("cow-floating-root");
  if (existing) {
    existing.style.display = existing.style.display === "none" ? "block" : "none";
    return;
  }

  const PLATFORM_ORDER = [
    "XY","OL","LS","XH",
    "TD","RF","HS","YD",
    "ND","YS","SH","JY",
    "JD","MT","FB"
  ];

  const PLATFORM_URLS = {
    "XY": "https://be.ms1666888.com/ManualDeposit",
    "OL": "https://be.ms1666888.com/ManualDeposit",
    "LS": "https://be.ms1666888.com/ManualDeposit",
    "XH": "https://be.ms1666888.com/ManualDeposit",
    "TD": "https://gz76qha4.tdyule222.com",
    "RF": "https://ktphr2j6.rfyule555.com/",
    "HS": "https://txwhsiqk.hsly04.com/",
    "YD": "https://ymsvcncb.ydyule666.com",
    "ND": "https://xgjemo.hdmx57.com/",
    "YS": "https://bu69t1grl1.ysyla16888.com/",
    "SH": "https://m6hcy34zd9.sh0031.com/",
    "JY": "https://dfdkgv.jyna67.com/",
    "JD": "https://b22465e41r.jdvip1688.com/",
    "MT": "https://kka0pl5f2t.mtyl1388.com/",
    "FB": "http://fbyl369.com/"
  };

  const MS_URL = "https://ms.rcppay.com/management/payment/third-party";
  const SFP_URL = "https://sfp.csussr.com/management/transaction-record/withdrawal-slips";

  const root = document.createElement("div");
  root.id = "cow-floating-root";
  root.innerHTML = `
    <div id="cow-dragbar">
      <div>
        <div id="cow-title">COW</div>
        <div id="cow-sub">控制中心</div>
      </div>
      <div id="cow-head-actions">
        <button id="cow-min" title="縮小">—</button>
        <button id="cow-close" title="隱藏">×</button>
      </div>
    </div>

    <div id="cow-tabs">
      <button class="cow-tab active" data-tab="login">檢查登入</button>
      <button class="cow-tab" data-tab="repay">出款失敗補回</button>
      <button class="cow-tab" data-tab="short">出款金額有少</button>
      <button class="cow-tab" data-tab="settings">补回记录</button>
    </div>

<div id="cow-body">
      <div class="cow-page active" data-page="login">
        <div class="cow-section-title">平台</div>
        <div id="cow-grid"></div>

        <button id="cow-check-login" class="cow-primary">檢查登入</button>

        <div id="cow-status">尚未操作</div>
        <div id="cow-note">選取平台後 點擊 檢查登入 確認是否都已登入</div>
      </div>

      <div class="cow-page" data-page="repay">
        <div class="cow-section-title">出款失敗補回</div>

        <textarea id="cow-repay-input" class="cow-textarea" rows="4" placeholder="請輸入補回資料格式&#10;RF\tWKRL_77638\tzd16888&#10;补回176"></textarea>

        <div class="cow-progress-wrap">
          <div class="cow-progress-line"></div>
          <div class="cow-progress-step" data-step="query">
            <div class="cow-progress-dot"></div>
            <div class="cow-progress-label">查詢</div>
          </div>
          <div class="cow-progress-step" data-step="ms">
            <div class="cow-progress-dot"></div>
            <div class="cow-progress-label">MS作帳</div>
          </div>
          <div class="cow-progress-step" data-step="operate">
            <div class="cow-progress-dot"></div>
            <div class="cow-progress-label">操作補回頁面</div>
          </div>
          <div class="cow-progress-step" data-step="captcha">
            <div class="cow-progress-dot"></div>
            <div class="cow-progress-label">人工輸入驗證碼</div>
          </div>
        </div>

        <div class="cow-return-grid">
          <div class="cow-return-card">
            <div class="cow-return-title cow-return-title-row"><span>查詢進度</span><button id="cow-query-btn" class="cow-inline-btn">查詢</button></div>
            <div id="cow-query-progress" class="cow-return-box">尚未開始</div>
          </div>
          <div class="cow-return-card">
            <div class="cow-return-title cow-return-title-row"><span>補回進度</span><button id="cow-repay-btn" class="cow-inline-btn">操作+MS作帳</button></div>
            <div id="cow-repay-progress" class="cow-return-box">尚未開始</div>
          </div>
        </div>

      </div>

      <div class="cow-page" data-page="short">
        <div class="cow-placeholder">出款金額有少</div>
      </div>

      <div class="cow-page" data-page="settings">
        <div class="cow-section-title">补回记录</div>
        <div id="cow-repay-records" class="cow-record-list">尚无记录</div>
      </div>
    </div>
  `;

  const style = document.createElement("style");
  style.textContent = `
    #cow-floating-root {
      position: fixed !important;
      top: 70px; right: 18px;
      width: 410px !important;
      z-index: 2147483647 !important;
      background: #f5f6f8 !important;
      border: 1px solid #b8b8b8 !important;
      border-radius: 12px !important;
      box-shadow: 0 10px 32px rgba(0,0,0,.24) !important;
      font-family: Arial,"Microsoft JhengHei",sans-serif !important;
      color:#222 !important;
      overflow:hidden !important;
    }
    #cow-floating-root * { box-sizing:border-box !important; }

    #cow-dragbar {
      padding:10px 12px !important;
      background:#222 !important;
      color:#fff !important;
      display:flex !important;
      justify-content:space-between !important;
      align-items:center !important;
      cursor:move !important;
      user-select:none !important;
    }

    #cow-title { font-size:17px !important; font-weight:700 !important; }
    #cow-sub { font-size:10px !important; opacity:.76 !important; }

    #cow-head-actions {
      display:flex !important;
      gap:6px !important;
    }

    #cow-head-actions button {
      width:28px !important;
      height:28px !important;
      padding:0 !important;
      border:0 !important;
      border-radius:6px !important;
      background:#fff !important;
      color:#222 !important;
      cursor:pointer !important;
    }

    #cow-tabs {
      display:grid !important;
      grid-template-columns: 0.95fr 1.45fr 1.35fr 0.75fr !important;
      background:#eceef1 !important;
      border-bottom:1px solid #ccc !important;
    }

    #cow-tabs .cow-tab {
      min-height:34px !important;
      padding:3px 4px !important;
      border:0 !important;
      border-right:1px solid #d7d7d7 !important;
      border-radius:0 !important;
      background:#eceef1 !important;
      color:#333 !important;
      font-size:11px !important;
      line-height:1.25 !important;
      cursor:pointer !important;
      white-space:normal !important;
      word-break:keep-all !important;
    }

    #cow-tabs .cow-tab:last-child { border-right:0 !important; }

    #cow-tabs .cow-tab.active {
      background:#fff !important;
      color:#111 !important;
      font-weight:700 !important;
      box-shadow:inset 0 -3px 0 #222 !important;
    }

    #cow-body { padding:12px !important; }

    .cow-page { display:none !important; }
    .cow-page.active { display:block !important; }

    .cow-section-title {
      font-size:14px !important;
      font-weight:700 !important;
      margin-bottom:8px !important;
    }

    #cow-grid {
      display:grid !important;
      grid-template-columns:repeat(4,1fr) !important;
      gap:6px !important;
    }

    #cow-grid label {
      display:flex !important;
      align-items:center !important;
      gap:5px !important;
      padding:7px 8px !important;
      border:1px solid #d7d7d7 !important;
      border-radius:6px !important;
      background:#fff !important;
      font-size:12px !important;
      cursor:pointer !important;
    }

    #cow-grid input {
      margin:0 !important;
    }

    #cow-floating-root .cow-primary {
      width:100% !important;
      margin-top:12px !important;
      padding:9px !important;
      border:1px solid #222 !important;
      border-radius:7px !important;
      background:#222 !important;
      color:#fff !important;
      font-size:13px !important;
      cursor:pointer !important;
    }

    #cow-status {
      margin-top:9px !important;
      padding:8px !important;
      background:#fff !important;
      border:1px solid #ddd !important;
      border-radius:7px !important;
      font-size:12px !important;
    }

    #cow-note {
      margin-top:8px !important;
      color:#666 !important;
      font-size:11px !important;
      line-height:1.45 !important;
    }

    .cow-placeholder {
      min-height:140px !important;
      display:flex !important;
      justify-content:center !important;
      align-items:center !important;
      border:1px dashed #ccc !important;
      border-radius:8px !important;
      background:#fff !important;
      color:#888 !important;
      font-size:13px !important;
    }

    .cow-textarea {
      width:100% !important;
      min-height:78px !important;
      resize:vertical !important;
      padding:8px 9px !important;
      border:1px solid #cfcfcf !important;
      border-radius:7px !important;
      background:#fff !important;
      color:#222 !important;
      font-size:12px !important;
      line-height:1.45 !important;
      outline:none !important;
    }

    .cow-progress-wrap {
      position:relative !important;
      display:grid !important;
      grid-template-columns:repeat(4,1fr) !important;
      margin:18px 2px 12px !important;
      padding-top:2px !important;
    }

    .cow-progress-line {
      position:absolute !important;
      left:12.5% !important;
      right:12.5% !important;
      top:11px !important;
      height:2px !important;
      background:#c9cdd3 !important;
      z-index:0 !important;
    }

    .cow-progress-step {
      position:relative !important;
      z-index:1 !important;
      text-align:center !important;
    }

    .cow-progress-dot {
      width:20px !important;
      height:20px !important;
      margin:0 auto 5px !important;
      border:2px solid #9ca3ad !important;
      border-radius:50% !important;
      background:#fff !important;
      box-shadow:0 0 0 3px #f5f6f8 !important;
    }

    .cow-progress-step.done .cow-progress-dot {
      border-color:#2e7d32 !important;
      background:#43a047 !important;
      box-shadow:0 0 0 3px #e8f5e9 !important;
    }

    .cow-progress-step.active .cow-progress-dot {
      border-color:#d99000 !important;
      background:#ffb300 !important;
      box-shadow:0 0 0 3px #fff3cd !important;
    }

    .cow-progress-label {
      font-size:10px !important;
      line-height:1.2 !important;
      color:#555 !important;
      white-space:normal !important;
    }

    .cow-return-grid {
      display:grid !important;
      grid-template-columns:1fr 1fr !important;
      gap:8px !important;
      margin-top:8px !important;
    }

    .cow-return-card {
      min-width:0 !important;
    }

    .cow-return-title {
      margin-bottom:4px !important;
      font-size:11px !important;
      font-weight:700 !important;
      color:#444 !important;
    }

    #cow-query-btn,
    #cow-repay-btn {
      font-size:11px !important;
    }

    #cow-query-progress,
    #cow-repay-progress {
      font-size:11px !important;
    }

    .cow-return-title-row > span {
      color:#444 !important;
      font-size:11px !important;
      font-weight:700 !important;
    }
.cow-return-box {
      min-height:64px !important;
      max-height:110px !important;
      overflow:auto !important;
      padding:7px !important;
      border:1px solid #d8d8d8 !important;
      border-radius:7px !important;
      background:#fff !important;
      color:#555 !important;
      font-size:11px !important;
      line-height:1.4 !important;
      white-space:pre-wrap !important;
    }

    #cow-query-progress,
    #cow-repay-progress {
      min-height:170px !important;
      max-height:260px !important;
      overflow-y:auto !important;
      font-size:11px !important;
      line-height:1.45 !important;
      padding:8px !important;
      white-space:normal !important;
    }

    #cow-repay-progress .cow-preview-main-line {
      font-size:11px !important;
      line-height:1.4 !important;
      margin:0 !important;
      transition:color .15s ease !important;
    }

    #cow-repay-progress .cow-preview-sub-line {
      padding-left:0 !important;
      font-size:11px !important;
      line-height:1.4 !important;
      margin:0 0 2px 0 !important;
    }

#cow-repay-progress .cow-preview-main-line.cow-preview-done {
      color:#16803a !important;
      font-weight:800 !important;
    }


    .cow-record-list {
      max-height:430px !important;
      overflow-y:auto !important;
      display:flex !important;
      flex-direction:column !important;
      gap:8px !important;
      color:#555 !important;
      font-size:11px !important;
      line-height:1.5 !important;
    }

    .cow-record-card {
      padding:9px 10px !important;
      border:1px solid #d8d8d8 !important;
      border-radius:8px !important;
      background:#fff !important;
      color:#333 !important;
      white-space:pre-wrap !important;
      word-break:break-all !important;
    }

    .cow-record-title {
      font-size:12px !important;
      font-weight:800 !important;
      color:#111 !important;
      margin-bottom:3px !important;
    }

    .cow-record-event {
      margin-top:2px !important;
      color:#16803a !important;
      font-weight:700 !important;
    }

.cow-section-gap {
      margin-top:12px !important;
    }

    .cow-captcha-list {
      display:flex !important;
      flex-direction:column !important;
      gap:7px !important;
    }

    .cow-captcha-row {
      display:grid !important;
      grid-template-columns:118px 1fr 96px !important;
      gap:5px !important;
      align-items:center !important;
    }

    .cow-captcha-name {
      font-size:11px !important;
      font-weight:700 !important;
      color:#333 !important;
    }

    .cow-code-input {
      width:100% !important;
      height:30px !important;
      padding:4px 7px !important;
      border:1px solid #ccc !important;
      border-radius:6px !important;
      background:#fff !important;
      color:#222 !important;
      font-size:11px !important;
      outline:none !important;
    }

    #cow-floating-root .cow-small-btn {
      height:30px !important;
      padding:0 6px !important;
      border:1px solid #222 !important;
      border-radius:6px !important;
      background:#222 !important;
      color:#fff !important;
      font-size:10px !important;
      cursor:pointer !important;
      white-space:nowrap !important;
    }

    #cow-floating-root .cow-secondary-btn {
      border-color:#bbb !important;
      background:#fff !important;
      color:#333 !important;
    }


    .cow-return-title-row {
      display:flex !important;
      align-items:center !important;
      justify-content:flex-start !important;
      gap:10px !important;
    }

    #cow-floating-root .cow-inline-btn {
      height:32px !important;
      min-width:72px !important;
      padding:0 16px !important;
      border:1px solid #222 !important;
      border-radius:6px !important;
      background:#222 !important;
      color:#fff !important;
      font-size:12px !important;
      font-weight:700 !important;
      cursor:pointer !important;
      line-height:30px !important;
      white-space:nowrap !important;
    }

  `;

  document.documentElement.appendChild(style);
  document.documentElement.appendChild(root);

  const grid = root.querySelector("#cow-grid");
  const status = root.querySelector("#cow-status");

  chrome.storage.local.get(["cowSelectedPlatforms", "cowPanelPosition"], (data) => {
    const selected = Array.isArray(data.cowSelectedPlatforms) ? data.cowSelectedPlatforms : [];
    PLATFORM_ORDER.forEach(code => {
      const label = document.createElement("label");
      label.innerHTML = `<input type="checkbox" value="${code}" ${selected.includes(code) ? "checked" : ""}> <span>${code}</span>`;
      grid.appendChild(label);
    });

    if (data.cowPanelPosition && typeof data.cowPanelPosition.x === "number" && typeof data.cowPanelPosition.y === "number") {
      root.style.left = `${data.cowPanelPosition.x}px`;
      root.style.top = `${data.cowPanelPosition.y}px`;
      root.style.right = "auto";
    }
  });

  function saveSelection() {
    const selected = [...grid.querySelectorAll('input[type="checkbox"]:checked')].map(x => x.value);
    chrome.storage.local.set({ cowSelectedPlatforms: selected });
    return selected;
  }

  grid.addEventListener("change", saveSelection);

  root.querySelector("#cow-check-login").addEventListener("click", () => {
    const selected = saveSelection();

    if (!selected.length) {
      status.textContent = "請先選取至少一個平台";
      return;
    }

    const WG_CODES = ["XY", "OL", "LS", "XH"];
    const hasWG = selected.some(code => WG_CODES.includes(code));
    const normalSelected = selected.filter(code => !WG_CODES.includes(code));

    const urls = [
      { name: "MS", url: MS_URL },
      { name: "四方", url: SFP_URL },
      ...(hasWG ? [{ name: "WG", url: PLATFORM_URLS["XY"] }] : []),
      ...normalSelected.map(code => ({ name: code, url: PLATFORM_URLS[code] }))
    ];

    status.textContent = `正在開啟：MS、四方、${selected.join("、")}`;

    chrome.runtime.sendMessage({ type: "open_urls", urls }, (resp) => {
      if (chrome.runtime.lastError) {
        status.textContent = "開啟失敗：" + chrome.runtime.lastError.message;
        return;
      }
      status.textContent = `已開啟：MS、四方、${selected.join("、")}`;
    });
  });


  const COW_REPAY_RECORDS_KEY = "cowRepayRecords";
  const COW_REPAY_RECORDS_MAX = 200;
  let cowDraftStartedAt = null;
  let cowLastRecordedRawText = "";
  let cowCurrentRecordId = "";

  function cowNowMs() {
    return Date.now();
  }

  function cowFormatClock(ms) {
    if (!ms) return "";
    const d = new Date(ms);
    const hh = String(d.getHours()).padStart(2, "0");
    const mm = String(d.getMinutes()).padStart(2, "0");
    return `${hh}：${mm}`;
  }

  function cowGetRepayInputLine(rawText) {
    const lines = String(rawText || "")
      .replace(/\r/g, "\n")
      .split("\n")
      .map(x => x.trim())
      .filter(Boolean);
    return lines.find(line => /[補补]回\s*[0-9]+(?:\.[0-9]+)?/.test(line)) || "";
  }

  function cowStorageGetRecords() {
    return new Promise(resolve => {
      chrome.storage.local.get([COW_REPAY_RECORDS_KEY], data => {
        const list = Array.isArray(data[COW_REPAY_RECORDS_KEY]) ? data[COW_REPAY_RECORDS_KEY] : [];
        resolve(list);
      });
    });
  }

  function cowStorageSetRecords(records) {
    return new Promise(resolve => {
      chrome.storage.local.set({ [COW_REPAY_RECORDS_KEY]: records }, () => resolve());
    });
  }

  async function cowRenderRepayRecords() {
    const box = root.querySelector("#cow-repay-records");
    if (!box) return;
    const records = await cowStorageGetRecords();
    if (!records.length) {
      box.textContent = "尚无记录";
      return;
    }

    // 由上到下：最舊在上、最新在最下面。舊版本留下的記錄也依時間重新排序。
    const orderedRecords = [...records].sort((a, b) => Number(a?.createdAt || 0) - Number(b?.createdAt || 0));

    box.innerHTML = orderedRecords.map(record => {
      const lines = [];
      lines.push(`<div class="cow-record-title">出款失败补回 ${cowEsc(cowFormatClock(record.createdAt))}</div>`);
      if (record.dateText) lines.push(`<div>${cowEsc(record.dateText)}</div>`);
      lines.push(`<div>${cowEsc(record.platform || "")}\t${cowEsc(record.orderNo || "")}</div>`);
      lines.push(`<div>${cowEsc(record.member || "")}</div>`);
      lines.push(`<div>${cowEsc(record.repayLine || "")}</div>`);
      if (record.queryAt) lines.push(`<div class="cow-record-event">${cowEsc(cowFormatClock(record.queryAt))} 查询</div>`);
      if (record.operationAt) lines.push(`<div class="cow-record-event">${cowEsc(cowFormatClock(record.operationAt))} 操作</div>`);
      return `<div class="cow-record-card">${lines.join("")}</div>`;
    }).join("");

    // 補回記錄採「舊在上、新在下」排列；每次開啟或更新後自動停在最下面，
    // 讓最新一筆直接出現在視野內，不需要使用者手動往下拉。
    requestAnimationFrame(() => {
      box.scrollTop = box.scrollHeight;
    });
  }

  async function cowCreateRepayRecord(rawText, queryResponse) {
    if (!queryResponse || !queryResponse.ok) return;
    const parsed = queryResponse.parsed || {};
    const now = cowNowMs();
    const record = {
      id: `repay_${now}_${Math.random().toString(36).slice(2, 8)}`,
      createdAt: cowDraftStartedAt || now,
      dateText: String(parsed.dateText || "").trim(),
      platform: String(parsed.platform || "").trim(),
      orderNo: String(parsed.orderNo || "").trim(),
      member: String(parsed.member || "").trim(),
      repayLine: cowGetRepayInputLine(rawText) || `补回${cowFmt(parsed.repayAmount)}`,
      rawText: String(rawText || ""),
      queryAt: now,
      operationAt: null
    };

    // 先鎖定目前這筆，避免使用者查詢完成後立刻按操作時產生記錄競態。
    cowCurrentRecordId = record.id;
    cowLastRecordedRawText = String(rawText || "");
    cowDraftStartedAt = null;

    const records = await cowStorageGetRecords();
    records.push(record);
    records.sort((a, b) => Number(a?.createdAt || 0) - Number(b?.createdAt || 0));
    if (records.length > COW_REPAY_RECORDS_MAX) {
      records.splice(0, records.length - COW_REPAY_RECORDS_MAX);
    }
    await cowStorageSetRecords(records);
    await cowRenderRepayRecords();
  }

  async function cowMarkCurrentRecordOperated() {
    if (!cowCurrentRecordId) return;
    const records = await cowStorageGetRecords();
    const record = records.find(x => x && x.id === cowCurrentRecordId);
    if (!record) return;
    if (!record.operationAt) record.operationAt = cowNowMs();
    await cowStorageSetRecords(records);
    await cowRenderRepayRecords();
  }

  const cowRepayInputForRecord = root.querySelector("#cow-repay-input");
  if (cowRepayInputForRecord) {
    cowRepayInputForRecord.addEventListener("input", () => {
      const value = cowRepayInputForRecord.value.trim();
      if (!value) {
        cowDraftStartedAt = null;
        cowCurrentRecordId = "";
        cowLastRecordedRawText = "";
        return;
      }
      if (!cowDraftStartedAt && value !== cowLastRecordedRawText.trim()) {
        cowDraftStartedAt = cowNowMs();
        cowCurrentRecordId = "";
      }
    });
  }

  cowRenderRepayRecords();

  function setProgressDot(stepName, state) {
    const step = root.querySelector(`.cow-progress-step[data-step="${stepName}"]`);
    if (!step) return;
    step.classList.remove("done", "active");
    if (state === "done") step.classList.add("done");
    if (state === "active") step.classList.add("active");
  }

  function cowEsc(v) {
    return String(v == null ? "" : v)
      .replace(/&/g, "&amp;")
      .replace(/</g, "&lt;")
      .replace(/>/g, "&gt;")
      .replace(/"/g, "&quot;")
      .replace(/'/g, "&#39;");
  }

  function cowFmt(v) {
    if (v == null || v === "") return "";
    const n = Number(v);
    if (Number.isFinite(n)) {
      if (Math.abs(n - Math.trunc(n)) < 1e-9) return String(Math.trunc(n));
      return n.toFixed(8).replace(/0+$/, "").replace(/\.$/, "");
    }
    return String(v);
  }

  function cowShowQueryError(box, message) {
    if (!box) return;
    box.innerHTML = `<div style="color:red;font-weight:700;">${cowEsc(message || "查詢失敗")}</div>`;
  }

  function formatQueryResult(data) {
    if (!data) return "查詢失敗：沒有返回資料";
    if (!data.ok) return data.error || "查詢失敗";

    const p = data.preview || {};
    const systemFee = Number(p.systemFee) || 0;
    const payoutFeeRepay = Number(p.payoutFeeRepay) || 0;
    const splitText = p.isSplit ? (p.splitText || "") : "無拆帳";
    const warnCloud = systemFee > 0 || payoutFeeRepay > 0;

    const repayLine = p.isSpecial
      ? `<div style="color:red;font-weight:800;">補回：${cowEsc(cowFmt(p.rmbAmount))} (${cowEsc(cowFmt(p.repayAmount))}+${cowEsc(cowFmt(p.systemFee))}手續費)</div>`
      : `<div>補回：${cowEsc(cowFmt(p.repayAmount))}</div>`;

    return {
      html: [
        `<div>人民幣金額：${cowEsc(cowFmt(p.rmbAmount))}</div>`,
        `<div>實際出款：${cowEsc(cowFmt(p.actualPayout))}</div>`,
        `<div>拆帳：${cowEsc(splitText)}</div>`,
        repayLine,
        `<div${systemFee > 0 ? ' style="color:red;font-weight:700;"' : ''}>系統手續費：${cowEsc(cowFmt(p.systemFee))}</div>`,
        `<div${payoutFeeRepay > 0 ? ' style="color:red;font-weight:700;"' : ''}>出款手續費補回：${cowEsc(cowFmt(p.payoutFeeRepay))}</div>`,
        warnCloud ? `<div style="color:red;font-weight:800;font-size:20px;line-height:1.5;margin-top:4px;">請確認是否需要填寫雲端</div>` : ""
      ].join("")
    };
  }

  function formatRepayPreview(data) {
    if (!data || !data.ok) return "請先完成查詢";

    const p = data.preview || {};
    const platform = String(p.platform || (data.parsed && data.parsed.platform) || "").trim() || "平台";
    const platformAmount = Number(p.platformFirstAmount);
    const inputRepay = Number(p.repayAmount);
    const amountDifferent = Number.isFinite(platformAmount) && Number.isFinite(inputRepay)
      ? Math.abs(platformAmount - inputRepay) > 1e-9
      : String(p.platformFirstAmount) !== String(p.repayAmount);

    const platformAmountStyle = amountDifferent
      ? ' style="color:red;font-weight:800;"'
      : "";

    const secondAmount = p.needPlatformSecond ? cowFmt(p.platformSecondAmount) : "不需要";
    const secondRemark = p.needPlatformSecond ? (p.platformSecondRemark || "") : "不需要";

    return {
      html: [
        `<div id="cow-preview-ms" class="cow-preview-main-line"><b>1.MS 金額：${cowEsc(cowFmt(p.msAmount))}</b></div>`,
        `<div class="cow-preview-sub-line">備註：${cowEsc(p.msRemark || "")}</div>`,

                `<div id="cow-preview-sfp" class="cow-preview-main-line"><b>2.四方 金額：${cowEsc(cowFmt(p.sfpOrderAmount))}</b></div>`,
        `<div class="cow-preview-sub-line">備註：${cowEsc(p.effectiveDateText ? `${p.effectiveDateText} 保留原備註` : "保留原備註")}</div>`,

                `<div id="cow-preview-platform1" class="cow-preview-main-line"${platformAmountStyle}><b>3.${cowEsc(platform)}平台 金額：${cowEsc(cowFmt(p.platformFirstAmount))}</b></div>`,
        `<div class="cow-preview-sub-line">第一筆備註：${cowEsc(p.platformFirstRemark || "")}</div>`,

                `<div id="cow-preview-platform2" class="cow-preview-main-line"><b>4.平台手續費 金額：${cowEsc(secondAmount)}</b></div>`,
        `<div class="cow-preview-sub-line">第二筆備註：${cowEsc(secondRemark)}</div>`
      ].join("")
    };
  }

  function cowRenderRepayPreview(data) {
    const box = root.querySelector("#cow-repay-progress");
    if (!box) return;
    try {
      const formatted = formatRepayPreview(data);
      if (formatted && typeof formatted === "object" && formatted.html) {
        box.innerHTML = formatted.html;
      } else {
        box.textContent = formatted;
      }
    } catch (err) {
      box.textContent = "補回預覽顯示錯誤：" + (err && err.message ? err.message : String(err));
    }
  }

  function cowMarkPreviewLineDone(kind) {
    const idMap = {
      ms: "#cow-preview-ms",
      sfp: "#cow-preview-sfp",
      platform1: "#cow-preview-platform1",
      platform2: "#cow-preview-platform2"
    };
    const el = root.querySelector(idMap[kind] || "");
    if (el) el.classList.add("cow-preview-done");
  }

  let cowLastQueryResponse = null;
  let cowMsDoneForQuery = false;
  let cowSfpPreparedForQuery = false;
  let cowSfpDoneForQuery = false;
  let cowPlatformPreparedForQuery = false;

  const queryBtn = root.querySelector("#cow-query-btn");
  if (queryBtn) {
    queryBtn.addEventListener("click", () => {
      const box = root.querySelector("#cow-query-progress");
      const input = root.querySelector("#cow-repay-input");
      const rawText = input ? input.value.trim() : "";

      // 每次按查詢都視為全新一筆：進度條先歸零，舊查詢與操作狀態全部清除。
      ["query", "ms", "operate", "captcha"].forEach(step => setProgressDot(step, ""));
      cowLastQueryResponse = null;
      cowMsDoneForQuery = false;
      cowSfpPreparedForQuery = false;
      cowSfpDoneForQuery = false;
      cowPlatformPreparedForQuery = false;

      const repayBox = root.querySelector("#cow-repay-progress");
      if (repayBox) repayBox.textContent = "尚未開始";

      if (!rawText) {
        cowShowQueryError(box, "請先輸入補回資料");
        return;
      }

      queryBtn.disabled = true;
      queryBtn.textContent = "查詢中";
      if (box) box.textContent = "正在查詢四方...";
      setProgressDot("query", "active");

      chrome.runtime.sendMessage(
        { type: "cow_repay_query", text: rawText },
        (resp) => {
          queryBtn.disabled = false;
          queryBtn.textContent = "查詢";

          if (chrome.runtime.lastError) {
            cowShowQueryError(box, "查詢失敗：" + chrome.runtime.lastError.message);
            setProgressDot("query", "");
            return;
          }

          if (resp && resp.ok) {
            cowLastQueryResponse = resp;
            cowRenderRepayPreview(resp);
            cowCreateRepayRecord(rawText, resp).catch(() => {});
          } else {
            cowLastQueryResponse = null;
            const repayBox = root.querySelector("#cow-repay-progress");
            if (repayBox) repayBox.textContent = "尚未開始";
          }

          if (box) {
            try {
              const formatted = formatQueryResult(resp);
              if (formatted && typeof formatted === "object" && formatted.html) {
                box.innerHTML = formatted.html;
              } else if (resp && !resp.ok) {
                cowShowQueryError(box, formatted);
              } else {
                box.textContent = formatted;
              }
            } catch (err) {
              cowShowQueryError(box, "查詢結果顯示錯誤：" + (err && err.message ? err.message : String(err)));
            }
          }

          if (resp && resp.ok) {
            setProgressDot("query", "done");
          } else {
            setProgressDot("query", "");
          }
        }
      );
    });
  }

  const repayBtn = root.querySelector("#cow-repay-btn");
  if (repayBtn) {
    repayBtn.addEventListener("click", async () => {
      const repayBox = root.querySelector("#cow-repay-progress");

      if (!cowLastQueryResponse || !cowLastQueryResponse.ok) {
        if (repayBox) {
          repayBox.insertAdjacentHTML("beforeend",
            '<div style="color:red;font-weight:700;margin-top:4px;">請先完成查詢，再進行作帳</div>');
        }
        return;
      }

      cowRenderRepayPreview(cowLastQueryResponse);
      if (cowMsDoneForQuery) cowMarkPreviewLineDone("ms");
      if (cowSfpPreparedForQuery || cowSfpDoneForQuery) cowMarkPreviewLineDone("sfp");
      if (cowPlatformPreparedForQuery) {
        cowMarkPreviewLineDone("platform1");
        if (cowLastQueryResponse?.preview?.needPlatformSecond) cowMarkPreviewLineDone("platform2");
      }

      repayBtn.disabled = true;
      repayBtn.textContent = "操作中";
      setProgressDot("ms", cowMsDoneForQuery ? "done" : "active");
      setProgressDot("operate", "");
      setProgressDot("captcha", "");

      const send = payload => new Promise(resolve => {
        chrome.runtime.sendMessage(payload, resp => {
          if (chrome.runtime.lastError) {
            resolve({ok:false,error:chrome.runtime.lastError.message});
          } else {
            resolve(resp || {ok:false,error:"沒有回傳結果"});
          }
        });
      });

      // 使用統計：每次有效的「操作+MS作帳」點擊都算 1 次，並記錄平台。
      // 統計失敗不影響原本補回流程。
      void send({
        type:"cow_track_repay_click",
        platform:String(cowLastQueryResponse?.parsed?.platform || "").toUpperCase()
      });

      // Step 1: MS. If already successful for this query, never submit it again.
      if (!cowMsDoneForQuery) {
        const msResp = await send({ type:"cow_ms_repay_execute", lastQuery:cowLastQueryResponse });
        if (!msResp.ok) {
          if (repayBox) repayBox.insertAdjacentHTML("beforeend",
            `<div style="color:red;font-weight:700;margin-top:4px;">${cowEsc(msResp.error || "6.操作MS錯誤")}</div>`);
          repayBtn.disabled = false;
          repayBtn.textContent = "操作+MS作帳";
          return;
        }
        cowMsDoneForQuery = true;
        cowMarkPreviewLineDone("ms");
        setProgressDot("ms", "done");
      } else {
        setProgressDot("ms", "done");
      }

      // Step 2: 四方 + 平台操作到驗證碼頁面，驗證碼由使用者直接在各頁面人工輸入。
      setProgressDot("operate", "active");
      if (!cowSfpPreparedForQuery && !cowSfpDoneForQuery) {
        const sfpResp = await send({ type:"cow_sfp_repay_prepare", lastQuery:cowLastQueryResponse });
        if (!sfpResp.ok) {
          if (repayBox) repayBox.insertAdjacentHTML("beforeend",
            `<div style="color:red;font-weight:700;margin-top:4px;">${cowEsc(sfpResp.error || "7.操作四方錯誤")}</div>`);
          repayBtn.disabled = false;
          repayBtn.textContent = "操作+MS作帳";
          return;
        }
        cowSfpPreparedForQuery = true;
        cowMarkPreviewLineDone("sfp");
      }

      if (repayBox && cowSfpPreparedForQuery && !cowSfpDoneForQuery) {
        repayBox.insertAdjacentHTML("beforeend",
          '<div style="margin-top:4px;">四方補回頁面已操作完成，請至四方頁面人工輸入驗證碼</div>');
      }

      // 接著操作平台；平台同樣只操作到驗證碼畫面。
      // DY：XY/OL/LS/XH 共用 ManualDeposit；KR/TD 走標準平台流程。
      const platformCode = String(cowLastQueryResponse?.parsed?.platform || "").toUpperCase();
      const isWG = ["XY","OL","LS","XH"].includes(platformCode);

      if (!cowPlatformPreparedForQuery) {
        const platformResp = isWG
          ? await send({
              type:"cow_prepare_manual_deposit",
              lastQuery:cowLastQueryResponse
            })
          : await send({
              type:"cow_prepare_standard_platform",
              lastQuery:cowLastQueryResponse
            });

        if (!platformResp.ok) {
          if (repayBox) repayBox.insertAdjacentHTML("beforeend",
            `<div style="color:red;font-weight:700;margin-top:4px;">${cowEsc(platformResp.error || "8.操作平台錯誤")}</div>`);
          repayBtn.disabled = false;
          repayBtn.textContent = "操作+MS作帳";
          return;
        }

        cowPlatformPreparedForQuery = true;
        cowMarkPreviewLineDone("platform1");
        if (platformResp.needSecond) cowMarkPreviewLineDone("platform2");

        if (repayBox) {
          if (isWG) {
            if (platformResp.needSecond) {
              repayBox.insertAdjacentHTML("beforeend",
                `<div style="margin-top:4px;">${cowEsc(platformCode)} DY 已填好並送出兩筆：充值-USDT + 红利，請至平台頁面人工輸入兩組驗證碼</div>`);
            } else {
              repayBox.insertAdjacentHTML("beforeend",
                `<div style="margin-top:4px;">${cowEsc(platformCode)} DY 已填好並送出第一筆：充值-USDT，請至平台頁面人工輸入驗證碼</div>`);
            }
          } else if (platformResp.needSecond) {
            repayBox.insertAdjacentHTML("beforeend",
              `<div style="margin-top:4px;">${cowEsc(platformCode)} 已清除舊資料並填好兩筆，請至平台頁面人工輸入兩組驗證碼</div>`);
          } else {
            repayBox.insertAdjacentHTML("beforeend",
              `<div style="margin-top:4px;">${cowEsc(platformCode)} 已清除舊資料並填好第一筆，請至平台頁面人工輸入驗證碼</div>`);
          }
        }
      }

      // 四方與平台都已操作到驗證碼頁面。
      setProgressDot("operate", "done");
      setProgressDot("captcha", "active");
      await cowMarkCurrentRecordOperated();

      repayBtn.disabled = false;
      repayBtn.textContent = "操作+MS作帳";
    });
  }

  root.querySelectorAll(".cow-tab").forEach(tab => {
    tab.addEventListener("click", () => {
      root.querySelectorAll(".cow-tab").forEach(x => x.classList.remove("active"));
      root.querySelectorAll(".cow-page").forEach(x => x.classList.remove("active"));
      tab.classList.add("active");
      root.querySelector(`.cow-page[data-page="${tab.dataset.tab}"]`).classList.add("active");
      if (tab.dataset.tab === "settings") cowRenderRepayRecords().catch(() => {});
    });
  });

  root.querySelector("#cow-close").addEventListener("click", () => {
    root.style.display = "none";
  });

  let minimized = false;
  root.querySelector("#cow-min").addEventListener("click", () => {
    minimized = !minimized;
    root.querySelector("#cow-tabs").style.display = minimized ? "none" : "grid";
    root.querySelector("#cow-body").style.display = minimized ? "none" : "block";
  });

  const dragbar = root.querySelector("#cow-dragbar");
  let dragging = false, dx = 0, dy = 0;

  dragbar.addEventListener("mousedown", (e) => {
    if (e.target.closest("button")) return;
    dragging = true;
    const rect = root.getBoundingClientRect();
    dx = e.clientX - rect.left;
    dy = e.clientY - rect.top;
    root.style.right = "auto";
    e.preventDefault();
  });

  document.addEventListener("mousemove", (e) => {
    if (!dragging) return;
    const x = Math.max(0, Math.min(window.innerWidth - root.offsetWidth, e.clientX - dx));
    const y = Math.max(0, Math.min(window.innerHeight - 40, e.clientY - dy));
    root.style.left = `${x}px`;
    root.style.top = `${y}px`;
  });

  document.addEventListener("mouseup", () => {
    if (!dragging) return;
    dragging = false;
    const rect = root.getBoundingClientRect();
    chrome.storage.local.set({
      cowPanelPosition: { x: Math.round(rect.left), y: Math.round(rect.top) }
    });
  });
})();
